import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Pressable } from 'react-native';
import * as Location from 'expo-location';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { useLocalSearchParams } from 'expo-router';
import { Search, MapPin, Hospital, Pill, Bus, Landmark, ShoppingBag, UtensilsCrossed, Bath, Mic, MicOff, Square, Volume2, Footprints, ChevronRight } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { ScreenWrapper, AccessibleHeading, AccessibleButton } from '@/components/ui/AccessibleComponents';
import { SosButton } from '@/components/SosButton';
import {
  Coords, Place, Route, NearbyKind,
  getCurrentCoords, getHeading, searchPlaces, walkingRoute, nearbyPlaces, whereAmI,
  haversine, formatDistance, formatDuration, directionPhrase, navErrorMessage,
} from '@/services/navigation';
import { haptic } from '@/lib/haptics';

const NEARBY_TILES: { kind: NearbyKind; icon: any; labelKey: string }[] = [
  { kind: 'hospital', icon: Hospital, labelKey: 'hospitals' },
  { kind: 'pharmacy', icon: Pill, labelKey: 'pharmacies' },
  { kind: 'transit', icon: Bus, labelKey: 'transit' },
  { kind: 'atm', icon: Landmark, labelKey: 'atms' },
  { kind: 'toilets', icon: Bath, labelKey: 'toilets' },
  { kind: 'restaurant', icon: UtensilsCrossed, labelKey: 'restaurants' },
  { kind: 'shopping', icon: ShoppingBag, labelKey: 'shopping' },
];

// Guidance tuning (metres). GPS in cities drifts 10-20 m, so the numbers are deliberately generous.
const REACHED_M = 20;
const NEAR_M = 45;
const FAR_M = 130;
const OFF_ROUTE_M = 70;

export default function NavigationScreen() {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const { speak, stop } = useSpeech();
  const params = useLocalSearchParams<{ dest?: string; nearby?: string; auto?: string }>();
  const lang = language === 'ta' ? 'ta-IN' : 'en-US';

  const [query, setQuery] = useState('');
  const [places, setPlaces] = useState<Place[]>([]);
  const [placesTitle, setPlacesTitle] = useState('');
  const [route, setRoute] = useState<Route | null>(null);
  const [stepIndex, setStepIndex] = useState(0);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');

  // Guidance state lives in refs: it changes with every GPS fix and must not re-render or resubscribe.
  const routeRef = useRef<Route | null>(null);
  const destRef = useRef<Place | null>(null);
  const idxRef = useRef(0);
  const announced = useRef<Set<string>>(new Set());
  const minDist = useRef(Infinity);
  const awayCount = useRef(0);
  const lastReroute = useRef(0);
  const rerouting = useRef(false);

  const say = useCallback((text: string) => {
    setStatus(text);
    speak(text, { lang });
  }, [speak, lang]);

  const fail = useCallback((e: unknown) => {
    haptic.error();
    say(navErrorMessage(e, language));
  }, [say, language]);

  /* ---------------- guidance ---------------- */

  const stepText = (r: Route, i: number) => {
    const step = r.steps[i];
    const last = i >= r.steps.length - 1;
    return last || step.distanceM < 1
      ? step.instruction
      : language === 'ta'
      ? `${step.instruction}. பிறகு ${formatDistance(step.distanceM, language)} நடக்கவும்.`
      : `${step.instruction}, then walk ${formatDistance(step.distanceM, language)}.`;
  };

  const stopGuidance = useCallback((announce = true) => {
    routeRef.current = null;
    destRef.current = null;
    setRoute(null);
    setStepIndex(0);
    deactivateKeepAwake('guidance').catch(() => {});
    if (announce) say(language === 'ta' ? 'வழிகாட்டுதல் நிறுத்தப்பட்டது.' : 'Guidance stopped.');
  }, [say, language]);

  const beginRoute = useCallback((r: Route, dest: Place, intro: string) => {
    routeRef.current = r;
    destRef.current = dest;
    idxRef.current = 0;
    announced.current = new Set();
    minDist.current = Infinity;
    awayCount.current = 0;
    setRoute(r);
    setStepIndex(0);
    setPlaces([]);
    activateKeepAwakeAsync('guidance').catch(() => {});
    haptic.success();
    say(`${intro} ${stepText(r, 0)}`);
  }, [say, language]);

  const startRoute = useCallback(async (dest: Place) => {
    setBusy(true);
    say(t('gettingLocation'));
    try {
      const from = await getCurrentCoords();
      const r = await walkingRoute(from, dest, language);
      const intro =
        language === 'ta'
          ? `${dest.name} க்கு நடைப் பயணம். ${formatDistance(r.totalDistanceM, language)}, சுமார் ${formatDuration(r.totalDurationS, language)}.`
          : `Walking to ${dest.name}. ${formatDistance(r.totalDistanceM, language)}, about ${formatDuration(r.totalDurationS, language)}.`;
      beginRoute(r, dest, intro);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }, [language, beginRoute, say, fail]);

  const reroute = useCallback(async (from: Coords) => {
    const dest = destRef.current;
    if (!dest || rerouting.current || Date.now() - lastReroute.current < 20000) return;
    rerouting.current = true;
    lastReroute.current = Date.now();
    haptic.warning();
    speak(t('recalculating'), { lang });
    try {
      const r = await walkingRoute(from, dest, language);
      routeRef.current = r;
      idxRef.current = 0;
      announced.current = new Set();
      minDist.current = Infinity;
      awayCount.current = 0;
      setRoute(r);
      setStepIndex(0);
      say(stepText(r, 0));
    } catch (e) {
      say(navErrorMessage(e, language));
    } finally {
      rerouting.current = false;
    }
  }, [language, say, speak, lang]);

  // Live GPS while a route is active.
  const guiding = !!route;
  useEffect(() => {
    if (!guiding) return;
    let sub: Location.LocationSubscription | null = null;
    let cancelled = false;

    const onFix = (pos: Location.LocationObject) => {
      const r = routeRef.current;
      if (!r) return;
      const here = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      let idx = idxRef.current;
      const next = r.steps[idx + 1];
      if (!next) return;
      const d = haversine(here, next.at);

      if (d <= REACHED_M) {
        idx += 1;
        idxRef.current = idx;
        minDist.current = Infinity;
        awayCount.current = 0;
        setStepIndex(idx);
        haptic.warning();
        if (idx >= r.steps.length - 1) {
          say(r.steps[idx].instruction);
          haptic.success();
          stopGuidance(false);
        } else {
          say(stepText(r, idx));
        }
        return;
      }

      const key = (s: string) => `${idx}:${s}`;
      if (d <= NEAR_M && !announced.current.has(key('near'))) {
        announced.current.add(key('near'));
        haptic.warning();
        speak(language === 'ta' ? `விரைவில்: ${next.instruction}` : `Coming up: ${next.instruction}`, { lang });
      } else if (d <= FAR_M && d > NEAR_M && r.steps[idx].distanceM > 200 && !announced.current.has(key('far'))) {
        announced.current.add(key('far'));
        speak(language === 'ta' ? `${formatDistance(d, language)} இல், ${next.instruction}` : `In ${formatDistance(d, language)}, ${next.instruction}`, { lang });
      }

      // Walking away from the next turn for several fixes in a row means we left the route.
      if (d < minDist.current) {
        minDist.current = d;
        awayCount.current = 0;
      } else if (d > minDist.current + OFF_ROUTE_M) {
        if (++awayCount.current >= 3) reroute(here);
      }
    };

    Location.watchPositionAsync(
      { accuracy: Location.Accuracy.High, distanceInterval: 4, timeInterval: 2000 },
      onFix
    )
      .then((s) => {
        if (cancelled) s.remove();
        else sub = s;
      })
      .catch((e) => fail(e));

    return () => {
      cancelled = true;
      sub?.remove();
    };
  }, [guiding]);

  useEffect(
    () => () => {
      deactivateKeepAwake('guidance').catch(() => {});
    },
    []
  );

  /* ---------------- search / nearby / where am I ---------------- */

  const runSearch = useCallback(async (q: string, autoStart: boolean) => {
    const text = q.trim();
    if (!text) return;
    setBusy(true);
    setPlaces([]);
    say(language === 'ta' ? `${text} ஐத் தேடுகிறேன்.` : `Searching for ${text}.`);
    try {
      let near: Coords | null = null;
      try {
        near = await getCurrentCoords();
      } catch {
        near = null;
      }
      const found = await searchPlaces(text, near, language);
      if (found.length === 0) {
        say(language === 'ta' ? `${text} கிடைக்கவில்லை. வேறு பெயரை முயற்சிக்கவும்.` : `I could not find ${text}. Try another name.`);
        return;
      }
      setPlacesTitle(text);
      if (autoStart || found.length === 1) {
        const top = found[0];
        setPlaces([]);
        await startRoute(top);
        return;
      }
      setPlaces(found);
      say(
        language === 'ta'
          ? `${found.length} இடங்கள் கிடைத்தன. முதலாவது ${found[0].name}. ஒன்றைத் தேர்ந்தெடுக்கவும்.`
          : `I found ${found.length} places. The first is ${found[0].name}. Choose one.`
      );
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }, [language, say, startRoute, fail]);

  const runNearby = useCallback(async (kind: NearbyKind) => {
    setBusy(true);
    setPlaces([]);
    haptic.tap();
    const tile = NEARBY_TILES.find((x) => x.kind === kind)!;
    const title = t(tile.labelKey);
    setPlacesTitle(title);
    say(t('gettingLocation'));
    try {
      const from = await getCurrentCoords();
      const [found, heading] = await Promise.all([nearbyPlaces(kind, from, language), getHeading()]);
      if (found.length === 0) {
        say(t('nothingNearby'));
        return;
      }
      const withDir = found.map((p) => ({ ...p }));
      setPlaces(withDir);
      const spoken = withDir
        .slice(0, 3)
        .map((p, i) => `${i + 1}. ${p.name}, ${formatDistance(p.distanceM ?? 0, language)}, ${directionPhrase(p.bearing ?? 0, heading, language)}.`)
        .join(' ');
      say(`${title}. ${spoken}`);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }, [language, say, fail]);

  const runWhereAmI = useCallback(async () => {
    setBusy(true);
    haptic.tap();
    say(t('gettingLocation'));
    try {
      say(await whereAmI(await getCurrentCoords(), language));
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }, [language, say, fail]);

  // Opened by Eyo: "take me to ..." / "nearest pharmacy".
  const lastAuto = useRef<string | null>(null);
  useEffect(() => {
    if (!params.auto || params.auto === lastAuto.current) return;
    lastAuto.current = params.auto;
    if (params.dest) runSearch(params.dest, true);
    else if (params.nearby) runNearby(params.nearby as NearbyKind);
  }, [params.auto]);

  /* ---------------- voice destination ---------------- */

  const recognition = useSpeechRecognition({
    lang,
    onResult: ({ transcript }) => {
      setQuery(transcript);
      runSearch(transcript, false);
    },
  });

  const onMic = () => {
    haptic.tap();
    if (recognition.isListening) return recognition.stop();
    stop();
    speak(language === 'ta' ? 'எங்கே செல்ல வேண்டும்?' : 'Where do you want to go?', { lang, onEnd: () => recognition.start() });
  };

  /* ---------------- render ---------------- */

  const current = route ? route.steps[stepIndex] : null;

  if (route && current) {
    const next = route.steps[stepIndex + 1];
    return (
      <ScreenWrapper style={styles.screen}>
        <View style={styles.header}>
          <AccessibleHeading text={t('navigation')} level={1} />
          <SosButton compact />
        </View>
        <ScrollView contentContainerStyle={{ gap: 14, paddingBottom: 20 }}>
          <View style={[styles.guideCard, { backgroundColor: colors.surface, borderColor: colors.accent }]} accessibilityLiveRegion="polite">
            <Footprints color={colors.accent} size={36} strokeWidth={2.5} />
            <Text style={[styles.guideDest, { color: colors.textSecondary, fontSize: getFontSize(15) }]}>{route.destination}</Text>
            <Text style={[styles.guideText, { color: colors.text, fontSize: getFontSize(26) }]}>{current.instruction}</Text>
            {next && (
              <Text style={[styles.guideSub, { color: colors.textSecondary, fontSize: getFontSize(16) }]}>
                {language === 'ta' ? 'அடுத்து: ' : 'Next: '}
                {next.instruction}
              </Text>
            )}
          </View>

          <AccessibleButton
            label={t('repeatInstruction')}
            size="extraLarge"
            icon={<Volume2 color={colors.primaryText} size={28} strokeWidth={2.5} />}
            onPress={() => {
              haptic.tap();
              say(stepText(route, stepIndex));
            }}
          />
          <AccessibleButton
            label={t('whereAmI')}
            variant="secondary"
            size="large"
            icon={<MapPin color={colors.text} size={26} strokeWidth={2.5} />}
            onPress={runWhereAmI}
          />
          <AccessibleButton
            label={t('stopNavigation')}
            variant="danger"
            size="large"
            icon={<Square color="#FFF" size={24} strokeWidth={2.5} />}
            onPress={() => stopGuidance()}
          />
          <Text style={[styles.hint, { color: colors.textSecondary, fontSize: getFontSize(13) }]}>
            {language === 'ta'
              ? 'வழிகாட்டும்போது செயலியைத் திறந்து வைத்திருங்கள். வெள்ளைக் கோல் அல்லது வழிகாட்டி நாயைத் தொடர்ந்து பயன்படுத்துங்கள்.'
              : 'Keep the app open while walking. Keep using your cane or guide dog: GPS can be off by 10 to 20 metres.'}
          </Text>
        </ScrollView>
      </ScreenWrapper>
    );
  }

  return (
    <ScreenWrapper style={styles.screen}>
      <View style={styles.header}>
        <AccessibleHeading text={t('navigation')} level={1} />
        <SosButton compact />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: 12, paddingBottom: 20 }} keyboardShouldPersistTaps="handled">
        <AccessibleButton
          label={t('whereAmI')}
          size="large"
          icon={<MapPin color={colors.primaryText} size={26} strokeWidth={2.5} />}
          onPress={runWhereAmI}
          disabled={busy}
        />

        <View style={[styles.searchRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            onPress={onMic}
            disabled={!recognition.isSupported()}
            accessibilityRole="button"
            accessibilityLabel={recognition.isListening ? t('stop') : t('microphone')}
            style={[styles.micBtn, { backgroundColor: recognition.isListening ? colors.error : colors.primary, opacity: recognition.isSupported() ? 1 : 0.4 }]}
          >
            {recognition.isListening ? <MicOff color="#FFF" size={26} strokeWidth={2.5} /> : <Mic color={colors.primaryText} size={26} strokeWidth={2.5} />}
          </Pressable>
          <TextInput
            style={[styles.input, { color: colors.text, fontSize: getFontSize(16) }]}
            placeholder={t('searchLocation')}
            placeholderTextColor={colors.textSecondary}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => runSearch(query, false)}
            returnKeyType="search"
            accessibilityLabel={t('searchLocation')}
          />
          <Pressable
            onPress={() => runSearch(query, false)}
            accessibilityRole="button"
            accessibilityLabel={t('search')}
            style={[styles.micBtn, { backgroundColor: colors.accent }]}
          >
            <Search color="#000" size={26} strokeWidth={2.5} />
          </Pressable>
        </View>

        {busy && (
          <Text accessibilityLiveRegion="polite" style={{ color: colors.textSecondary, fontSize: getFontSize(16), fontWeight: '600', textAlign: 'center' }}>
            {t('loading')}
          </Text>
        )}

        {places.length > 0 && (
          <View style={{ gap: 10 }}>
            <AccessibleHeading text={placesTitle} level={2} />
            {places.map((p) => (
              <Pressable
                key={p.id}
                onPress={() => {
                  haptic.tap();
                  startRoute(p);
                }}
                accessibilityRole="button"
                accessibilityLabel={`${p.name}${p.distanceM != null ? `, ${formatDistance(p.distanceM, language)}` : ''}`}
                accessibilityHint={t('startNavigation')}
                style={({ pressed }) => [styles.placeRow, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
              >
                <View style={{ flex: 1 }}>
                  <Text style={{ color: colors.text, fontSize: getFontSize(18), fontWeight: '700' }}>{p.name}</Text>
                  {(p.distanceM != null || p.address) && (
                    <Text style={{ color: colors.textSecondary, fontSize: getFontSize(14), marginTop: 2 }}>
                      {[p.distanceM != null ? formatDistance(p.distanceM, language) : null, p.address].filter(Boolean).join(' · ')}
                    </Text>
                  )}
                </View>
                <ChevronRight color={colors.primary} size={26} strokeWidth={2.5} />
              </Pressable>
            ))}
          </View>
        )}

        <AccessibleHeading text={t('findNearby')} level={2} style={{ marginTop: 6 }} />
        <View style={styles.tileGrid}>
          {NEARBY_TILES.map(({ kind, icon: Icon, labelKey }) => (
            <Pressable
              key={kind}
              onPress={() => runNearby(kind)}
              disabled={busy}
              accessibilityRole="button"
              accessibilityLabel={`${t('findNearby')}: ${t(labelKey)}`}
              style={({ pressed }) => [styles.tile, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.7 : busy ? 0.5 : 1 }]}
            >
              <Icon color={colors.primary} size={30} strokeWidth={2.5} />
              <Text style={{ color: colors.text, fontSize: getFontSize(15), fontWeight: '700', textAlign: 'center' }}>{t(labelKey)}</Text>
            </Pressable>
          ))}
        </View>

        {!!status && (
          <Text style={{ color: colors.textSecondary, fontSize: getFontSize(14), lineHeight: 22 }} accessibilityLiveRegion="polite">
            {status}
          </Text>
        )}
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  screen: { padding: 16, paddingBottom: 8 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 18, borderWidth: 1, padding: 8 },
  micBtn: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  input: { flex: 1, paddingVertical: 10, paddingHorizontal: 6, fontWeight: '500' },
  placeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 16, borderRadius: 16, borderWidth: 1, minHeight: 72 },
  tileGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  tile: { width: '31%', flexGrow: 1, minHeight: 96, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center', gap: 6, padding: 8 },
  guideCard: { borderRadius: 20, borderWidth: 2, padding: 20, gap: 10, alignItems: 'center' },
  guideDest: { fontWeight: '600', textAlign: 'center' },
  guideText: { fontWeight: '800', textAlign: 'center', lineHeight: 34 },
  guideSub: { textAlign: 'center', fontWeight: '500' },
  hint: { textAlign: 'center', lineHeight: 20 },
});
