import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Phone, MessageSquareShare, ArrowLeft, Siren } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { ScreenWrapper, AccessibleButton, AccessibleHeading } from '@/components/ui/AccessibleComponents';
import { EMERGENCY_NUMBER, callNumber, textLocation } from '@/services/emergency';
import { haptic } from '@/lib/haptics';

/**
 * Emergency options. Deliberately does NOT dial automatically — an accidental
 * shake or tap must never place a call. Each option is one large button.
 */
export default function SosScreen() {
  const { getColors, getFontSize, language, emergencyName, emergencyPhone } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const router = useRouter();
  const { speak } = useSpeech();
  const lang = language === 'ta' ? 'ta-IN' : 'en-US';
  const [status, setStatus] = useState('');

  const hasContact = emergencyPhone.trim().length >= 5;
  const contactLabel = emergencyName.trim() || emergencyPhone;

  useEffect(() => {
    const intro = hasContact ? t('sosSpoken') : `${t('sosSpoken')} ${t('noContactSet')}`;
    speak(intro, { lang });
  }, []);

  const announce = (msg: string) => {
    setStatus(msg);
    speak(msg, { lang });
  };

  return (
    <ScreenWrapper style={{ backgroundColor: '#450A0A' }}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.titleRow}>
          <Siren color="#FFF" size={40} strokeWidth={2.5} />
          <AccessibleHeading text={t('emergency')} level={1} style={{ color: '#FFF' }} />
        </View>

        <AccessibleButton
          label={t('callEmergency')}
          variant="danger"
          size="extraLarge"
          icon={<Phone color="#FFF" size={30} strokeWidth={2.5} />}
          onPress={async () => {
            haptic.medium();
            if (!(await callNumber(EMERGENCY_NUMBER))) announce(language === 'ta' ? 'அழைப்பைத் தொடங்க முடியவில்லை.' : 'I could not start the call.');
          }}
        />

        {hasContact ? (
          <>
            <AccessibleButton
              label={`${t('call')} ${contactLabel}`}
              variant="primary"
              size="extraLarge"
              icon={<Phone color={colors.primaryText} size={30} strokeWidth={2.5} />}
              onPress={async () => {
                haptic.medium();
                if (!(await callNumber(emergencyPhone))) announce(language === 'ta' ? 'அழைப்பைத் தொடங்க முடியவில்லை.' : 'I could not start the call.');
              }}
            />
            <AccessibleButton
              label={`${t('textLocationTo')} ${contactLabel}`}
              variant="success"
              size="extraLarge"
              icon={<MessageSquareShare color="#000" size={30} strokeWidth={2.5} />}
              onPress={async () => {
                haptic.medium();
                announce(t('gettingLocation'));
                const r = await textLocation(emergencyPhone, emergencyName, language);
                announce(
                  !r.ok
                    ? language === 'ta' ? 'செய்தியைத் திறக்க முடியவில்லை.' : 'I could not open messages.'
                    : language === 'ta'
                    ? 'செய்தி தயார். அனுப்ப "Send" அழுத்தவும்.'
                    : 'Message ready. Press send to deliver it.'
                );
              }}
            />
          </>
        ) : (
          <Text style={[styles.note, { fontSize: getFontSize(16) }]} accessibilityRole="text">
            {t('noContactSet')}
          </Text>
        )}

        {!!status && (
          <Text accessibilityLiveRegion="polite" style={[styles.note, { fontSize: getFontSize(16) }]}>
            {status}
          </Text>
        )}

        <AccessibleButton
          label={t('back')}
          variant="secondary"
          size="large"
          icon={<ArrowLeft color={colors.text} size={26} strokeWidth={2.5} />}
          onPress={() => router.back()}
        />
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  content: { gap: 16, paddingTop: 40, paddingBottom: 30 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  note: { color: '#FECACA', lineHeight: 24, fontWeight: '600' },
});
