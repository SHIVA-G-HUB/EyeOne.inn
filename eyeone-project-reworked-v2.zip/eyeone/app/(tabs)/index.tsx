import { Redirect } from 'expo-router';

/** Eyo is the home screen; the old menu is replaced by the one-tap tiles on that screen. */
export default function Index() {
  return <Redirect href="/(tabs)/assistant" />;
}
