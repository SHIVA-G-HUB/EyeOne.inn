import { useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import { Accelerometer } from 'expo-sensors';

interface ShakeOptions {
  /** Web: change in m/s² between readings. */
  threshold?: number;
  /** Native: change in m/s² between readings (sampled every 100ms, so needs a firmer shake than web). */
  nativeThreshold?: number;
  /** Minimum ms between two shakes. */
  interval?: number;
  /** Turn shake detection on/off (the Settings toggle). Default true. */
  enabled?: boolean;
  onShake: () => void;
}

const G = 9.81;

/**
 * Opens the assistant when the phone is shaken.
 * - Native: expo-sensors Accelerometer (works while the app is in the foreground).
 * - Web: DeviceMotion; iOS Safari needs a one-time tap to grant motion permission.
 */
export function useShakeToOpen({ threshold = 3, nativeThreshold = 14, interval = 1000, enabled = true, onShake }: ShakeOptions) {
  const lastShakeRef = useRef(0);
  const lastRef = useRef<{ x: number; y: number; z: number } | null>(null);
  const onShakeRef = useRef(onShake);
  onShakeRef.current = onShake;

  useEffect(() => {
    if (!enabled) return;
    lastRef.current = null;
    const limit = Platform.OS === 'web' ? threshold : nativeThreshold;
    const handleReading = (x: number, y: number, z: number) => {
      const last = lastRef.current;
      lastRef.current = { x, y, z };
      if (!last) return;
      const now = Date.now();
      if (now - lastShakeRef.current < interval) return;
      const delta = Math.hypot(x - last.x, y - last.y, z - last.z);
      if (delta > limit) {
        lastShakeRef.current = now;
        onShakeRef.current();
      }
    };

    if (Platform.OS === 'web') {
      if (typeof window === 'undefined' || !(window as any).DeviceMotionEvent) return;

      const onMotion = (e: DeviceMotionEvent) => {
        const a = e.accelerationIncludingGravity;
        if (a) handleReading(a.x ?? 0, a.y ?? 0, a.z ?? 0);
      };

      let attached = false;
      const attach = () => {
        if (attached) return;
        attached = true;
        window.addEventListener('devicemotion', onMotion);
      };

      const DME = (window as any).DeviceMotionEvent;
      let unlock: (() => void) | undefined;
      if (typeof DME.requestPermission === 'function') {
        // iOS Safari: permission must be requested from a user gesture.
        unlock = () => {
          DME.requestPermission()
            .then((state: string) => state === 'granted' && attach())
            .catch(() => {});
          window.removeEventListener('click', unlock!);
        };
        window.addEventListener('click', unlock);
      } else {
        attach();
      }

      return () => {
        window.removeEventListener('devicemotion', onMotion);
        if (unlock) window.removeEventListener('click', unlock);
      };
    }

    Accelerometer.setUpdateInterval(100);
    const sub = Accelerometer.addListener(({ x, y, z }) => handleReading(x * G, y * G, z * G));
    return () => sub.remove();
  }, [threshold, nativeThreshold, interval, enabled]);
}
