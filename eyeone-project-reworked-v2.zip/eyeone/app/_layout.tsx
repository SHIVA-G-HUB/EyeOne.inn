import { Stack, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Platform } from 'react-native';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { AccessibilityProvider, useAccessibility } from '@/contexts/AccessibilityContext';
import { useShakeToOpen } from '@/hooks/useShakeToOpen';
import { haptic } from '@/lib/haptics';

/**
 * Shake the phone (app open) to jump to Eyo and start listening.
 * Lives inside the provider so it can honour the Settings toggle.
 */
function ShakeListener() {
  const { shakeToOpen } = useAccessibility();
  const router = useRouter();

  useShakeToOpen({
    enabled: shakeToOpen,
    threshold: 3.5,
    nativeThreshold: 14,
    interval: 2000,
    onShake: () => {
      haptic.medium();
      router.navigate({ pathname: '/(tabs)/assistant', params: { listen: String(Date.now()) } });
    },
  });
  return null;
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <AccessibilityProvider>
      <ShakeListener />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="sos" options={{ presentation: 'modal', animation: Platform.OS === 'web' ? 'none' : 'slide_from_bottom' }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="light" />
    </AccessibilityProvider>
  );
}
