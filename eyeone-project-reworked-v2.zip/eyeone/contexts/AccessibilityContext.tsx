import React, { createContext, useContext, useEffect, useMemo, useState, ReactNode } from 'react';
import { getJSON, setJSON } from '@/lib/storage';
import { setHapticsEnabled } from '@/lib/haptics';

export type TextSize = 'small' | 'medium' | 'large' | 'extraLarge';
export type ContrastMode = 'normal' | 'high' | 'max';
export type MotionMode = 'normal' | 'reduced';
export type SpeechSpeed = 'slow' | 'normal' | 'fast';
export type AppLanguage = 'en' | 'ta';

interface AccessibilityState {
  textSize: TextSize;
  contrast: ContrastMode;
  motion: MotionMode;
  speechSpeed: SpeechSpeed;
  language: AppLanguage;
  voiceEnabled: boolean;
  hapticsEnabled: boolean;
  shakeToOpen: boolean;
  handsFree: boolean;
  emergencyName: string;
  emergencyPhone: string;
}

interface AccessibilityContextType extends AccessibilityState {
  setTextSize: (size: TextSize) => void;
  setContrast: (mode: ContrastMode) => void;
  setMotion: (mode: MotionMode) => void;
  setSpeechSpeed: (speed: SpeechSpeed) => void;
  setLanguage: (lang: AppLanguage) => void;
  setVoiceEnabled: (enabled: boolean) => void;
  setHapticsEnabled: (enabled: boolean) => void;
  setShakeToOpen: (enabled: boolean) => void;
  setHandsFree: (enabled: boolean) => void;
  setEmergencyContact: (name: string, phone: string) => void;
  getSpeechRate: () => number;
  getFontSize: (base: number) => number;
  getColors: () => ColorScheme;
}

interface ColorScheme {
  background: string;
  surface: string;
  surfaceAlt: string;
  text: string;
  textSecondary: string;
  primary: string;
  primaryText: string;
  accent: string;
  border: string;
  error: string;
  success: string;
  warning: string;
}

const defaultColors: ColorScheme = {
  background: '#0F172A',
  surface: '#1E293B',
  surfaceAlt: '#334155',
  text: '#F8FAFC',
  textSecondary: '#CBD5E1',
  primary: '#3B82F6',
  primaryText: '#FFFFFF',
  accent: '#10B981',
  border: '#475569',
  error: '#EF4444',
  success: '#22C55E',
  warning: '#F59E0B',
};

const highContrastColors: ColorScheme = {
  background: '#000000',
  surface: '#1A1A1A',
  surfaceAlt: '#333333',
  text: '#FFFFFF',
  textSecondary: '#E0E0E0',
  primary: '#66CCFF',
  primaryText: '#000000',
  accent: '#00FF99',
  border: '#666666',
  error: '#FF6B6B',
  success: '#00FF66',
  warning: '#FFCC00',
};

const maxContrastColors: ColorScheme = {
  background: '#000000',
  surface: '#000000',
  surfaceAlt: '#FFFFFF',
  text: '#FFFFFF',
  textSecondary: '#FFFFFF',
  primary: '#FFFF00',
  primaryText: '#000000',
  accent: '#00FF00',
  border: '#FFFFFF',
  error: '#FF0000',
  success: '#00FF00',
  warning: '#FFFF00',
};

const textSizeMap: Record<TextSize, number> = {
  small: 0.85,
  medium: 1,
  large: 1.25,
  extraLarge: 1.55,
};

const speechRateMap: Record<SpeechSpeed, number> = {
  slow: 0.7,
  normal: 1,
  fast: 1.5,
};

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

const STORAGE_KEY = 'accessibility_settings';

const defaultState: AccessibilityState = {
  textSize: 'large',
  contrast: 'normal',
  motion: 'normal',
  speechSpeed: 'normal',
  language: 'en',
  voiceEnabled: true,
  hapticsEnabled: true,
  shakeToOpen: true,
  handsFree: false,
  emergencyName: '',
  emergencyPhone: '',
};

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AccessibilityState>(defaultState);
  const [hydrated, setHydrated] = useState(false);

  // Load saved settings on both web and native, merged over defaults so new
  // settings added in later versions never come back undefined.
  useEffect(() => {
    let cancelled = false;
    getJSON<Partial<AccessibilityState>>(STORAGE_KEY, {}).then((saved) => {
      if (cancelled) return;
      const merged = { ...defaultState, ...saved };
      setState(merged);
      setHapticsEnabled(merged.hapticsEnabled);
      setHydrated(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const value = useMemo<AccessibilityContextType>(() => {
    const updateState = (partial: Partial<AccessibilityState>) => {
      setState((prev) => {
        const next = { ...prev, ...partial };
        setJSON(STORAGE_KEY, next);
        if (partial.hapticsEnabled !== undefined) setHapticsEnabled(partial.hapticsEnabled);
        return next;
      });
    };

    const colors =
      state.contrast === 'high' ? highContrastColors : state.contrast === 'max' ? maxContrastColors : defaultColors;

    return {
      ...state,
      setTextSize: (textSize) => updateState({ textSize }),
      setContrast: (contrast) => updateState({ contrast }),
      setMotion: (motion) => updateState({ motion }),
      setSpeechSpeed: (speechSpeed) => updateState({ speechSpeed }),
      setLanguage: (language) => updateState({ language }),
      setVoiceEnabled: (voiceEnabled) => updateState({ voiceEnabled }),
      setHapticsEnabled: (hapticsEnabled) => updateState({ hapticsEnabled }),
      setShakeToOpen: (shakeToOpen) => updateState({ shakeToOpen }),
      setHandsFree: (handsFree) => updateState({ handsFree }),
      setEmergencyContact: (emergencyName, emergencyPhone) => updateState({ emergencyName, emergencyPhone }),
      getSpeechRate: () => speechRateMap[state.speechSpeed],
      getFontSize: (base: number) => Math.round(base * textSizeMap[state.textSize]),
      getColors: () => colors,
    };
  }, [state]);

  // Wait for saved settings (a few milliseconds) so the app never flashes the wrong theme or language.
  if (!hydrated) return null;

  return <AccessibilityContext.Provider value={value}>{children}</AccessibilityContext.Provider>;
}

export function useAccessibility() {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    throw new Error('useAccessibility must be used within AccessibilityProvider');
  }
  return ctx;
}

export { defaultColors };
