import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { ScreenWrapper, AccessibleHeading } from '@/components/ui/AccessibleComponents';
import { Keyboard, Mic, MessageCircle, Navigation, Eye, ShieldCheck } from 'lucide-react-native';

export default function HelpScreen() {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);

  const keyboardControls = [
    { key: 'Tab', desc: language === 'ta' ? 'முன்னோக்கி நகர்த்தி' : 'Move forward' },
    { key: 'Shift + Tab', desc: language === 'ta' ? 'பின்னோக்கி நகர்த்தி' : 'Move backward' },
    { key: 'Enter', desc: language === 'ta' ? 'செயல்படுத்து' : 'Activate' },
    { key: 'Space', desc: language === 'ta' ? 'பொத்தான்களை செயல்படுத்து' : 'Activate buttons' },
    { key: 'Escape', desc: language === 'ta' ? 'உரையாடல்களை மூடு' : 'Close dialogs' },
    { key: 'Arrow Keys', desc: language === 'ta' ? 'பட்டியல்களில் உலாவு' : 'Navigate lists' },
  ];

  const voiceCommands = [
    { cmd: language === 'ta' ? '"எதிரில் என்ன இருக்கிறது?"' : '"What is in front of me?"', desc: language === 'ta' ? 'கேமரா காட்சியை விவரிக்கும்' : 'Camera describes the scene' },
    { cmd: language === 'ta' ? '"இதைப் படி"' : '"Read this"', desc: language === 'ta' ? 'அடையாளம், லேபிள், மெனுவைப் படிக்கும்' : 'Reads signs, labels, menus' },
    { cmd: language === 'ta' ? '"இந்த நோட்டு எவ்வளவு?"' : '"How much money is this?"', desc: language === 'ta' ? 'ரூபாய் நோட்டை அடையாளம் காணும்' : 'Identifies rupee notes' },
    { cmd: language === 'ta' ? '"இது என்ன நிறம்?"' : '"What colour is this?"', desc: language === 'ta' ? 'நிறத்தைச் சொல்லும்' : 'Names the colour' },
    { cmd: language === 'ta' ? '"நான் எங்கே இருக்கிறேன்?"' : '"Where am I?"', desc: language === 'ta' ? 'உங்கள் இடத்தைச் சொல்லும்' : 'Says your street and area' },
    { cmd: language === 'ta' ? '"அருகில் மருத்துவமனை"' : '"Find a pharmacy near me"', desc: language === 'ta' ? 'அருகிலுள்ள இடங்களைச் சொல்லும்' : 'Lists places nearby with direction' },
    { cmd: language === 'ta' ? '"சென்ட்ரல் ரயில் நிலையத்துக்கு வழி"' : '"Take me to Chennai Central"', desc: language === 'ta' ? 'நடைவழிகாட்டுதலைத் தொடங்கும்' : 'Starts walking directions' },
    { cmd: language === 'ta' ? '"மருத்துவச் செய்திகள்"' : '"Read medical news"', desc: language === 'ta' ? 'செய்திகளைப் படிக்கும்' : 'Reads live headlines' },
    { cmd: language === 'ta' ? '"அவசரம்"' : '"Emergency"', desc: language === 'ta' ? 'அவசர வழிகளைத் திறக்கும்' : 'Opens emergency options' },
  ];

  const aiCommands = [
    { cmd: language === 'ta' ? '"வங்கிக் காசோலை என்றால் என்ன?"' : '"Explain what a bank cheque is"', desc: language === 'ta' ? 'எதையும் கேட்கலாம்' : 'Ask Eyo anything' },
    { cmd: language === 'ta' ? '"அந்த நோட்டு எவ்வளவு என்றாய்?"' : '"What was that note again?"', desc: language === 'ta' ? 'கடைசிப் படம் பற்றிக் கேட்கலாம்' : 'Follow up on the last photo' },
    { cmd: language === 'ta' ? 'கைகளின்றி உரையாடல்' : 'Hands-free chat button', desc: language === 'ta' ? 'Eyo பேசி முடிந்ததும் தானாகக் கேட்கும்' : 'Eyo listens again after each answer' },
    { cmd: language === 'ta' ? 'தொலைபேசியைக் குலுக்கு' : 'Shake the phone', desc: language === 'ta' ? 'செயலி திறந்திருக்கும்போது Eyo கேட்கத் தொடங்கும்' : 'With the app open, Eyo starts listening' },
  ];

  const navInstructions = [
    language === 'ta' ? 'வழிகாட்டி தாவலைத் திறக்கவும் அல்லது Eyo-விடம் "…க்கு வழி" என்று சொல்லவும்.' : 'Open the Navigation tab, or tell Eyo "Take me to ...".',
    language === 'ta' ? 'மைக்கைத் தட்டி இடத்தின் பெயரைச் சொல்லவும்.' : 'Tap the microphone and say the place name.',
    language === 'ta' ? 'நடைவழிகாட்டுதல் தொடங்கும். ஒவ்வொரு திருப்பத்திற்கும் முன் குரல் மற்றும் அதிர்வு வரும்.' : 'Walking directions start. You get a voice prompt and vibration before each turn.',
    language === 'ta' ? 'வழி தவறினால் புதிய வழியைத் தானாகத் தேடும்.' : 'If you leave the route, it finds a new one automatically.',
    language === 'ta' ? 'GPS 10 முதல் 20 மீட்டர் தவறலாம். வெள்ளைக் கோல் அல்லது வழிகாட்டி நாயைத் தொடர்ந்து பயன்படுத்துங்கள்.' : 'GPS can be off by 10 to 20 metres. Keep using your cane or guide dog.',
  ];

  const visionInstructions = [
    language === 'ta' ? 'பார் தாவலைத் திறக்கவும்.' : 'Open the See tab.',
    language === 'ta' ? 'காட்சி, உரை, ஆவணம், நோட்டு, நிறம், பொருள் என ஒரு முறையைத் தேர்வு செய்யவும்.' : 'Choose a mode: Describe, Read text, Document, Currency, Colour or Product.',
    language === 'ta' ? 'திரையில் எங்கு வேண்டுமானாலும் இருமுறை தட்டினால் படம் எடுக்கும்.' : 'Double tap anywhere on the preview to take the photo.',
    language === 'ta' ? 'Eyo முடிவைச் சத்தமாகப் படிக்கும். மீண்டும் கேட்க "மீண்டும் சொல்" அழுத்தவும்.' : 'Eyo reads the result aloud. Press Repeat to hear it again.',
    language === 'ta' ? '"இந்தப் படம் பற்றி கேள்" அழுத்தி கூடுதல் கேள்வி கேட்கலாம்.' : 'Press Ask about this photo to ask a follow-up question.',
    language === 'ta' ? 'இருட்டில் விளக்கை இயக்கவும்.' : 'In the dark, turn the light on.',
  ];

  const Section = ({ icon, title, items, isCommandList }: any) => (
    <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.sectionHeader}>
        {icon}
        <Text style={[styles.sectionTitle, { color: colors.text, fontSize: getFontSize(20) }]}>{title}</Text>
      </View>
      {items.map((item: any, i: number) => (
        <View
          key={i}
          style={[styles.itemRow, i < items.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
          accessibilityRole="summary"
          accessibilityLabel={isCommandList ? `${item.cmd}: ${item.desc}` : `${item.key}: ${item.desc}`}
        >
          {isCommandList ? (
            <>
              <Text style={[styles.commandText, { color: colors.accent, fontSize: getFontSize(15) }]}>
                {item.cmd}
              </Text>
              <Text style={[styles.commandDesc, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
                {item.desc}
              </Text>
            </>
          ) : (
            <>
              <View style={[styles.keyBadge, { backgroundColor: colors.surfaceAlt }]}>
                <Text style={[styles.keyText, { color: colors.text, fontSize: getFontSize(14) }]}>
                  {item.key}
                </Text>
              </View>
              <Text style={[styles.keyDesc, { color: colors.textSecondary, fontSize: getFontSize(15) }]}>
                {item.desc}
              </Text>
            </>
          )}
        </View>
      ))}
    </View>
  );

  return (
    <ScreenWrapper>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={[styles.headerIcon, { backgroundColor: colors.primary }]}>
            <Eye color={colors.primaryText} size={28} strokeWidth={2.5} />
          </View>
          <AccessibleHeading text={t('howToUse')} level={1} />
          <Text style={[styles.subtitle, { color: colors.textSecondary, fontSize: getFontSize(16) }]}>
            {t('aboutDescription')}
          </Text>
        </View>

        <Section
          icon={<Keyboard color={colors.primary} size={24} strokeWidth={2.5} />}
          title={t('keyboardInstructions')}
          items={keyboardControls}
        />

        <Section
          icon={<Mic color={colors.accent} size={24} strokeWidth={2.5} />}
          title={t('voiceInstructions')}
          items={voiceCommands}
          isCommandList
        />

        <Section
          icon={<MessageCircle color={colors.primary} size={24} strokeWidth={2.5} />}
          title={t('aiInstructions')}
          items={aiCommands}
          isCommandList
        />

        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Eye color={colors.accent} size={24} strokeWidth={2.5} />
            <Text accessibilityRole="header" style={[styles.sectionTitle, { color: colors.text, fontSize: getFontSize(20) }]}>
              {t('helpVision')}
            </Text>
          </View>
          {visionInstructions.map((inst, i) => (
            <View
              key={i}
              style={[styles.stepRow, i < visionInstructions.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
              accessibilityLabel={`Step ${i + 1}: ${inst}`}
            >
              <View style={[styles.stepBadge, { backgroundColor: colors.primary }]}>
                <Text style={[styles.stepBadgeText, { color: colors.primaryText }]}>{i + 1}</Text>
              </View>
              <Text style={[styles.stepText, { color: colors.text, fontSize: getFontSize(15) }]}>{inst}</Text>
            </View>
          ))}
        </View>

        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Navigation color={colors.accent} size={24} strokeWidth={2.5} />
            <Text style={[styles.sectionTitle, { color: colors.text, fontSize: getFontSize(20) }]}>
              {t('navigationInstructions')}
            </Text>
          </View>
          {navInstructions.map((inst, i) => (
            <View
              key={i}
              style={[styles.stepRow, i < navInstructions.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
              role="listitem"
              accessibilityLabel={`Step ${i + 1}: ${inst}`}
            >
              <View style={[styles.stepBadge, { backgroundColor: colors.primary }]}>
                <Text style={[styles.stepBadgeText, { color: colors.primaryText }]}>{i + 1}</Text>
              </View>
              <Text style={[styles.stepText, { color: colors.text, fontSize: getFontSize(15) }]}>
                {inst}
              </Text>
            </View>
          ))}
        </View>

        <View style={[styles.shakeCard, { backgroundColor: colors.surface, borderColor: colors.accent }]}>
          <View style={[styles.shakeIcon, { backgroundColor: colors.accent }]}>
            <Eye color="#000" size={24} strokeWidth={2.5} />
          </View>
          <View style={styles.shakeContent}>
            <Text style={[styles.shakeTitle, { color: colors.text, fontSize: getFontSize(18) }]}>
              {t('shakeToOpen')}
            </Text>
            <Text style={[styles.shakeDesc, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
              {language === 'ta'
                ? 'ஃபோனை குலுக்கி எப்போதும் AI உதவியாளரை திறக்கலாம்.'
                : 'Shake your phone anytime to instantly open the AI assistant.'}
            </Text>
          </View>
        </View>

        <View style={[styles.privacyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <ShieldCheck color={colors.accent} size={24} strokeWidth={2.5} />
            <Text style={[styles.sectionTitle, { color: colors.text, fontSize: getFontSize(20) }]}>
              {t('privacyNotice')}
            </Text>
          </View>
          <Text style={[styles.privacyText, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
            {t('privacyDescription')}
          </Text>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  scrollContent: { paddingBottom: 20 },
  header: { alignItems: 'center', marginBottom: 24, paddingTop: 10 },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  subtitle: {
    textAlign: 'center',
    lineHeight: 22,
    fontWeight: '500',
    marginTop: 6,
  },
  section: {
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 14,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
  },
  sectionTitle: { fontWeight: '800' },
  itemRow: {
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  keyBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    minWidth: 100,
    alignItems: 'center',
  },
  keyText: { fontWeight: '700' },
  keyDesc: { flex: 1, fontWeight: '500' },
  commandText: { fontWeight: '700', flex: 1 },
  commandDesc: { flex: 1, fontWeight: '500', textAlign: 'right' },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 12,
  },
  stepBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBadgeText: { fontWeight: '800', fontSize: 13 },
  stepText: { flex: 1, fontWeight: '500', lineHeight: 22 },
  shakeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 18,
    borderRadius: 16,
    borderWidth: 2,
    marginBottom: 14,
    gap: 14,
  },
  shakeIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  shakeContent: { flex: 1 },
  shakeTitle: { fontWeight: '800', marginBottom: 4 },
  shakeDesc: { lineHeight: 20, fontWeight: '500' },
  privacyCard: {
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 14,
  },
  privacyText: { lineHeight: 22, fontWeight: '500' },
});
