import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

let enabled = true;

/** Kept in sync with the "Vibration feedback" setting by AccessibilityProvider. */
export function setHapticsEnabled(value: boolean) {
  enabled = value;
}

const run = (fn: () => Promise<void>) => {
  if (!enabled || Platform.OS === 'web') return;
  fn().catch(() => {});
};

export const haptic = {
  /** Light tap: selection changed, button pressed. */
  tap: () => run(() => Haptics.selectionAsync()),
  /** Photo taken, action started. */
  medium: () => run(() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)),
  /** Result ready / task done. */
  success: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)),
  /** Something went wrong. */
  error: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)),
  /** Turn coming up while walking. */
  warning: () => run(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)),
};
