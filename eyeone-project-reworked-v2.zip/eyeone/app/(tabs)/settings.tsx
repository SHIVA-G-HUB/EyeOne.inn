import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { useAccessibility, TextSize, ContrastMode, MotionMode, SpeechSpeed, AppLanguage } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { ScreenWrapper, AccessibleHeading } from '@/components/ui/AccessibleComponents';
import { Type, Contrast, EyeOff, Gauge, Volume2, Globe, Check, Vibrate, Smartphone, Siren, HelpCircle } from 'lucide-react-native';
import { AccessibleButton } from '@/components/ui/AccessibleComponents';

export default function SettingsScreen() {
  const { getColors, getFontSize, textSize, contrast, motion, speechSpeed, language, voiceEnabled,
    setTextSize, setContrast, setMotion, setSpeechSpeed, setLanguage, setVoiceEnabled,
    hapticsEnabled, setHapticsEnabled, shakeToOpen, setShakeToOpen, emergencyName, emergencyPhone, setEmergencyContact } = useAccessibility();
  const router = useRouter();
  const [nameDraft, setNameDraft] = useState(emergencyName);
  const [phoneDraft, setPhoneDraft] = useState(emergencyPhone);
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const { speak, isSupported } = useSpeech();

  const announceChange = (msg: string) => {
    if (voiceEnabled && isSupported()) {
      speak(msg, { lang: language === 'ta' ? 'ta-IN' : 'en-US' });
    }
  };

  const textSizes: { key: TextSize; label: string }[] = [
    { key: 'small', label: t('small') },
    { key: 'medium', label: t('medium') },
    { key: 'large', label: t('large') },
    { key: 'extraLarge', label: t('extraLarge') },
  ];

  const contrastModes: { key: ContrastMode; label: string }[] = [
    { key: 'normal', label: t('normal') },
    { key: 'high', label: t('highContrast') },
    { key: 'max', label: t('maxContrast') },
  ];

  const motionModes: { key: MotionMode; label: string }[] = [
    { key: 'normal', label: t('normal') },
    { key: 'reduced', label: t('reducedMotion') },
  ];

  const speechSpeeds: { key: SpeechSpeed; label: string }[] = [
    { key: 'slow', label: t('slow') },
    { key: 'normal', label: t('normal') },
    { key: 'fast', label: t('fast') },
  ];

  const languages: { key: AppLanguage; label: string }[] = [
    { key: 'en', label: t('english') },
    { key: 'ta', label: t('tamil') },
  ];

  const renderToggle = (title: string, icon: React.ReactNode, value: boolean, onChange: (v: boolean) => void) => (
    <View style={[styles.settingGroup, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.settingHeader}>
        {icon}
        <Text style={[styles.settingTitle, { color: colors.text, fontSize: getFontSize(18) }]}>{title}</Text>
      </View>
      <View style={styles.optionsRow}>
        {[true, false].map((v) => {
          const selected = value === v;
          const label = v ? t('on') : t('off');
          return (
            <Pressable
              key={String(v)}
              onPress={() => {
                onChange(v);
                announceChange(`${title}: ${label}`);
              }}
              accessibilityRole="radio"
              accessibilityLabel={`${title} ${label}`}
              accessibilityState={{ selected }}
              style={({ pressed }) => [
                styles.optionChip,
                {
                  backgroundColor: selected ? (v ? colors.accent : colors.primary) : colors.surfaceAlt,
                  borderColor: selected ? (v ? colors.accent : colors.primary) : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.optionText, { color: selected ? (v ? '#000' : colors.primaryText) : colors.text, fontSize: getFontSize(14) }]}>{label}</Text>
              {selected && <Check color={v ? '#000' : colors.primaryText} size={16} strokeWidth={3} />}
            </Pressable>
          );
        })}
      </View>
    </View>
  );

  const saveContact = () => {
    setEmergencyContact(nameDraft.trim(), phoneDraft.trim());
    announceChange(phoneDraft.trim() ? `${t('emergencyContact')}: ${t('saved')}` : t('noContactSet'));
  };

  const renderOptionGroup = (
    title: string,
    icon: React.ReactNode,
    options: { key: string; label: string }[],
    current: string,
    onSelect: (key: string) => void
  ) => (
    <View style={[styles.settingGroup, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.settingHeader}>
        {icon}
        <Text style={[styles.settingTitle, { color: colors.text, fontSize: getFontSize(18) }]}>{title}</Text>
      </View>
      <View style={styles.optionsRow}>
        {options.map((opt) => {
          const isSelected = current === opt.key;
          return (
            <Pressable
              key={opt.key}
              onPress={() => {
                onSelect(opt.key);
                announceChange(`${title}: ${opt.label}`);
              }}
              accessibilityRole="radio"
              accessibilityLabel={opt.label}
              accessibilityState={{ selected: isSelected }}
              style={({ pressed }) => [
                styles.optionChip,
                {
                  backgroundColor: isSelected ? colors.primary : colors.surfaceAlt,
                  borderColor: isSelected ? colors.primary : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text
                style={[
                  styles.optionText,
                  { color: isSelected ? colors.primaryText : colors.text, fontSize: getFontSize(14) },
                ]}
              >
                {opt.label}
              </Text>
              {isSelected && <Check color={colors.primaryText} size={16} strokeWidth={3} />}
            </Pressable>
          );
        })}
      </View>
    </View>
  );

  return (
    <ScreenWrapper>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <AccessibleHeading text={t('settings')} level={1} style={styles.pageTitle} />

        {renderOptionGroup(t('language'), <Globe color={colors.accent} size={22} strokeWidth={2.5} />,
          languages, language, (k) => setLanguage(k as AppLanguage))}

        {renderOptionGroup(t('textSize'), <Type color={colors.primary} size={22} strokeWidth={2.5} />,
          textSizes, textSize, (k) => setTextSize(k as TextSize))}

        {renderOptionGroup(t('contrast'), <Contrast color={colors.primary} size={22} strokeWidth={2.5} />,
          contrastModes, contrast, (k) => setContrast(k as ContrastMode))}

        {renderOptionGroup(t('motion'), <EyeOff color={colors.accent} size={22} strokeWidth={2.5} />,
          motionModes, motion, (k) => setMotion(k as MotionMode))}

        {renderOptionGroup(t('speechSpeed'), <Gauge color={colors.primary} size={22} strokeWidth={2.5} />,
          speechSpeeds, speechSpeed, (k) => setSpeechSpeed(k as SpeechSpeed))}

        <View style={[styles.settingGroup, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.settingHeader}>
            <Volume2 color={colors.accent} size={22} strokeWidth={2.5} />
            <Text style={[styles.settingTitle, { color: colors.text, fontSize: getFontSize(18) }]}>{t('voice')}</Text>
          </View>
          <View style={styles.optionsRow}>
            <Pressable
              onPress={() => {
                setVoiceEnabled(true);
                announceChange(`${t('voice')}: ${t('on')}`);
              }}
              accessibilityRole="radio"
              accessibilityLabel={`${t('voice')} ${t('on')}`}
              accessibilityState={{ selected: voiceEnabled }}
              style={({ pressed }) => [
                styles.optionChip,
                {
                  backgroundColor: voiceEnabled ? colors.accent : colors.surfaceAlt,
                  borderColor: voiceEnabled ? colors.accent : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.optionText, { color: voiceEnabled ? '#000' : colors.text, fontSize: getFontSize(14) }]}>
                {t('on')}
              </Text>
              {voiceEnabled && <Check color="#000" size={16} strokeWidth={3} />}
            </Pressable>
            <Pressable
              onPress={() => {
                setVoiceEnabled(false);
                announceChange(`${t('voice')}: ${t('off')}`);
              }}
              accessibilityRole="radio"
              accessibilityLabel={`${t('voice')} ${t('off')}`}
              accessibilityState={{ selected: !voiceEnabled }}
              style={({ pressed }) => [
                styles.optionChip,
                {
                  backgroundColor: !voiceEnabled ? colors.surfaceAlt : colors.surfaceAlt,
                  borderColor: !voiceEnabled ? colors.border : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.optionText, { color: colors.text, fontSize: getFontSize(14) }]}>{t('off')}</Text>
              {!voiceEnabled && <Check color={colors.text} size={16} strokeWidth={3} />}
            </Pressable>
          </View>
        </View>

        {renderToggle(t('shakeToOpen'), <Smartphone color={colors.accent} size={22} strokeWidth={2.5} />, shakeToOpen, setShakeToOpen)}

        {renderToggle(t('haptics'), <Vibrate color={colors.primary} size={22} strokeWidth={2.5} />, hapticsEnabled, setHapticsEnabled)}

        <View style={[styles.settingGroup, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.settingHeader}>
            <Siren color={colors.error} size={22} strokeWidth={2.5} />
            <Text accessibilityRole="header" style={[styles.settingTitle, { color: colors.text, fontSize: getFontSize(18) }]}>{t('emergencyContact')}</Text>
          </View>
          <TextInput
            value={nameDraft}
            onChangeText={setNameDraft}
            placeholder={t('contactName')}
            placeholderTextColor={colors.textSecondary}
            accessibilityLabel={t('contactName')}
            style={[styles.field, { color: colors.text, borderColor: colors.border, backgroundColor: colors.surfaceAlt, fontSize: getFontSize(16) }]}
          />
          <TextInput
            value={phoneDraft}
            onChangeText={setPhoneDraft}
            placeholder={t('contactPhone')}
            placeholderTextColor={colors.textSecondary}
            accessibilityLabel={t('contactPhone')}
            keyboardType="phone-pad"
            autoComplete="tel"
            style={[styles.field, { color: colors.text, borderColor: colors.border, backgroundColor: colors.surfaceAlt, fontSize: getFontSize(16) }]}
          />
          <AccessibleButton label={t('save')} onPress={saveContact} variant="success" size="medium" />
        </View>

        <AccessibleButton
          label={t('help')}
          variant="secondary"
          size="large"
          icon={<HelpCircle color={colors.text} size={24} strokeWidth={2.5} />}
          onPress={() => router.push('/(tabs)/help')}
          style={{ marginBottom: 12 }}
        />

        <View style={[styles.aboutCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.aboutTitle, { color: colors.text, fontSize: getFontSize(16) }]}>{t('aboutApp')}</Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
            {t('aboutDescription')}
          </Text>
          <View style={[styles.privacySection, { borderTopColor: colors.border }]}>
            <Text style={[styles.aboutTitle, { color: colors.text, fontSize: getFontSize(16) }]}>{t('privacyNotice')}</Text>
            <Text style={[styles.aboutText, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
              {t('privacyDescription')}
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  field: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 10, fontWeight: '500' },
  scrollContent: { paddingBottom: 20 },
  pageTitle: { marginBottom: 16 },
  settingGroup: {
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    marginBottom: 12,
  },
  settingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },
  settingTitle: { fontWeight: '700' },
  optionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  optionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  optionText: { fontWeight: '700' },
  aboutCard: {
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    marginTop: 8,
  },
  aboutTitle: { fontWeight: '700', marginBottom: 6 },
  aboutText: { lineHeight: 22, fontWeight: '500' },
  privacySection: {
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
  },
});
