/**
 * In-memory "what just happened" shared between screens, so Eyo can answer
 * follow-ups like "what was that note again?" after the camera described something.
 */
interface VisionMemory {
  mode: string;
  text: string;
  at: number;
}

let lastVision: VisionMemory | null = null;

export function rememberVision(mode: string, text: string) {
  lastVision = { mode, text, at: Date.now() };
}

/** Returns the last camera result if it is recent enough to still be relevant. */
export function recentVision(maxAgeMs = 15 * 60 * 1000): VisionMemory | null {
  if (!lastVision) return null;
  return Date.now() - lastVision.at <= maxAgeMs ? lastVision : null;
}
