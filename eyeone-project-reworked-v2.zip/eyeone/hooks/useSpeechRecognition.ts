import { useState, useCallback, useRef, useEffect } from 'react';
import { Platform } from 'react-native';

interface SpeechRecognitionResult {
  transcript: string;
  confidence: number;
}

interface UseSpeechRecognitionOptions {
  lang?: string;
  continuous?: boolean;
  interimResults?: boolean;
  onResult?: (result: SpeechRecognitionResult) => void;
  onError?: (error: string) => void;
  onEnd?: () => void;
}

/**
 * Native speech recognition comes from `expo-speech-recognition`, which needs a
 * development build (it is not in Expo Go). It is loaded defensively so the app
 * still runs in Expo Go — there, `isSupported()` is simply false and the typed
 * input stays available.
 */
let NativeSR: any = null;
if (Platform.OS !== 'web') {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    NativeSR = require('expo-speech-recognition').ExpoSpeechRecognitionModule ?? null;
  } catch {
    NativeSR = null;
  }
}

const friendlyError = (code?: string): string => {
  switch (code) {
    case 'no-speech':
      return 'No speech detected. Please try again.';
    case 'audio-capture':
      return 'Microphone not available. Please check your device.';
    case 'not-allowed':
    case 'service-not-allowed':
      return 'Microphone permission denied. Please allow microphone access.';
    case 'network':
      return 'Network error during speech recognition.';
    case 'language-not-supported':
      return 'This language is not supported for voice input on this device.';
    case 'aborted':
      return 'Speech recognition was stopped.';
    default:
      return 'Speech recognition error.';
  }
};

export function useSpeechRecognition(options?: UseSpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Always call the latest callbacks without recreating start()/stop().
  const optionsRef = useRef(options);
  optionsRef.current = options;

  const isSupported = useCallback(() => {
    if (Platform.OS === 'web') {
      if (typeof window === 'undefined') return false;
      return !!(window as any).SpeechRecognition || !!(window as any).webkitSpeechRecognition;
    }
    return !!NativeSR;
  }, []);

  const fail = useCallback((code?: string) => {
    const msg = friendlyError(code);
    setError(msg);
    setIsListening(false);
    optionsRef.current?.onError?.(msg);
  }, []);

  // Native event wiring (once).
  useEffect(() => {
    if (Platform.OS === 'web' || !NativeSR) return;
    const subs = [
      NativeSR.addListener('result', (e: any) => {
        const best = e?.results?.[0];
        if (!best) return;
        setTranscript(best.transcript ?? '');
        if (e.isFinal && best.transcript) {
          optionsRef.current?.onResult?.({ transcript: best.transcript, confidence: best.confidence ?? 0 });
        }
      }),
      NativeSR.addListener('error', (e: any) => fail(e?.error)),
      NativeSR.addListener('end', () => {
        setIsListening(false);
        optionsRef.current?.onEnd?.();
      }),
    ];
    return () => subs.forEach((s: any) => s?.remove?.());
  }, [fail]);

  const startNative = useCallback(async () => {
    try {
      const perm = await NativeSR.requestPermissionsAsync();
      if (!perm?.granted) {
        fail('not-allowed');
        return;
      }
      setError(null);
      setTranscript('');
      NativeSR.start({
        lang: optionsRef.current?.lang || 'en-US',
        interimResults: optionsRef.current?.interimResults ?? true,
        continuous: optionsRef.current?.continuous ?? false,
      });
      setIsListening(true);
    } catch {
      fail();
    }
  }, [fail]);

  const startWeb = useCallback(() => {
    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognitionClass();
    recognition.lang = optionsRef.current?.lang || 'en-US';
    recognition.continuous = optionsRef.current?.continuous ?? false;
    recognition.interimResults = optionsRef.current?.interimResults ?? true;

    recognition.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';
      let confidence = 0;
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalTranscript += result[0].transcript;
          confidence = result[0].confidence;
        } else {
          interimTranscript += result[0].transcript;
        }
      }
      if (finalTranscript) {
        setTranscript(finalTranscript);
        optionsRef.current?.onResult?.({ transcript: finalTranscript, confidence });
      } else if (interimTranscript) {
        setTranscript(interimTranscript);
      }
    };
    recognition.onerror = (event: any) => fail(event.error);
    recognition.onend = () => {
      setIsListening(false);
      optionsRef.current?.onEnd?.();
    };

    recognitionRef.current = recognition;
    setError(null);
    setTranscript('');
    try {
      recognition.start();
      setIsListening(true);
    } catch {
      // already started
    }
  }, [fail]);

  const start = useCallback(() => {
    if (!isSupported()) {
      const msg = 'Voice input is not available here. You can type instead.';
      setError(msg);
      optionsRef.current?.onError?.(msg);
      return;
    }
    if (Platform.OS === 'web') startWeb();
    else startNative();
  }, [isSupported, startNative, startWeb]);

  const stop = useCallback(() => {
    if (Platform.OS !== 'web') {
      try {
        NativeSR?.stop();
      } catch {
        // already stopped
      }
      setIsListening(false);
      return;
    }
    const recognition = recognitionRef.current;
    if (recognition) {
      try {
        recognition.stop();
      } catch {
        // already stopped
      }
      setIsListening(false);
    }
  }, []);

  const reset = useCallback(() => {
    setTranscript('');
    setError(null);
  }, []);

  useEffect(() => {
    return () => {
      stop();
    };
  }, [stop]);

  return { isListening, transcript, error, isSupported, start, stop, reset };
}
