// Supabase Edge Function: Eyo assistant proxy.
// Keeps the OpenAI key on the server. Deploy with:
//   supabase secrets set OPENAI_API_KEY=sk-...
//   supabase functions deploy eyo
// @ts-nocheck  (Deno runtime)

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const systemPrompt = (language: string, context?: string) => `You are Eyo, a warm, patient, human-sounding voice assistant for blind, low-vision and other disabled users in India.
Your replies are read aloud by a screen reader or text-to-speech, so:
- Speak in short, natural sentences. No markdown, no bullet symbols, no emojis, no URLs read out letter by letter.
- Answer first, then offer one clear next step if useful.
- Reply in ${language === 'ta' ? 'Tamil (தமிழ்)' : 'English'}, unless the user clearly writes in the other language, then match them.
- The app itself can describe what the camera sees, read text and currency, name colours, scan barcodes, give walking directions, find nearby places, read Tamil and English news, and open emergency options. When someone asks for one of those, tell them briefly to say it or tap the matching button; do not pretend you can see through the camera yourself.
- You can help with daily questions, explaining things, reading and explaining text they give you, and friendly conversation.
- If you do not know or cannot do something, say so plainly and suggest an alternative.
- Never diagnose or give definitive medical, legal or financial advice; give general information and suggest a professional.
- If someone may be in danger or needs urgent help, tell them to call 112 (India emergency number) or ask someone nearby.${context ? `\n\nThe camera recently described this to the user (they may ask follow-up questions about it):\n${context}` : ''}`;

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors });

  try {
    const { messages, language, context } = await req.json();
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return new Response(JSON.stringify({ error: 'Invalid messages' }), { status: 400, headers: cors });
    }
    const safe = messages
      .filter((m: any) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .map((m: any) => ({ role: m.role, content: m.content.slice(0, 2000) }));

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      },
      body: JSON.stringify({
        model: Deno.env.get('OPENAI_MODEL') ?? 'gpt-4o',
        temperature: 0.6,
        max_tokens: 400,
        messages: [{ role: 'system', content: systemPrompt(language, typeof context === 'string' ? context.slice(0, 1500) : undefined) }, ...safe],
      }),
    });

    if (!res.ok) {
      return new Response(JSON.stringify({ error: 'Upstream error' }), { status: 502, headers: cors });
    }
    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content?.trim() ?? '';
    return new Response(JSON.stringify({ reply }), { headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch {
    return new Response(JSON.stringify({ error: 'Bad request' }), { status: 400, headers: cors });
  }
});
