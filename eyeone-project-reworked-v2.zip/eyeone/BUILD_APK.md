# Get EyeOne onto your Android phone (one APK file)

The APK is built in Expo's cloud (free account), because it needs the Android toolchain.

## One-time setup (computer)
1. Install Node.js 20 or newer.
2. Make a free account at https://expo.dev
3. Unzip this project, open a terminal in the `eyeone` folder, then:
   ```
   npm install --legacy-peer-deps
   npm install -g eas-cli
   eas login
   ```

## Server (needed for camera descriptions, Eyo chat, live news)
```
npm install -g supabase
supabase login
supabase link --project-ref YOUR-PROJECT-REF
supabase secrets set OPENAI_API_KEY=sk-...
supabase functions deploy eyo vision news --no-verify-jwt
```
Then put your project URL and anon key into `eas.json` (both places `YOUR-PROJECT` / `YOUR-ANON-KEY` appear).
`--no-verify-jwt` is only for testing; see README about adding login/rate limiting before sharing the app.

## Build
```
eas build -p android --profile preview
```
- First run: answer Yes to "create project" and Yes to "generate a keystore".
- Takes about 10 to 20 minutes. When done you get a link and a QR code.
- Open the link on your phone, download the .apk, allow "install unknown apps" when asked, install.
- Allow camera, microphone, location when the app asks.

## Rebuilding after feedback
Run the same `eas build` command again; install the new APK over the old one.
