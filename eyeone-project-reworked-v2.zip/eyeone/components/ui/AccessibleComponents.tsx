import React, { ReactNode } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Pressable, ViewStyle, TextStyle, AccessibilityRole } from 'react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';

interface AccessibleButtonProps {
  label: string;
  onPress: () => void;
  icon?: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'success';
  size?: 'small' | 'medium' | 'large' | 'extraLarge';
  accessibilityHint?: string;
  style?: ViewStyle;
  disabled?: boolean;
  testID?: string;
}

export function AccessibleButton({
  label,
  onPress,
  icon,
  variant = 'primary',
  size = 'large',
  accessibilityHint,
  style,
  disabled,
  testID,
}: AccessibleButtonProps) {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);

  const sizeConfig = {
    small: { paddingVertical: 8, paddingHorizontal: 16, fontSize: 14, iconSize: 18 },
    medium: { paddingVertical: 12, paddingHorizontal: 20, fontSize: 16, iconSize: 20 },
    large: { paddingVertical: 18, paddingHorizontal: 24, fontSize: 18, iconSize: 24 },
    extraLarge: { paddingVertical: 24, paddingHorizontal: 32, fontSize: 22, iconSize: 28 },
  };

  const cfg = sizeConfig[size];

  const bgColors = {
    primary: colors.primary,
    secondary: colors.surfaceAlt,
    outline: 'transparent',
    danger: colors.error,
    success: colors.accent,
  };

  const textColors = {
    primary: colors.primaryText,
    secondary: colors.text,
    outline: colors.primary,
    danger: '#FFFFFF',
    success: '#000000',
  };

  const borderColors = {
    primary: 'transparent',
    secondary: 'transparent',
    outline: colors.primary,
    danger: 'transparent',
    success: 'transparent',
  };

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled }}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: bgColors[variant],
          borderColor: borderColors[variant],
          paddingVertical: cfg.paddingVertical,
          paddingHorizontal: cfg.paddingHorizontal,
          opacity: pressed ? 0.7 : disabled ? 0.5 : 1,
          borderWidth: variant === 'outline' ? 2 : 0,
        },
        style,
      ]}
    >
      <View style={styles.content}>
        {icon && <View style={styles.iconContainer}>{icon}</View>}
        <Text
          style={[
            styles.label,
            {
              color: textColors[variant],
              fontSize: getFontSize(cfg.fontSize),
              fontWeight: '700',
            },
          ]}
        >
          {label}
        </Text>
      </View>
    </Pressable>
  );
}

interface AccessibleCardProps {
  title: string;
  subtitle?: string;
  onPress?: () => void;
  children?: ReactNode;
  accessibilityLabel?: string;
  accessibilityHint?: string;
  style?: ViewStyle;
  testID?: string;
}

export function AccessibleCard({
  title,
  subtitle,
  onPress,
  children,
  accessibilityLabel,
  accessibilityHint,
  style,
  testID,
}: AccessibleCardProps) {
  const { getColors, getFontSize } = useAccessibility();
  const colors = getColors();

  const Wrapper: any = onPress ? Pressable : View;
  const wrapperProps: any = onPress
    ? {
        onPress,
        accessibilityRole: 'button',
        accessibilityLabel: accessibilityLabel || title,
        accessibilityHint,
        testID,
      }
    : { testID };

  return (
    <Wrapper
      {...wrapperProps}
      style={({ pressed }: any) => [
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          opacity: pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      <Text
        style={[styles.cardTitle, { color: colors.text, fontSize: getFontSize(18) }]}
        accessibilityRole="header"
      >
        {title}
      </Text>
      {subtitle && (
        <Text style={[styles.cardSubtitle, { color: colors.textSecondary, fontSize: getFontSize(14) }]}>
          {subtitle}
        </Text>
      )}
      {children}
    </Wrapper>
  );
}

interface AccessibleHeadingProps {
  text: string;
  level?: 1 | 2 | 3;
  style?: TextStyle;
  accessibilityLabel?: string;
}

export function AccessibleHeading({ text, level = 1, style, accessibilityLabel }: AccessibleHeadingProps) {
  const { getColors, getFontSize } = useAccessibility();
  const colors = getColors();
  const sizes = { 1: 28, 2: 22, 3: 18 };
  const roles: AccessibilityRole[] = ['header', 'header', 'header'];

  return (
    <Text
      accessibilityRole={roles[level - 1]}
      accessibilityLabel={accessibilityLabel || text}
      style={[
        {
          color: colors.text,
          fontSize: getFontSize(sizes[level]),
          fontWeight: level === 1 ? '800' : '700',
          lineHeight: getFontSize(sizes[level]) * 1.2,
        },
        style,
      ]}
    >
      {text}
    </Text>
  );
}

interface ScreenWrapperProps {
  children: ReactNode;
  style?: ViewStyle;
}

export function ScreenWrapper({ children, style }: ScreenWrapperProps) {
  const { getColors } = useAccessibility();
  const colors = getColors();

  return (
    <View style={[styles.screenWrapper, { backgroundColor: colors.background }, style]}>
      {children}
    </View>
  );
}

interface LoadingViewProps {
  message?: string;
}

export function LoadingView({ message }: LoadingViewProps) {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);

  return (
    <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
      <Text
        accessibilityRole="alert"
        accessibilityLiveRegion="polite"
        style={{ color: colors.text, fontSize: getFontSize(16), fontWeight: '600' }}
      >
        {message || t('loading')}
      </Text>
    </View>
  );
}

interface ErrorViewProps {
  message?: string;
  onRetry?: () => void;
}

export function ErrorView({ message, onRetry }: ErrorViewProps) {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);

  return (
    <View style={[styles.errorContainer, { backgroundColor: colors.background }]}>
      <Text
        accessibilityRole="alert"
        accessibilityLiveRegion="assertive"
        style={{ color: colors.error, fontSize: getFontSize(16), fontWeight: '600', textAlign: 'center' }}
      >
        {message || t('errorLoading')}
      </Text>
      {onRetry && (
        <AccessibleButton
          label={t('tryAgain')}
          onPress={onRetry}
          variant="primary"
          size="medium"
          style={{ marginTop: 16 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  width: '100%',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  iconContainer: {
    marginRight: 4,
  },
  label: {
    textAlign: 'center',
  },
  card: {
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 12,
  },
  cardTitle: {
    fontWeight: '700',
    marginBottom: 4,
  },
  cardSubtitle: {
    marginTop: 2,
  lineHeight: 20,
  },
  screenWrapper: {
    flex: 1,
    padding: 20,
  paddingTop: 10,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
});
