import { AppLanguage } from '@/contexts/AccessibilityContext';
import { VISION_URL, authHeaders } from './config';

/**
 * What the camera can do, modelled on the apps blind users rely on:
 *  scene    — Be My AI / Seeing AI "Scene": describe surroundings, obstacles, people
 *  text     — Seeing AI "Short text" / Envision "Instant text" / Lookout "Text": read signs, labels, menus
 *  document — Seeing AI "Document" / Envision "Scan text": read a full page in order
 *  currency — Seeing AI / Lookout "Currency": identify Indian rupee notes and coins
 *  color    — Seeing AI "Color": name colours (clothes, objects)
 *  ask      — Envision "Ask" / Be My AI follow-up: answer a question about the last photo
 */
export type VisionMode = 'scene' | 'text' | 'document' | 'currency' | 'color' | 'ask';

export class VisionError extends Error {
  kind: 'not-configured' | 'network' | 'server';
  constructor(kind: VisionError['kind']) {
    super(kind);
    this.kind = kind;
  }
}

export interface VisionRequest {
  base64: string;
  mimeType?: string;
  mode: VisionMode;
  language: AppLanguage;
  question?: string;
  /** For 'ask': what was said about this photo before. */
  previous?: string;
}

const TIMEOUT_MS = 30000;

export function isVisionConfigured(): boolean {
  return !!VISION_URL;
}

export async function describeImage(req: VisionRequest): Promise<string> {
  if (!VISION_URL) throw new VisionError('not-configured');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(VISION_URL, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        image: req.base64,
        mimeType: req.mimeType ?? 'image/jpeg',
        mode: req.mode,
        language: req.language,
        question: req.question,
        previous: req.previous,
      }),
    });
    if (!res.ok) throw new VisionError('server');
    const data = (await res.json()) as { text?: string };
    if (!data.text) throw new VisionError('server');
    return data.text;
  } catch (e) {
    if (e instanceof VisionError) throw e;
    throw new VisionError('network');
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------------------------------------------ */
/* Barcode product lookup (Seeing AI "Product") — Open Food Facts      */
/* ------------------------------------------------------------------ */

export interface ProductInfo {
  code: string;
  name?: string;
  brand?: string;
  quantity?: string;
  ingredients?: string;
}

export async function lookupProduct(code: string): Promise<ProductInfo> {
  try {
    const res = await fetch(
      `https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(
        code
      )}.json?fields=product_name,brands,quantity,ingredients_text`
    );
    if (!res.ok) return { code };
    const data = await res.json();
    if (data.status !== 1 || !data.product) return { code };
    const p = data.product;
    return {
      code,
      name: p.product_name || undefined,
      brand: p.brands || undefined,
      quantity: p.quantity || undefined,
      ingredients: p.ingredients_text || undefined,
    };
  } catch {
    return { code };
  }
}

export function speakableProduct(p: ProductInfo, language: AppLanguage): string | null {
  if (!p.name) return null;
  const ta = language === 'ta';
  const parts = [p.brand ? `${p.brand} ${p.name}` : p.name];
  if (p.quantity) parts.push(ta ? `அளவு ${p.quantity}` : `Size ${p.quantity}`);
  if (p.ingredients) {
    const short = p.ingredients.length > 300 ? `${p.ingredients.slice(0, 300)}…` : p.ingredients;
    parts.push(ta ? `பொருட்கள்: ${short}` : `Ingredients: ${short}`);
  }
  return parts.join('. ');
}
