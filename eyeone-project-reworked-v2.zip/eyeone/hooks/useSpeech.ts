import { useRef, useCallback, useEffect } from 'react';
import { Platform, AccessibilityInfo } from 'react-native';
import * as Speech from 'expo-speech';
import { useAccessibility } from '@/contexts/AccessibilityContext';

interface SpeakOptions {
  lang?: string;
  rate?: number;
  pitch?: number;
  onEnd?: () => void;
  onBoundary?: (charIndex: number) => void;
}

const isWeb = Platform.OS === 'web';

let cachedVoices: SpeechSynthesisVoice[] = [];

function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!isWeb || typeof window === 'undefined' || !window.speechSynthesis) {
      resolve([]);
      return;
    }
    const existing = window.speechSynthesis.getVoices();
    if (existing.length > 0) {
      cachedVoices = existing;
      resolve(existing);
      return;
    }
    const handler = () => {
      const voices = window.speechSynthesis.getVoices();
      cachedVoices = voices;
      window.speechSynthesis.onvoiceschanged = null;
      resolve(voices);
    };
    window.speechSynthesis.onvoiceschanged = handler;
    setTimeout(() => {
      window.speechSynthesis.onvoiceschanged = null;
      resolve(cachedVoices);
    }, 2000);
  });
}

/**
 * Text-to-speech for web (Web Speech API) and native (expo-speech).
 * Same API on both, so screens don't care which platform they run on.
 */
export function useSpeech() {
  const { getSpeechRate, language, voiceEnabled } = useAccessibility();
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const speakingRef = useRef(false);
  const pausedRef = useRef(false);
  const screenReaderRef = useRef(false);

  useEffect(() => {
    loadVoices();
    AccessibilityInfo.isScreenReaderEnabled()
      .then((on) => {
        screenReaderRef.current = on;
      })
      .catch(() => {});
    const sub = AccessibilityInfo.addEventListener('screenReaderChanged', (on) => {
      screenReaderRef.current = on;
    });
    return () => sub.remove();
  }, []);

  const isSupported = useCallback(() => {
    if (!isWeb) return true;
    return typeof window !== 'undefined' && !!window.speechSynthesis;
  }, []);

  const speak = useCallback(
    (text: string, options?: SpeakOptions) => {
      if (!isSupported() || !voiceEnabled) {
        // App voice is off: if TalkBack/VoiceOver is running, hand the text to it instead of staying silent.
        if (screenReaderRef.current && text) AccessibilityInfo.announceForAccessibility(text);
        options?.onEnd?.();
        return;
      }
      const lang = options?.lang || (language === 'ta' ? 'ta-IN' : 'en-US');
      const rate = options?.rate ?? getSpeechRate();
      const pitch = options?.pitch ?? 1;

      if (!isWeb) {
        Speech.stop();
        speakingRef.current = true;
        pausedRef.current = false;
        const done = () => {
          speakingRef.current = false;
          options?.onEnd?.();
        };
        Speech.speak(text, {
          language: lang,
          rate,
          pitch,
          onDone: done,
          onStopped: () => {
            speakingRef.current = false;
          },
          onError: done,
          onBoundary: options?.onBoundary
            ? (e: any) => options.onBoundary?.(e?.charIndex ?? 0)
            : undefined,
        });
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = rate;
      utterance.pitch = pitch;

      const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
      const matchVoice = voices.find((v) => v.lang === lang) || voices.find((v) => v.lang.startsWith(lang.split('-')[0]));
      if (matchVoice) utterance.voice = matchVoice;

      if (options?.onEnd) utterance.onend = options.onEnd;
      if (options?.onBoundary) {
        utterance.onboundary = (e) => options.onBoundary?.(e.charIndex);
      }

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    },
    [getSpeechRate, language, voiceEnabled, isSupported]
  );

  const pause = useCallback(() => {
    if (isWeb) {
      if (isSupported()) window.speechSynthesis.pause();
    } else {
      // Speech.pause is iOS-only; on Android we fall back to stopping.
      if (Platform.OS === 'ios') Speech.pause();
      else Speech.stop();
    }
    pausedRef.current = true;
  }, [isSupported]);

  const resume = useCallback(() => {
    if (isWeb) {
      if (isSupported()) window.speechSynthesis.resume();
    } else if (Platform.OS === 'ios') {
      Speech.resume();
    }
    pausedRef.current = false;
  }, [isSupported]);

  const stop = useCallback(() => {
    if (isWeb) {
      if (isSupported()) {
        window.speechSynthesis.cancel();
        utteranceRef.current = null;
      }
    } else {
      Speech.stop();
    }
    speakingRef.current = false;
    pausedRef.current = false;
  }, [isSupported]);

  const isSpeaking = useCallback(() => {
    if (isWeb) return isSupported() && window.speechSynthesis.speaking;
    return speakingRef.current;
  }, [isSupported]);

  const isPaused = useCallback(() => {
    if (isWeb) return isSupported() && window.speechSynthesis.paused;
    return pausedRef.current;
  }, [isSupported]);

  return { speak, pause, resume, stop, isSpeaking, isPaused, isSupported };
}
