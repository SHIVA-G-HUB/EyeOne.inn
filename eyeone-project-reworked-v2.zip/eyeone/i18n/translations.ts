import { AppLanguage } from '@/contexts/AccessibilityContext';

export type TranslationKey =
  | 'appName'
  | 'tagline'
  | 'home'
  | 'news'
  | 'aiAssistant'
  | 'navigation'
  | 'settings'
  | 'help'
  | 'welcomeMessage'
  | 'latestNews'
  | 'tamilNews'
  | 'englishNews'
  | 'categories'
  | 'readArticle'
  | 'listenArticle'
  | 'saveArticle'
  | 'removeSaved'
  | 'savedArticles'
  | 'searchNews'
  | 'searchPlaceholder'
  | 'search'
  | 'read'
  | 'pause'
  | 'resume'
  | 'stop'
  | 'restart'
  | 'nextInstruction'
  | 'previousInstruction'
  | 'repeatInstruction'
  | 'stopNavigation'
  | 'currentLocation'
  | 'destination'
  | 'distance'
  | 'estimatedTime'
  | 'routeInstructions'
  | 'startNavigation'
  | 'searchLocation'
  | 'findNearby'
  | 'hospitals'
  | 'restaurants'
  | 'transit'
  | 'shopping'
  | 'typeMessage'
  | 'send'
  | 'clear'
  | 'newConversation'
  | 'microphone'
  | 'speak'
  | 'stopSpeaking'
  | 'continueSpeaking'
  | 'language'
  | 'textSize'
  | 'contrast'
  | 'motion'
  | 'speechSpeed'
  | 'voice'
  | 'small'
  | 'medium'
  | 'large'
  | 'extraLarge'
  | 'normal'
  | 'highContrast'
  | 'maxContrast'
  | 'reducedMotion'
  | 'slow'
  | 'fast'
  | 'on'
  | 'off'
  | 'tamil'
  | 'english'
  | 'howToUse'
  | 'keyboardInstructions'
  | 'voiceInstructions'
  | 'aiInstructions'
  | 'navigationInstructions'
  | 'loading'
  | 'errorLoading'
  | 'tryAgain'
  | 'noResults'
  | 'offlineMessage'
  | 'locationPermissionTitle'
  | 'locationPermissionMessage'
  | 'locationDenied'
  | 'locationDeniedMessage'
  | 'articleSaved'
  | 'articleRemoved'
  | 'navigationStarted'
  | 'navigationStopped'
  | 'languageChanged'
  | 'voiceNotSupported'
  | 'micPermissionDenied'
  | 'noSpeechDetected'
  | 'shakeToOpen'
  | 'tapToSpeak'
  | 'listening'
  | 'aboutApp'
  | 'aboutDescription'
  | 'privacyNotice'
  | 'privacyDescription'
  | 'close'
  | 'cancel'
  | 'confirm'
  | 'yes'
  | 'no'
  | 'back'
  | 'moreInfo'
  | 'publishedAt'
  | 'category'
  | 'summary'
  | 'fullArticle'
  | 'selectCategory'
  | 'allNews'
  | 'tamilNadu'
  | 'india'
  | 'world'
  | 'politics'
  | 'business'
  | 'technology'
  | 'sports'
  | 'education'
  | 'health'
  | 'entertainment'
  | 'weather'
  | 'government'
  | 'noSavedArticles'
  | 'voiceFirstMode'
  | 'sayACommand'
  | 'readingArticle'
  | 'finishedReading'
  | 'routeFound'
  | 'noRouteFound'
  | 'enterDestination'
  | 'useCurrentLocation'
  | 'orEnterStart'
  | 'startingPoint'
  | 'arrived'
  | 'directions'
  | 'step'
  | 'of'
  | 'meters'
  | 'kilometers'
  | 'minutes'
  | 'walk'
  | 'turn'
  | 'continue'
  | 'cross'
  | 'head'
  | 'arriveAt'
  | 'assistantGreeting'
  | 'assistantPrompt'
  | 'thinking'
  | 'askAboutNews'
  | 'translateTo'
  | 'summarize'
  | 'explainSimply'
  | 'see'
  | 'describeScene'
  | 'readText'
  | 'currency'
  | 'colour'
  | 'product'
  | 'takePhoto'
  | 'choosePhoto'
  | 'lightOn'
  | 'lightOff'
  | 'repeat'
  | 'askAboutPhoto'
  | 'analysing'
  | 'cameraPermission'
  | 'allowCamera'
  | 'tapToCapture'
  | 'visionError'
  | 'visionNotConfigured'
  | 'scanningBarcode'
  | 'barcodeUnknown'
  | 'emergency'
  | 'sosHint'
  | 'call'
  | 'callEmergency'
  | 'textLocationTo'
  | 'emergencyContact'
  | 'contactName'
  | 'contactPhone'
  | 'noContactSet'
  | 'sosSpoken'
  | 'whereAmI'
  | 'gettingLocation'
  | 'haptics'
  | 'handsFree'
  | 'atms'
  | 'pharmacies'
  | 'toilets'
  | 'nearby'
  | 'recalculating'
  | 'nothingNearby'
  | 'medicalNews'
  | 'refresh'
  | 'newsOffline'
  | 'saved'
  | 'save'
  | 'helpVision'
  | 'connectionNeeded'
  | 'document';

const translations: Record<AppLanguage, Record<TranslationKey, string>> = {
  en: {
    appName: 'TrueAccessibility',
    tagline: 'Your eyes, your world',
    home: 'Home',
    news: 'News',
    aiAssistant: 'AI Assistant',
    navigation: 'Navigation',
    settings: 'Settings',
    help: 'Help',
    welcomeMessage: 'Welcome. Tap any button to begin. Shake your phone anytime to open Eyo.',
    latestNews: 'Latest News',
    tamilNews: 'Tamil News',
    englishNews: 'English News',
    categories: 'Categories',
    readArticle: 'Read Article',
    listenArticle: 'Listen',
    saveArticle: 'Save',
    removeSaved: 'Remove',
    savedArticles: 'Saved Articles',
    searchNews: 'Search News',
    searchPlaceholder: 'Search for news topics...',
    search: 'Search',
    read: 'Read',
    pause: 'Pause',
    resume: 'Resume',
    stop: 'Stop',
    restart: 'Restart',
    nextInstruction: 'Next',
    previousInstruction: 'Previous',
    repeatInstruction: 'Repeat',
    stopNavigation: 'Stop Navigation',
    currentLocation: 'Current Location',
    destination: 'Destination',
    distance: 'Distance',
    estimatedTime: 'Estimated Time',
    routeInstructions: 'Route Instructions',
    startNavigation: 'Start Navigation',
    searchLocation: 'Search Location',
    findNearby: 'Find Nearby',
    hospitals: 'Hospitals',
    restaurants: 'Restaurants',
    transit: 'Transit Stations',
    shopping: 'Shopping',
    typeMessage: 'Type a message...',
    send: 'Send',
    clear: 'Clear',
    newConversation: 'New Conversation',
    microphone: 'Microphone',
    speak: 'Speak',
    stopSpeaking: 'Stop Speaking',
    continueSpeaking: 'Continue',
    language: 'Language',
    textSize: 'Text Size',
    contrast: 'Contrast',
    motion: 'Motion',
    speechSpeed: 'Speech Speed',
    voice: 'Voice',
    small: 'Small',
    medium: 'Medium',
    large: 'Large',
    extraLarge: 'Extra Large',
    normal: 'Normal',
    highContrast: 'High Contrast',
    maxContrast: 'Maximum Contrast',
    reducedMotion: 'Reduced Motion',
    slow: 'Slow',
    fast: 'Fast',
    on: 'On',
    off: 'Off',
    tamil: 'Tamil',
    english: 'English',
    howToUse: 'How to Use',
    keyboardInstructions: 'Keyboard Controls',
    voiceInstructions: 'Voice Commands',
    aiInstructions: 'AI Assistant',
    navigationInstructions: 'Navigation',
    loading: 'Loading...',
    errorLoading: 'Something went wrong. Please try again.',
    tryAgain: 'Try Again',
    noResults: 'No results found.',
    offlineMessage: 'You are offline. Showing cached content.',
    locationPermissionTitle: 'Location Permission',
    locationPermissionMessage: 'Location access is needed to provide directions and find nearby places.',
    locationDenied: 'Location Unavailable',
    locationDeniedMessage: 'Location access is turned off. You can search for a starting point manually.',
    articleSaved: 'Article saved.',
    articleRemoved: 'Article removed from saved.',
    navigationStarted: 'Navigation started.',
    navigationStopped: 'Navigation stopped.',
    languageChanged: 'Language changed to',
    voiceNotSupported: 'Voice features are not supported in this browser.',
    micPermissionDenied: 'Microphone permission denied.',
    noSpeechDetected: 'No speech detected. Please try again.',
    shakeToOpen: 'Shake to Open',
    tapToSpeak: 'Tap to speak',
    listening: 'Listening...',
    aboutApp: 'About',
    aboutDescription: 'An accessibility-first app for blind and visually impaired users. Talk to Eyo, describe what is around you, read text and currency, walk with voice directions, and hear Tamil and English news.',
    privacyNotice: 'Privacy',
    privacyDescription: 'Photos you take are sent securely to an AI service so they can be described. The app does not keep them. Your emergency contact and settings are stored only on this phone.',
    close: 'Close',
    cancel: 'Cancel',
    confirm: 'Confirm',
    yes: 'Yes',
    no: 'No',
    back: 'Back',
    moreInfo: 'More Info',
    publishedAt: 'Published',
    category: 'Category',
    summary: 'Summary',
    fullArticle: 'Full Article',
    selectCategory: 'Select Category',
    allNews: 'All News',
    tamilNadu: 'Tamil Nadu',
    india: 'India',
    world: 'World',
    politics: 'Politics',
    business: 'Business',
    technology: 'Technology',
    sports: 'Sports',
    education: 'Education',
    health: 'Health',
    entertainment: 'Entertainment',
    weather: 'Weather',
    government: 'Government',
    noSavedArticles: 'No saved articles yet.',
    voiceFirstMode: 'Voice-First Mode',
    sayACommand: 'Say a command...',
    readingArticle: 'Reading article...',
    finishedReading: 'Finished reading.',
    routeFound: 'Route found.',
    noRouteFound: 'Could not find a route. Please try a different destination.',
    enterDestination: 'Enter destination',
    useCurrentLocation: 'Use current location',
    orEnterStart: 'Or enter starting point',
    startingPoint: 'Starting point',
    arrived: 'You have arrived at your destination.',
    directions: 'Directions',
    step: 'Step',
    of: 'of',
    meters: 'm',
    kilometers: 'km',
    minutes: 'min',
    walk: 'Walk',
    turn: 'Turn',
    continue: 'Continue',
    cross: 'Cross',
    head: 'Head',
    arriveAt: 'Arrive at',
    assistantGreeting: 'Hello! I am your accessibility assistant. How can I help you today?',
    assistantPrompt: 'Ask me about the news, request directions, or say "read Tamil news".',
    thinking: 'Thinking...',
    askAboutNews: 'Ask about the news',
    translateTo: 'Translate to',
    summarize: 'Summarize',
    explainSimply: 'Explain simply',
    see: 'See',
    describeScene: 'Describe scene',
    readText: 'Read text',
    currency: 'Currency',
    colour: 'Colour',
    product: 'Product',
    takePhoto: 'Take photo',
    choosePhoto: 'Choose photo',
    lightOn: 'Light on',
    lightOff: 'Light off',
    repeat: 'Repeat',
    askAboutPhoto: 'Ask about this photo',
    analysing: 'Looking now. Please hold still.',
    cameraPermission: 'EyeOne needs the camera to see for you.',
    allowCamera: 'Allow camera',
    tapToCapture: 'Double tap anywhere on the screen to take a photo.',
    visionError: 'I could not analyse that photo. Please check your internet connection and try again.',
    visionNotConfigured: 'The vision service is not set up yet. Please add the server address in the app settings file.',
    scanningBarcode: 'Point the camera at a barcode. I will scan it automatically.',
    barcodeUnknown: 'I found a barcode but no product details. Try Read text mode on the label.',
    emergency: 'Emergency',
    sosHint: 'Opens emergency options: call 112 or text your location',
    call: 'Call',
    callEmergency: 'Call 112 now',
    textLocationTo: 'Text my location to',
    emergencyContact: 'Emergency contact',
    contactName: 'Contact name',
    contactPhone: 'Contact phone number',
    noContactSet: 'No emergency contact is saved. You can add one in Settings.',
    sosSpoken: 'Emergency options. Call 112, call your contact, or text your location. Or go back.',
    whereAmI: 'Where am I',
    gettingLocation: 'Finding your location.',
    haptics: 'Vibration feedback',
    handsFree: 'Hands-free chat',
    atms: 'ATMs',
    pharmacies: 'Pharmacies',
    toilets: 'Toilets',
    nearby: 'Nearby',
    recalculating: 'You seem off the route. Finding a new way.',
    nothingNearby: 'I could not find any of those nearby.',
    medicalNews: 'Medical',
    refresh: 'Refresh',
    newsOffline: 'Live news could not be loaded. Showing saved sample stories.',
    saved: 'Saved',
    save: 'Save',
    helpVision: 'Camera and vision',
    connectionNeeded: 'This needs an internet connection.',
    document: 'Document',
  },
  ta: {
    appName: 'TrueAccessibility',
    tagline: 'உங்கள் கண்கள், உங்கள் உலகம்',
    home: 'முகப்பு',
    news: 'செய்திகள்',
    aiAssistant: 'AI உதவியாளர்',
    navigation: 'வழிகாட்டி',
    settings: 'அமைப்புகள்',
    help: 'உதவி',
    welcomeMessage: 'வரவேற்கிறோம். தொடங்க எந்த பொத்தானையும் தட்டவும். உதவியாளரை திறக ஃபோனை குலுக்கவும்.',
    latestNews: 'சமீபத்திய செய்திகள்',
    tamilNews: 'தமிழ் செய்திகள்',
    englishNews: '�ங்கில செய்திகள்',
    categories: 'பிரிவுகள்',
    readArticle: 'கட்டுரை படி',
    listenArticle: 'கேள்',
    saveArticle: 'சேமி',
    removeSaved: 'நீக்கு',
    savedArticles: 'சேமித்த கட்டுரைகள்',
    searchNews: 'செய்தி தேடல்',
    searchPlaceholder: 'செய்தி தலைப்புகளை தேடவும்...',
    search: 'தேடு',
    read: 'படி',
    pause: 'இடைநிறுத்து',
    resume: 'தொடரு',
    stop: 'நிறுத்து',
    restart: 'மீண்டும் தொடங்கு',
    nextInstruction: 'அடுத்து',
    previousInstruction: 'முந்தையது',
    repeatInstruction: 'மீண்டும்',
    stopNavigation: 'வழிகாட்டியை நிறுத்து',
    currentLocation: 'தற்போதைய இடம்',
    destination: 'சேருமிடம்',
    distance: 'தூரம்',
    estimatedTime: 'மதிப்பிடப்பட்ட நேரம்',
    routeInstructions: 'பாதை வழிமுறைகள்',
    startNavigation: 'வழிகாட்டியை தொடங்கு',
    searchLocation: 'இடம் தேடு',
    findNearby: 'அருகில் காண்க',
    hospitals: 'மருத்துவமனைகள்',
    restaurants: 'உணவகங்கள்',
    transit: 'பேருந்து நிலையங்கள்',
    shopping: 'கடைகள்',
    typeMessage: 'செய்தி எழுது...',
    send: 'அனுப்பு',
    clear: 'அழி',
    newConversation: 'புதிய உரையாடல்',
    microphone: 'மைக்ரோஃபோன்',
    speak: 'பேசு',
    stopSpeaking: 'பேச்சை நிறுத்து',
    continueSpeaking: 'தொடரு',
    language: 'மொழி',
    textSize: 'எழுத்து அளவு',
    contrast: 'வண்ண வேறுபாடு',
    motion: 'அசைவு',
    speechSpeed: 'பேச்சு வேகம்',
    voice: 'குரல்',
    small: 'சிறியது',
    medium: 'நடுத்தரம்',
    large: 'பெரியது',
    extraLarge: 'மிகப் பெரியது',
    normal: 'சாதாரணம்',
    highContrast: 'அதிக வேறுபாடு',
    maxContrast: 'அதிகபட்ச வேறுபாடு',
    reducedMotion: 'குறைக்கப்பட்ட அசைவு',
    slow: 'மெதுவாக',
    fast: 'வேகமாக',
    on: 'இயக்கு',
    off: 'அணை',
    tamil: 'தமிழ்',
    english: 'ஆங்கிலம்',
    howToUse: 'எப்படி பயன்படுத்துவது',
    keyboardInstructions: 'விசைப்பலகை கட்டுப்பாடுகள்',
    voiceInstructions: 'குரல் கட்டளைகள்',
    aiInstructions: 'AI உதவியாளர்',
    navigationInstructions: 'வழிகாட்டி',
    loading: 'ஏற்றுகிறது...',
    errorLoading: 'ஏதோ தவறு நடந்தது. மீண்டும் முயற்சிக்கவும்.',
    tryAgain: 'மீண்டும் முயற்சி',
    noResults: 'முடிவுகள் இல்லை.',
    offlineMessage: 'நீங்கள் ஆஃப்லைனில் இருக்கிறீர்கள். சேமிக்கப்பட்ட உள்ளடக்கம் காட்டப்படுகிறது.',
    locationPermissionTitle: 'இடம் அனுமதி',
    locationPermissionMessage: 'திசைகாட்டிகளை வழங்கவும் அருகிலுள்ள இடங்களைக் கண்டுபிடிக்க இடம் அணுகல் தேவை.',
    locationDenied: 'இடம் கிடைக்கவில்லை',
    locationDeniedMessage: 'இடம் அணுகல் மூடப்பட்டுள்ளது. தொடக்க இடத்தை கைமுறையாக தேடலாம்.',
    articleSaved: 'கட்டுரை சேமிக்கப்பட்டது.',
    articleRemoved: 'கட்டுரை நீக்கப்பட்டது.',
    navigationStarted: 'வழிகாட்டி தொடங்கியது.',
    navigationStopped: 'வழிகாட்டி நிறுத்தப்பட்டது.',
    languageChanged: 'மொழி மாற்றப்பட்டது',
    voiceNotSupported: 'குரல் அம்சங்கள் இந்த உலாவியில் ஆதரிக்கப்படவில்லை.',
    micPermissionDenied: 'மைக்ரோஃபோன் அனுமதி மறுக்கப்பட்டது.',
    noSpeechDetected: 'பேச்சு கண்டறியப்படவில்லை. மீண்டும் முயற்சிக்கவும்.',
    shakeToOpen: 'திறக்க குலுக்கு',
    tapToSpeak: 'பேச தட்டு',
    listening: 'கேட்கிறது...',
    aboutApp: 'பற்றி',
    aboutDescription: 'பார்வையற்ற மற்றும் பார்வை குறைபாடுள்ள பயனர்களுக்கான அணுகல் முதல் செயலி. தமிழ் மற்றும் ஆங்கிலத்தில் செய்திகளைப் படியுங்கள், குரல் வழிகாட்டியுடன் வழிநடத்துங்கள், AI உதவியாளருடன் உரையாடுங்கள்.',
    privacyNotice: 'தனியுரிமை',
    privacyDescription: 'நீங்கள் எடுக்கும் படங்கள் விவரிக்கப்பட AI சேவைக்குப் பாதுகாப்பாக அனுப்பப்படும். செயலி அவற்றைச் சேமிக்காது. அவசரத் தொடர்பும் அமைப்புகளும் இந்தத் தொலைபேசியில் மட்டுமே சேமிக்கப்படும்.',
    close: 'மூடு',
    cancel: 'ரத்து',
    confirm: 'உறுதிப்படுத்து',
    yes: 'ஆம்',
    no: 'இல்லை',
    back: 'பின்',
    moreInfo: 'மேலும் தகவல்',
    publishedAt: 'வெளியிடப்பட்டது',
    category: 'பிரிவு',
    summary: 'சுருக்கம்',
    fullArticle: 'முழு கட்டுரை',
    selectCategory: 'பிரிவை தேர்வு செய்',
    allNews: 'அனைத்து செய்திகள்',
    tamilNadu: 'தமிழ்நாடு',
    india: 'இந்தியா',
    world: 'உலகம்',
    politics: 'அரசியல்',
    business: 'வணிகம்',
    technology: 'தொழில்நுட்பம்',
    sports: 'விளையாட்டு',
    education: 'கல்வி',
    health: 'சுகாதாரம்',
    entertainment: 'பொழுதுபோக்கு',
    weather: 'வானிலை',
    government: 'அரசு',
    noSavedArticles: 'சேமித்த கட்டுரைகள் இல்லை.',
    voiceFirstMode: 'குரல் முதல் பயன்முறை',
    sayACommand: 'கட்டளை சொல்லு...',
    readingArticle: 'கட்டுரை படிக்கிறது...',
    finishedReading: 'படிப்பு முடிந்தது.',
    routeFound: 'பாதை கிடைத்தது.',
    noRouteFound: 'பாதை கிடைக்கவில்லை. வேறு சேருமிடத்தை முயற்சிக்கவும்.',
    enterDestination: 'சேருமிடம் உள்ளிடவும்',
    useCurrentLocation: 'தற்போதைய இடத்தை பயன்படுத்து',
    orEnterStart: 'அல்லது தொடக்க இடத்தை உள்ளிடவும்',
    startingPoint: 'தொடக்க இடம்',
    arrived: 'நீங்கள் சேருமிடத்தை அடைந்துவிட்டீர்கள்.',
    directions: 'திசைகள்',
    step: 'படி',
    of: 'இல்',
    meters: 'மீ',
    kilometers: 'கி.மீ',
    minutes: 'நிமிடம்',
    walk: 'நட',
    turn: 'திரும்பு',
    continue: 'தொடரு',
    cross: 'கடந்து செல்',
    head: 'செல்',
    arriveAt: 'சேரு',
    assistantGreeting: 'வணக்கம்! நான் உங்கள் அணுகல் உதவியாளர். நான் எப்படி உதவ வேண்டும்?',
    assistantPrompt: 'செய்திகளைப் பற்றி கேளுங்கள், திசைகளைக் கேளுங்கள், அல்லது "தமிழ் செய்திகளை படி" என்று சொல்லுங்கள்.',
    thinking: 'சிந்திக்கிறது...',
    askAboutNews: 'செய்திகளைப் பற்றி கேள்',
    translateTo: 'மொழிபெயர்',
    summarize: 'சுருக்கம்',
    explainSimply: 'எளிமையாக விளக்கு',
    see: 'பார்',
    describeScene: 'காட்சியை விவரி',
    readText: 'உரையைப் படி',
    currency: 'ரூபாய் நோட்டு',
    colour: 'நிறம்',
    product: 'பொருள்',
    takePhoto: 'படம் எடு',
    choosePhoto: 'படத்தைத் தேர்ந்தெடு',
    lightOn: 'விளக்கை ஒளிர்',
    lightOff: 'விளக்கை அணை',
    repeat: 'மீண்டும் சொல்',
    askAboutPhoto: 'இந்தப் படம் பற்றி கேள்',
    analysing: 'பார்க்கிறேன். அசையாமல் இருங்கள்.',
    cameraPermission: 'உங்களுக்காகப் பார்க்க EyeOne-க்கு கேமரா தேவை.',
    allowCamera: 'கேமராவை அனுமதி',
    tapToCapture: 'படம் எடுக்க திரையில் எங்கு வேண்டுமானாலும் இருமுறை தட்டவும்.',
    visionError: 'அந்தப் படத்தைப் பகுப்பாய்வு செய்ய முடியவில்லை. இணைய இணைப்பைச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்.',
    visionNotConfigured: 'பார்வை சேவை இன்னும் அமைக்கப்படவில்லை. சேவையக முகவரியைச் சேர்க்கவும்.',
    scanningBarcode: 'பார்கோடை நோக்கி கேமராவைப் பிடிக்கவும். தானாக ஸ்கேன் செய்கிறேன்.',
    barcodeUnknown: 'பார்கோடு கிடைத்தது ஆனால் பொருள் விவரம் இல்லை. லேபிளில் உரையைப் படி முறையைப் பயன்படுத்துங்கள்.',
    emergency: 'அவசரம்',
    sosHint: 'அவசர வழிகள்: 112 அழைப்பு அல்லது உங்கள் இடத்தை அனுப்புதல்',
    call: 'அழை',
    callEmergency: '112-ஐ இப்போது அழை',
    textLocationTo: 'என் இடத்தை அனுப்பு',
    emergencyContact: 'அவசரத் தொடர்பு',
    contactName: 'தொடர்பு பெயர்',
    contactPhone: 'தொடர்பு தொலைபேசி எண்',
    noContactSet: 'அவசரத் தொடர்பு சேமிக்கப்படவில்லை. அமைப்புகளில் சேர்க்கலாம்.',
    sosSpoken: 'அவசர வழிகள். 112 அழைக்கலாம், உங்கள் தொடர்பை அழைக்கலாம், அல்லது இடத்தை அனுப்பலாம். அல்லது திரும்பிச் செல்லலாம்.',
    whereAmI: 'நான் எங்கே இருக்கிறேன்',
    gettingLocation: 'உங்கள் இடத்தைக் கண்டறிகிறேன்.',
    haptics: 'அதிர்வு பின்னூட்டம்',
    handsFree: 'கைகளின்றி உரையாடல்',
    atms: 'ஏடிஎம்',
    pharmacies: 'மருந்தகங்கள்',
    toilets: 'கழிவறைகள்',
    nearby: 'அருகில்',
    recalculating: 'நீங்கள் வழியிலிருந்து விலகிவிட்டீர்கள். புதிய வழியைத் தேடுகிறேன்.',
    nothingNearby: 'அருகில் எதுவும் கிடைக்கவில்லை.',
    medicalNews: 'மருத்துவம்',
    refresh: 'புதுப்பி',
    newsOffline: 'நேரடிச் செய்திகளை ஏற்ற முடியவில்லை. மாதிரிச் செய்திகள் காட்டப்படுகின்றன.',
    saved: 'சேமிக்கப்பட்டது',
    save: 'சேமி',
    helpVision: 'கேமரா மற்றும் பார்வை',
    connectionNeeded: 'இதற்கு இணைய இணைப்பு தேவை.',
    document: 'ஆவணம்',
  },
};

export function useTranslations(lang: AppLanguage) {
  return translations[lang] || translations.en;
}

export function getTranslation(lang: AppLanguage, key: TranslationKey): string {
  return translations[lang]?.[key] || translations.en[key] || key;
}
