import { Platform } from 'react-native';
import * as Location from 'expo-location';
import type { AppLanguage } from '@/contexts/AccessibilityContext';

/**
 * Real, GPS-based walking navigation built on free OpenStreetMap services:
 *  - expo-location            device position + compass heading
 *  - Nominatim                place search and "where am I" (reverse geocoding)
 *  - OSRM foot profile        walking routes with turn-by-turn steps
 *  - Overpass                 nearby hospitals, pharmacies, bus stops, ATMs, toilets...
 *
 * These public servers have fair-use limits and no uptime guarantee. That is fine for
 * development and small pilots; for a public launch move to a paid provider
 * (Mapbox, Google, OpenRouteService) behind a Supabase edge function.
 */

export interface Coords {
  lat: number;
  lng: number;
}

export interface Place {
  id: string;
  name: string;
  address?: string;
  lat: number;
  lng: number;
  distanceM?: number;
  bearing?: number;
}

export interface RouteStep {
  /** Spoken instruction for the maneuver at the START of this step. */
  instruction: string;
  /** Where the maneuver happens. */
  at: Coords;
  /** How far to walk after the maneuver, before the next one. */
  distanceM: number;
  durationS: number;
}

export interface Route {
  destination: string;
  steps: RouteStep[];
  totalDistanceM: number;
  totalDurationS: number;
}

export type NearbyKind = 'hospital' | 'pharmacy' | 'restaurant' | 'transit' | 'atm' | 'toilets' | 'shopping';

export class NavError extends Error {
  kind: 'denied' | 'unavailable' | 'network' | 'no-route';
  constructor(kind: NavError['kind']) {
    super(kind);
    this.kind = kind;
  }
}

/* ------------------------------ geometry ------------------------------ */

const R = 6371000;
const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;

export function haversine(a: Coords, b: Coords): number {
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Compass bearing 0-360 from a to b. */
export function bearingBetween(a: Coords, b: Coords): number {
  const y = Math.sin(rad(b.lng - a.lng)) * Math.cos(rad(b.lat));
  const x =
    Math.cos(rad(a.lat)) * Math.sin(rad(b.lat)) - Math.sin(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.cos(rad(b.lng - a.lng));
  return (deg(Math.atan2(y, x)) + 360) % 360;
}

/* ------------------------------ wording ------------------------------ */

const COMPASS_EN = ['north', 'north-east', 'east', 'south-east', 'south', 'south-west', 'west', 'north-west'];
const COMPASS_TA = ['வடக்கு', 'வடகிழக்கு', 'கிழக்கு', 'தென்கிழக்கு', 'தெற்கு', 'தென்மேற்கு', 'மேற்கு', 'வடமேற்கு'];

export function compassWord(bearing: number, lang: AppLanguage): string {
  const i = Math.round(((bearing % 360) / 45)) % 8;
  return (lang === 'ta' ? COMPASS_TA : COMPASS_EN)[i];
}

/** "ahead", "on your right", "behind you"... when the phone's heading is known, else a compass word. */
export function directionPhrase(bearing: number, heading: number | null, lang: AppLanguage): string {
  const ta = lang === 'ta';
  if (heading == null) return ta ? `${compassWord(bearing, lang)} திசையில்` : `to the ${compassWord(bearing, lang)}`;
  const rel = (bearing - heading + 360) % 360;
  if (rel < 30 || rel >= 330) return ta ? 'நேராக முன்னால்' : 'straight ahead';
  if (rel < 75) return ta ? 'முன்னால் வலப்புறம்' : 'ahead on your right';
  if (rel < 135) return ta ? 'உங்கள் வலப்புறம்' : 'on your right';
  if (rel < 225) return ta ? 'உங்கள் பின்னால்' : 'behind you';
  if (rel < 285) return ta ? 'உங்கள் இடப்புறம்' : 'on your left';
  return ta ? 'முன்னால் இடப்புறம்' : 'ahead on your left';
}

export function formatDistance(m: number, lang: AppLanguage): string {
  const ta = lang === 'ta';
  if (m < 1000) {
    const rounded = m < 20 ? Math.max(5, Math.round(m / 5) * 5) : Math.round(m / 10) * 10;
    return ta ? `${rounded} மீட்டர்` : `${rounded} meters`;
  }
  const km = (m / 1000).toFixed(1).replace(/\.0$/, '');
  return ta ? `${km} கிலோமீட்டர்` : `${km} kilometers`;
}

export function formatDuration(s: number, lang: AppLanguage): string {
  const min = Math.max(1, Math.round(s / 60));
  if (min < 60) return lang === 'ta' ? `${min} நிமிடம்` : `${min} minute${min === 1 ? '' : 's'}`;
  const h = Math.floor(min / 60);
  const rest = min % 60;
  return lang === 'ta' ? `${h} மணி ${rest} நிமிடம்` : `${h} hour${h === 1 ? '' : 's'} ${rest} minutes`;
}

/* ------------------------------ device ------------------------------ */

export async function getCurrentCoords(): Promise<Coords> {
  try {
    const perm = await Location.requestForegroundPermissionsAsync();
    if (perm.status !== 'granted') throw new NavError('denied');
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    return { lat: pos.coords.latitude, lng: pos.coords.longitude };
  } catch (e) {
    if (e instanceof NavError) throw e;
    throw new NavError('unavailable');
  }
}

/** Compass heading in degrees, or null when the device cannot provide it (e.g. web). */
export async function getHeading(): Promise<number | null> {
  if (Platform.OS === 'web') return null;
  try {
    const h = await Location.getHeadingAsync();
    const v = h.trueHeading >= 0 ? h.trueHeading : h.magHeading;
    return typeof v === 'number' && v >= 0 ? v : null;
  } catch {
    return null;
  }
}

/* ------------------------------ Nominatim ------------------------------ */

const NOMINATIM = 'https://nominatim.openstreetmap.org';

async function getJson(url: string, init?: RequestInit): Promise<any> {
  try {
    const res = await fetch(url, init);
    if (!res.ok) throw new NavError('network');
    return await res.json();
  } catch (e) {
    if (e instanceof NavError) throw e;
    throw new NavError('network');
  }
}

/** "Near Anna Salai, Teynampet, Chennai." */
export async function whereAmI(c: Coords, lang: AppLanguage): Promise<string> {
  const data = await getJson(
    `${NOMINATIM}/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=${lang}&lat=${c.lat}&lon=${c.lng}`
  );
  const a = data.address ?? {};
  const road = a.road || a.pedestrian || a.footway || a.path;
  const area = a.neighbourhood || a.suburb || a.quarter || a.village;
  const city = a.city || a.town || a.city_district || a.county || a.state_district;
  const poi = data.name && data.name !== road ? data.name : a.amenity || a.shop || a.building;
  const parts = [poi, road, area, city].filter((p, i, arr) => p && arr.indexOf(p) === i);
  if (parts.length === 0) {
    return lang === 'ta' ? 'உங்கள் இருப்பிடத்தை என்னால் பெயரிட முடியவில்லை.' : 'I could not work out a name for where you are.';
  }
  return lang === 'ta' ? `நீங்கள் ${parts.join(', ')} அருகில் இருக்கிறீர்கள்.` : `You are near ${parts.join(', ')}.`;
}

export async function searchPlaces(query: string, near: Coords | null, lang: AppLanguage): Promise<Place[]> {
  const params = new URLSearchParams({
    format: 'jsonv2',
    q: query,
    limit: '5',
    countrycodes: 'in',
    addressdetails: '0',
    'accept-language': lang,
  });
  if (near) {
    // Prefer results within ~50 km of the user, but do not exclude farther ones.
    const d = 0.45;
    params.set('viewbox', `${near.lng - d},${near.lat + d},${near.lng + d},${near.lat - d}`);
  }
  const data: any[] = await getJson(`${NOMINATIM}/search?${params.toString()}`);
  return data
    .map((r) => {
      const c = { lat: parseFloat(r.lat), lng: parseFloat(r.lon) };
      const [first, ...rest] = String(r.display_name).split(',');
      const place: Place = {
        id: String(r.place_id),
        name: r.name || first.trim(),
        address: rest.slice(0, 3).join(',').trim() || undefined,
        ...c,
      };
      if (near) {
        place.distanceM = haversine(near, c);
        place.bearing = bearingBetween(near, c);
      }
      return place;
    })
    .sort((a, b) => (a.distanceM ?? 0) - (b.distanceM ?? 0));
}

/* ------------------------------ OSRM route ------------------------------ */

const OSRM_FOOT = 'https://routing.openstreetmap.de/routed-foot/route/v1/foot';

const TURN_EN: Record<string, string> = {
  left: 'Turn left',
  right: 'Turn right',
  'slight left': 'Bear left',
  'slight right': 'Bear right',
  'sharp left': 'Turn sharp left',
  'sharp right': 'Turn sharp right',
  straight: 'Continue straight',
  uturn: 'Make a U-turn',
};
const TURN_TA: Record<string, string> = {
  left: 'இடதுபுறம் திரும்புங்கள்',
  right: 'வலதுபுறம் திரும்புங்கள்',
  'slight left': 'சற்று இடதுபுறம் செல்லுங்கள்',
  'slight right': 'சற்று வலதுபுறம் செல்லுங்கள்',
  'sharp left': 'கூர்மையாக இடதுபுறம் திரும்புங்கள்',
  'sharp right': 'கூர்மையாக வலதுபுறம் திரும்புங்கள்',
  straight: 'நேராகச் செல்லுங்கள்',
  uturn: 'திரும்பிச் செல்லுங்கள்',
};

function instructionFor(step: any, lang: AppLanguage): string {
  const ta = lang === 'ta';
  const m = step.maneuver ?? {};
  const name: string = step.name ? String(step.name) : '';
  const onEn = name ? ` onto ${name}` : '';
  const onTa = name ? `${name} சாலையில் ` : '';
  const turn = ta ? TURN_TA[m.modifier] : TURN_EN[m.modifier];

  switch (m.type) {
    case 'depart': {
      const dir = compassWord(m.bearing_after ?? 0, lang);
      return ta ? `${onTa}${dir} நோக்கி நடக்கத் தொடங்குங்கள்` : `Start walking ${dir}${name ? ` on ${name}` : ''}`;
    }
    case 'arrive':
      if (m.modifier === 'left') return ta ? 'நீங்கள் சேருமிடத்தை அடைந்துவிட்டீர்கள். அது உங்கள் இடதுபுறம் உள்ளது.' : 'You have arrived. Your destination is on your left.';
      if (m.modifier === 'right') return ta ? 'நீங்கள் சேருமிடத்தை அடைந்துவிட்டீர்கள். அது உங்கள் வலதுபுறம் உள்ளது.' : 'You have arrived. Your destination is on your right.';
      return ta ? 'நீங்கள் சேருமிடத்தை அடைந்துவிட்டீர்கள்.' : 'You have arrived at your destination.';
    case 'roundabout':
    case 'rotary':
      return ta
        ? `ரவுண்டானாவில் ${m.exit ?? 1}-வது வெளியேற்றத்தில் செல்லுங்கள்`
        : `At the roundabout, take exit ${m.exit ?? 1}`;
    case 'new name':
    case 'continue':
      return ta ? `${onTa}நேராகத் தொடருங்கள்` : `Continue straight${name ? ` on ${name}` : ''}`;
    default:
      if (turn) return ta ? `${onTa}${turn}` : `${turn}${onEn}`;
      return ta ? `${onTa}தொடருங்கள்` : `Continue${name ? ` on ${name}` : ''}`;
  }
}

export async function walkingRoute(from: Coords, to: Place, lang: AppLanguage): Promise<Route> {
  const data = await getJson(
    `${OSRM_FOOT}/${from.lng},${from.lat};${to.lng},${to.lat}?steps=true&overview=false&alternatives=false`
  );
  const leg = data?.routes?.[0]?.legs?.[0];
  if (!leg?.steps?.length) throw new NavError('no-route');

  const steps: RouteStep[] = leg.steps.map((s: any) => ({
    instruction: instructionFor(s, lang),
    at: { lat: s.maneuver.location[1], lng: s.maneuver.location[0] },
    distanceM: s.distance,
    durationS: s.duration,
  }));
  return {
    destination: to.name,
    steps,
    totalDistanceM: data.routes[0].distance,
    totalDurationS: data.routes[0].duration,
  };
}

/* ------------------------------ Overpass ------------------------------ */

const OVERPASS = 'https://overpass-api.de/api/interpreter';

const NEARBY_FILTERS: Record<NearbyKind, string[]> = {
  hospital: ['[amenity~"^(hospital|clinic)$"]'],
  pharmacy: ['[amenity=pharmacy]'],
  restaurant: ['[amenity~"^(restaurant|cafe|fast_food)$"]'],
  transit: ['[highway=bus_stop]', '[railway=station]', '[railway=subway_entrance]'],
  atm: ['[amenity=atm]'],
  toilets: ['[amenity=toilets]'],
  shopping: ['[shop~"^(supermarket|mall|convenience|department_store)$"]'],
};

const KIND_FALLBACK_NAME: Record<NearbyKind, [string, string]> = {
  hospital: ['Hospital or clinic', 'மருத்துவமனை'],
  pharmacy: ['Pharmacy', 'மருந்தகம்'],
  restaurant: ['Restaurant', 'உணவகம்'],
  transit: ['Transit stop', 'போக்குவரத்து நிறுத்தம்'],
  atm: ['ATM', 'ஏடிஎம்'],
  toilets: ['Public toilet', 'பொதுக் கழிவறை'],
  shopping: ['Shop', 'கடை'],
};

export async function nearbyPlaces(kind: NearbyKind, from: Coords, lang: AppLanguage, radiusM = 1500): Promise<Place[]> {
  const around = `(around:${radiusM},${from.lat},${from.lng})`;
  const body = `[out:json][timeout:20];(${NEARBY_FILTERS[kind].map((f) => `nwr${f}${around};`).join('')});out center 40;`;
  const data = await getJson(OVERPASS, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `data=${encodeURIComponent(body)}`,
  });

  const fallback = KIND_FALLBACK_NAME[kind][lang === 'ta' ? 1 : 0];
  const seen = new Set<string>();
  const places: Place[] = [];
  for (const el of data.elements ?? []) {
    const lat = el.lat ?? el.center?.lat;
    const lng = el.lon ?? el.center?.lon;
    if (lat == null || lng == null) continue;
    const tags = el.tags ?? {};
    const name: string = (lang === 'ta' ? tags['name:ta'] : tags['name:en']) || tags.name || fallback;
    const key = `${name}|${lat.toFixed(4)}|${lng.toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const c = { lat, lng };
    places.push({
      id: `${el.type}-${el.id}`,
      name,
      lat,
      lng,
      distanceM: haversine(from, c),
      bearing: bearingBetween(from, c),
    });
  }
  return places.sort((a, b) => (a.distanceM ?? 0) - (b.distanceM ?? 0)).slice(0, 8);
}

export function navErrorMessage(e: unknown, lang: AppLanguage): string {
  const ta = lang === 'ta';
  const kind = e instanceof NavError ? e.kind : 'unavailable';
  switch (kind) {
    case 'denied':
      return ta ? 'இருப்பிட அனுமதி மறுக்கப்பட்டது. தொலைபேசி அமைப்புகளில் அனுமதியுங்கள்.' : 'Location permission was denied. Please allow it in your phone settings.';
    case 'no-route':
      return ta ? 'அந்த இடத்திற்கு நடைபாதை வழியைக் கண்டுபிடிக்க முடியவில்லை.' : 'I could not find a walking route to that place.';
    case 'network':
      return ta ? 'வரைபடச் சேவையை அடைய முடியவில்லை. இணையத்தைச் சரிபார்க்கவும்.' : 'I could not reach the map service. Please check your internet.';
    default:
      return ta ? 'உங்கள் இருப்பிடத்தைப் பெற முடியவில்லை. GPS-ஐ இயக்கி வெளியில் முயற்சிக்கவும்.' : 'I could not get your location. Turn on GPS and try again, ideally outdoors.';
  }
}
