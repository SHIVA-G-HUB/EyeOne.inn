// Supabase Edge Function: EyeOne vision.
// Receives one photo + a mode and returns a spoken-style description from GPT-4o (vision).
//   supabase secrets set OPENAI_API_KEY=sk-...
//   supabase functions deploy vision
// @ts-nocheck  (Deno runtime)

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const MAX_IMAGE_CHARS = 6_000_000; // ~4.5 MB of image data as base64

const speakingRules = (language: string) => `
You are the eyes of a blind or low-vision person in India. Your answer is read aloud by text-to-speech.
- Reply in ${language === 'ta' ? 'Tamil (தமிழ்)' : 'English'}.
- Plain spoken sentences. No markdown, no bullet symbols, no emojis, no headings.
- Be accurate first. Never invent details. If something is unclear, blurry, cut off or too dark, say so and tell the person how to fix it, for example "move the phone a little to the left" or "turn on the light".
- Do not identify real people by their face. You may describe them: how many, what they wear, what they are doing, roughly how far away.
- Do not give medical, legal or financial advice from a photo; describe what is visible and suggest asking a professional.`;

const modePrompts: Record<string, string> = {
  scene: `Describe the scene in front of the person, like a helpful friend guiding them.
Start with one short sentence that says where they seem to be and what the main thing is.
Then give the useful details in order of importance: anything that could be a hazard or obstacle (steps, holes, vehicles, wet floor, low objects), doors and paths, people, then notable objects and their positions using clock positions or left, right and ahead.
Read any clearly visible sign or text. Keep it under 120 words unless the scene is very busy.`,

  text: `Read out the text that is visible in the photo, exactly as written, in natural reading order.
If it is a sign, label, menu, packet, medicine strip or price tag, say what kind of item it is in a few words first, then read the text.
For medicine, read the name, strength and any expiry date, and do not give dosage advice.
If some text is cut off or blurry, read what you can and say which part is missing and how to reposition the phone.
If there is no readable text, say so.`,

  document: `This is a photo of a document or page. Read it in full, in the correct reading order, including headings, paragraphs, tables (row by row) and any amounts, dates and phone numbers.
Begin with one short sentence saying what kind of document it is. If the page is cut off, tell the person which edge to move the phone toward.`,

  currency: `Identify Indian rupee banknotes and coins in the photo.
For each one say the denomination. If there are several, give a total at the end.
If you are not certain about any note or coin, say that you are not sure and ask the person to hold it flat, in good light, filling the frame. Never guess an amount. If the note is folded, say which part is hidden.`,

  color: `Tell the person the colours in the photo. If one item is the main subject, such as a shirt or a fruit, name its main colour first, then any pattern or secondary colours, using everyday colour names.
Mention if the lighting may be changing how the colours look.`,

  ask: `The person is asking a question about this photo. Answer only their question, directly and briefly, using what is visible. If the photo does not show enough to answer, say so and suggest what to photograph.`,
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors });

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

  try {
    const { image, mimeType, mode, language, question, previous } = await req.json();

    if (typeof image !== 'string' || image.length < 100 || image.length > MAX_IMAGE_CHARS) {
      return json({ error: 'Invalid image' }, 400);
    }
    const safeMime = ['image/jpeg', 'image/png', 'image/webp'].includes(mimeType) ? mimeType : 'image/jpeg';
    const safeMode = modePrompts[mode] ? mode : 'scene';
    const lang = language === 'ta' ? 'ta' : 'en';

    let userText = modePrompts[safeMode];
    if (safeMode === 'ask') {
      const q = typeof question === 'string' ? question.slice(0, 500) : '';
      if (!q) return json({ error: 'Missing question' }, 400);
      userText += `\n\nQuestion: ${q}`;
      if (typeof previous === 'string' && previous) {
        userText += `\n\nFor context, you already described this photo as: ${previous.slice(0, 1500)}`;
      }
    }

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      },
      body: JSON.stringify({
        model: Deno.env.get('OPENAI_VISION_MODEL') ?? 'gpt-4o',
        temperature: 0.2,
        max_tokens: safeMode === 'document' ? 900 : 450,
        messages: [
          { role: 'system', content: speakingRules(lang) },
          {
            role: 'user',
            content: [
              { type: 'text', text: userText },
              {
                type: 'image_url',
                image_url: {
                  url: `data:${safeMime};base64,${image}`,
                  detail: safeMode === 'scene' || safeMode === 'color' ? 'auto' : 'high',
                },
              },
            ],
          },
        ],
      }),
    });

    if (!res.ok) return json({ error: 'Upstream error' }, 502);
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content?.trim() ?? '';
    if (!text) return json({ error: 'Empty reply' }, 502);
    return json({ text });
  } catch {
    return json({ error: 'Bad request' }, 400);
  }
});
