/**
 * Server endpoints. Everything hangs off one Supabase project:
 *   EXPO_PUBLIC_EYO_API_URL = https://<project>.supabase.co/functions/v1/eyo
 * The vision and news functions are derived from it unless overridden.
 */
const EYO = process.env.EXPO_PUBLIC_EYO_API_URL;

const sibling = (name: string): string | undefined =>
  EYO ? EYO.replace(/\/eyo\/?$/, `/${name}`) : undefined;

export const EYO_URL = EYO;
export const VISION_URL = process.env.EXPO_PUBLIC_VISION_API_URL || sibling('vision');
export const NEWS_URL = process.env.EXPO_PUBLIC_NEWS_API_URL || sibling('news');
export const ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

export const authHeaders = (): Record<string, string> =>
  ANON_KEY ? { Authorization: `Bearer ${ANON_KEY}`, apikey: ANON_KEY } : {};
