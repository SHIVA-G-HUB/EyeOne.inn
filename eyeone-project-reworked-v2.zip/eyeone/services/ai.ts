import { sampleNews, searchNews, NewsArticle } from './news';
import { AppLanguage } from '@/contexts/AccessibilityContext';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

interface Intent {
  type: 'read_news' | 'read_tamil_news' | 'read_english_news' | 'search_news' | 'open_map' | 'navigate' | 'summarize' | 'translate' | 'explain' | 'greeting' | 'help' | 'weather' | 'time' | 'unknown';
  params?: Record<string, string>;
}

const tamilKeywords = [
  'செய்தி', 'தமிழ்', 'வாசிக்க', 'திற', 'தேடு', 'வழி', 'உதவி', 'வணக்கம்',
  'முக்கிய', 'இன்றைய', 'சொல்', 'காட்டு', 'என்ன', 'எப்படி',
];

const englishKeywords = [
  'news', 'tamil', 'english', 'read', 'search', 'navigate', 'map',
  'help', 'hello', 'hi', 'today', 'latest', 'find', 'directions',
  'summarize', 'translate', 'explain', 'weather', 'time',
];

function detectIntent(text: string): Intent {
  const lower = text.toLowerCase().trim();

  // Greeting
  if (/^(hello|hi|hey|வணக்கம்|ஹாய்|வாங்க)/i.test(lower)) {
    return { type: 'greeting' };
  }

  // Help
  if (/help|உதவி|how do i|how to|எப்படி/i.test(lower)) {
    return { type: 'help' };
  }

  // Weather
  if (/weather|வானிலை|rain|temperature|மழை/i.test(lower)) {
    return { type: 'weather' };
  }

  // Time
  if (/what time|நேரம்|time now|current time/i.test(lower)) {
    return { type: 'time' };
  }

  // Navigate
  if (/navigate|directions|route|find.*near|take me|வழி|செல்ல|காட்டு|நடத்து/i.test(lower)) {
    const destMatch = text.match(/(?:to|near|சேருமிடம்|இடம்)\s+(.+)/i);
    return { type: 'navigate', params: { destination: destMatch?.[1]?.trim() || '' } };
  }

  // Map
  if (/open.*map|show.*map|வரைபடம்|map/i.test(lower)) {
    return { type: 'open_map' };
  }

  // Summarize
  if (/summarize|summary|சுருக்க|brief/i.test(lower)) {
    return { type: 'summarize' };
  }

  // Translate
  if (/translate|மொழிபெயர்/i.test(lower)) {
    return { type: 'translate' };
  }

  // Explain
  if (/explain|விளக்கு|simple|எளிமை/i.test(lower)) {
    return { type: 'explain' };
  }

  // Tamil news
  if (/tamil.*news|தமிழ்.*செய்தி|read.*tamil|தமிழ்.*வாசிக்க|தமிழ்.*செய்தி/i.test(lower)) {
    return { type: 'read_tamil_news' };
  }

  // English news
  if (/english.*news|read.*english/i.test(lower)) {
    return { type: 'read_english_news' };
  }

  // Search news
  const searchMatch = text.match(/(?:search|find|தேடு)\s+(?:for\s+|பற்றி\s+)?(.+)/i);
  if (searchMatch) {
    return { type: 'search_news', params: { query: searchMatch[1].trim() } };
  }

  // Read news
  if (/read.*news|today.*news|latest.*news|செய்தி.*வாசிக்க|இன்றைய.*செய்தி|முக்கிய.*செய்தி/i.test(lower)) {
    return { type: 'read_news' };
  }

  // Check for Tamil keywords
  const hasTamil = tamilKeywords.some((kw) => text.includes(kw));
  const hasEnglish = englishKeywords.some((kw) => lower.includes(kw));

  if (hasTamil && !hasEnglish) {
    if (/செய்தி|வாசிக்க|திற/i.test(text)) return { type: 'read_tamil_news' };
    if (/வழி|செல்ல|காட்டு|நடத்து/i.test(text)) return { type: 'navigate' };
    return { type: 'read_tamil_news' };
  }

  return { type: 'unknown' };
}

function generateResponse(intent: Intent, lang: AppLanguage): string {
  const isTamil = lang === 'ta';

  switch (intent.type) {
    case 'greeting':
      return isTamil
        ? 'வணக்கம்! நான் உங்கள் அணுகல் உதவியாளர். நான் உங்களுக்கு எப்படி உதவ வேண்டும்? செய்திகளைப் படிக்க, வழிகாட்டியைப் பயன்படுத்த, அல்லது கேள்விகள் கேட்க முடியும்.'
        : 'Hello! I am your accessibility assistant. How can I help you? I can read news, help with navigation, or answer your questions.';

    case 'help':
      return isTamil
        ? 'நான் இவற்றை செய்ய முடியும்:\n• "தமிழ் செய்திகளை படி" - தமிழ் செய்திகளை படிக்க\n• "Read English news" - ஆங்கில செய்திகளை படிக்க\n• "Search Chennai news" - செய்திகளை தேட\n• "Navigate to Chennai Central" - வழிகாட்டியை தொடங்க\n• "Summarize" - கட்டுரையை சுருக்க'
        : 'I can help you with:\n• "Read Tamil news" - Read news in Tamil\n• "Read English news" - Read news in English\n• "Search Chennai news" - Search for news\n• "Navigate to Chennai Central" - Start navigation\n• "Summarize" - Summarize an article';

    case 'read_news':
    case 'read_tamil_news': {
      const articles = sampleNews.slice(0, 5);
      if (isTamil) {
        let response = 'இன்றைய முக்கிய செய்திகள்:\n\n';
        articles.forEach((a, i) => {
          response += `${i + 1}. ${a.titleTamil || a.title}. ${a.summaryTamil || a.summary}\n\n`;
        });
        response += 'மேலும் கேட்க விரும்புகிறீர்களா?';
        return response;
      }
      let response = 'Here are today\'s top news:\n\n';
      articles.forEach((a, i) => {
        response += `${i + 1}. ${a.title}. ${a.summary}\n\n`;
      });
      response += 'Would you like to hear more?';
      return response;
    }

    case 'read_english_news': {
      const articles = sampleNews.slice(0, 5);
      let response = 'Here are the latest English news:\n\n';
      articles.forEach((a, i) => {
        response += `${i + 1}. ${a.title}. ${a.summary}\n\n`;
      });
      return response;
    }

    case 'search_news': {
      const query = intent.params?.query || '';
      const results = searchNews(query);
      if (results.length === 0) {
        return isTamil
          ? `"${query}" பற்றி எந்த செய்தியும் இல்லை. வேறு தலைப்பை முயற்சிக்கவும்.`
          : `No news found for "${query}". Try a different topic.`;
      }
      if (isTamil) {
        let response = `"${query}" பற்றிய செய்திகள்:\n\n`;
        results.forEach((a, i) => {
          response += `${i + 1}. ${a.titleTamil || a.title}\n`;
        });
        return response;
      }
      let response = `News about "${query}":\n\n`;
      results.forEach((a, i) => {
        response += `${i + 1}. ${a.title}\n`;
      });
      return response;
    }

    case 'navigate':
      return isTamil
        ? 'வழிகாட்டியை திறக்கிறேன். சேருமிடத்தை உள்ளிடவும் அல்லது "தற்போதைய இடத்தை பயன்படுத்து" என்று சொல்லுங்கள்.'
        : 'Opening navigation. Please enter a destination or say "use current location".';

    case 'open_map':
      return isTamil
        ? 'வரைபடத்தை திறக்கிறேன்.'
        : 'Opening the map.';

    case 'summarize':
      return isTamil
        ? 'எந்த கட்டுரையை சுருக்க வேண்டும்? தயவுசெய்து கட்டுரையைத் தேர்வு செய்யவும்.'
        : 'Which article would you like me to summarize? Please select an article from the news section.';

    case 'translate':
      return isTamil
        ? 'எந்த கட்டுரையை மொழிபெயர் வேண்டும்? தயவுசெய்து கட்டுரையைத் தேர்வு செய்யவும்.'
        : 'Which article would you like me to translate? Please select an article from the news section.';

    case 'explain':
      return isTamil
        ? 'எந்த கட்டுரையை எளிமையாக விளக்க வேண்டும்?'
        : 'Which article would you like me to explain simply?';

    case 'weather':
      return isTamil
        ? 'தற்போது வானிலை தகவல் கிடைக்கவில்லை. தயவுசெய்து வானிலை பயன்பாட்டை பார்க்கவும்.'
        : 'Weather information is not available right now. Please check the weather section for updates.';

    case 'time':
      return isTamil
        ? `தற்போதைய நேரம் ${new Date().toLocaleTimeString('ta-IN')}.`
        : `The current time is ${new Date().toLocaleTimeString('en-US')}.`;

    case 'unknown':
    default:
      return isTamil
        ? 'மன்னிக்கவும், நான் புரிந்துகொள்ளவில்லை. இணையம் இல்லாதபோது சில கட்டளைகளை மட்டுமே புரிந்துகொள்வேன். "எதிரில் என்ன இருக்கிறது", "இதைப் படி", "நான் எங்கே இருக்கிறேன்", அல்லது "அவசரம்" என்று சொல்லிப் பாருங்கள்.'
        : 'Sorry, I didn\'t catch that. Without internet I only understand a few commands. Try "What is in front of me", "Read this", "Where am I", or "Emergency".';
  }
}

export function processAICommand(text: string, lang: AppLanguage): string {
  const intent = detectIntent(text);
  return generateResponse(intent, lang);
}

export function getAssistantGreeting(lang: AppLanguage): string {
  return lang === 'ta'
    ? 'வணக்கம்! நான் உங்கள் அணுகல் உதவியாளர். நான் எப்படி உதவ வேண்டும்?'
    : 'Hello! I am your accessibility assistant. How can I help you today?';
}
