import { NEWS_URL, authHeaders } from './config';
import type { AppLanguage } from '@/contexts/AccessibilityContext';

export interface NewsArticle {
  id: string;
  title: string;
  titleTamil?: string;
  summary: string;
  summaryTamil?: string;
  content: string;
  contentTamil?: string;
  category: string;
  categoryKey: string;
  language: 'en' | 'ta' | 'both';
  publishedAt: string;
  source: string;
  imageUrl?: string;
  readTime: number;
  link?: string;
}

export interface NewsCategory {
  key: string;
  labelEn: string;
  labelTa: string;
  icon: string;
}

export const newsCategories: NewsCategory[] = [
  { key: 'tamil-nadu', labelEn: 'Tamil Nadu', labelTa: 'தமிழ்நாடு', icon: 'map-pin' },
  { key: 'medical', labelEn: 'Medical', labelTa: 'மருத்துவம்', icon: 'stethoscope' },
  { key: 'india', labelEn: 'India', labelTa: 'இந்தியா', icon: 'flag' },
  { key: 'world', labelEn: 'World', labelTa: 'உலகம்', icon: 'globe' },
  { key: 'politics', labelEn: 'Politics', labelTa: 'அரசியல்', icon: 'landmark' },
  { key: 'business', labelEn: 'Business', labelTa: 'வணிகம்', icon: 'briefcase' },
  { key: 'technology', labelEn: 'Technology', labelTa: 'தொழில்நுட்பம்', icon: 'cpu' },
  { key: 'sports', labelEn: 'Sports', labelTa: 'விளையாட்டு', icon: 'trophy' },
  { key: 'education', labelEn: 'Education', labelTa: 'கல்வி', icon: 'graduation-cap' },
  { key: 'health', labelEn: 'Health', labelTa: 'சுகாதாரம்', icon: 'heart-pulse' },
  { key: 'entertainment', labelEn: 'Entertainment', labelTa: 'பொழுதுபோக்கு', icon: 'film' },
  { key: 'weather', labelEn: 'Weather', labelTa: 'வானிலை', icon: 'cloud-rain' },
  { key: 'government', labelEn: 'Government', labelTa: 'அரசு', icon: 'building-2' },
];

function timeAgo(hours: number): string {
  const date = new Date();
  date.setHours(date.getHours() - hours);
  return date.toISOString();
}

export const sampleNews: NewsArticle[] = [
  {
    id: '1',
    title: 'Chennai Receives Heavy Rainfall as Northeast Monsoon Intensifies',
    titleTamil: 'வடகிழக்கு பருவமழை தீவிரமடைய சென்னையில் பலத்த மழை',
    summary: 'Chennai and surrounding districts experienced heavy rainfall overnight as the Northeast monsoon intensified. The Met department has issued a red alert for coastal areas.',
    summaryTamil: 'வடகிழக்கு பருவமழை தீவிரமடைந்ததால் சென்னை மற்றும் சுற்றுப்புற மாவட்டங்களில் இரவில் பலத்த மழை பெய்தது. கடற்கரை பகுதிகளுக்கு வானிலை துறை சிவப்பு எச்சரிக்கை வெளியிட்டுள்ளது.',
    content: 'Chennai and several coastal districts of Tamil Nadu experienced heavy to very heavy rainfall overnight as the Northeast monsoon intensified over the region. According to the Regional Meteorological Centre, Nungambakkam recorded 12 cm of rainfall in the 24 hours ending 8:30 AM, while Meenambakkam recorded 9.5 cm. The India Meteorological Department (IMD) has issued a red alert for Chennai, Chengalpattu, Kancheepuram, and Tiruvallur districts for the next 48 hours. Schools and colleges in these districts have been declared closed. The Greater Chennai Corporation has deployed 76 motor pumps to clear waterlogging in low-lying areas. Residents are advised to stay indoors and avoid traveling unless necessary. The state government has set up relief camps in vulnerable areas and emergency helpline numbers 1070 and 1913 have been activated for public assistance.',
    contentTamil: 'வடகிழக்கு பருவமழை தீவிரமடைந்ததால் சென்னை மற்றும் தமிழ்நாட்டின் பல கடற்கரை மாவட்டங்களில் இரவில் பலத்த மழை பெய்தது. பிராந்திய வானிலை மையத்தின்படி, நுங்கம்பாக்கத்தில் 24 மணிநேரத்தில் 12 செ.மீ மழை பதிவாகியுள்ளது. இந்திய வானிலை துறை சென்னை, செங்கல்பட்டு, காஞ்சிபுரம், திருவள்ளூர் மாவட்டங்களுக்கு சிவப்பு எச்சரிக்கை வெளியிட்டுள்ளது. இந்த மாவட்டங்களில் பள்ளி கல்லூரிகளுக்கு விடுமுறை அறிவிக்கப்பட்டுள்ளது.',
    category: 'Tamil Nadu',
    categoryKey: 'tamil-nadu',
    language: 'both',
    publishedAt: timeAgo(2),
    source: 'News Tamil',
    readTime: 3,
  },
  {
    id: '2',
    title: 'ISRO Successfully Launches PSLV-C58 with X-Ray Polarimeter Satellite',
    titleTamil: 'ஐஸ்ரோ பிஎஸ்எல்வி-சி58 ஏவுகணை வெற்றிகரமாக ஏவியது',
    summary: 'The Indian Space Research Organisation successfully launched the PSLV-C58 carrying the X-Ray Polarimeter Satellite (XPoSat) from Sriharikota.',
    summaryTamil: 'இந்திய விண்வெளி ஆராய்ச்சி நிறுவனம் ஸ்ரீஹரிக்கோட்டாவில் இருந்து எக்ஸ்-ரே போலாரிமீட்டர் செயற்கைக்கோளை தாங்கிய பிஎஸ்எல்வி-சி58 ஏவுகணையை வெற்றிகரமாக ஏவியது.',
    content: 'The Indian Space Research Organisation (ISRO) achieved another milestone with the successful launch of PSLV-C58 from the Satish Dhawan Space Centre in Sriharikota. The rocket carried the X-Ray Polarimeter Satellite (XPoSat), Indias first dedicated polarimetry mission to study the polarization of cosmic X-rays. The satellite was placed in a 650 km orbit with a 6-degree inclination. XPoSat carries two scientific payloads: POLIX (Polarimeter Instrument in X-rays) and XSPECT (X-ray Spectroscopy and Timing). The mission aims to study bright astronomical X-ray sources in the energy band 8-30 keV. This launch marks the 60th flight of the PSLV and the fourth mission of PSLV-DL variant.',
    contentTamil: 'இந்திய விண்வெளி ஆராய்ச்சி நிறுவனம் ஸ்ரீஹரிக்கோட்டாவில் இருந்து பிஎஸ்எல்வி-சி58 ஏவுகணையை வெற்றிகரமாக ஏவியது. இந்த ஏவுகணை எக்ஸ்-ரே போலாரிமீட்டர் செயற்கைக்கோளை தாங்கிச் சென்றது. இது இந்தியாவின் முதல் பிரத்யேக போலாரிமெட்ரி பணியாகும்.',
    category: 'Technology',
    categoryKey: 'technology',
    language: 'both',
    publishedAt: timeAgo(5),
    source: 'Science Today',
    readTime: 4,
  },
  {
    id: '3',
    title: 'RBI Maintains Repo Rate at 6.5% in Latest Monetary Policy Review',
    titleTamil: 'ரிசர்வ் வங்கி ரெப்போ வட்டி விகிதம் 6.5% மாற்றமின்றி',
    summary: 'The Reserve Bank of India maintained the repo rate at 6.5% for the sixth consecutive time, citing inflation concerns and global economic uncertainty.',
    summaryTamil: 'இந்திய ரிசர்வ் வங்கி பணவீக்கம் மற்றும் உலக பொருளாதார நிச்சயமற்ற தன்மையை காரணம் காட்டி ஆறாவது முறையாக ரெப்போ வட்டி விகிதத்தை 6.5% மாற்றமின்றி வைத்திருக்கிறது.',
    content: 'The Reserve Bank of India (RBI) in its latest Monetary Policy Committee (MPC) meeting decided to keep the repo rate unchanged at 6.5% for the sixth consecutive time. The decision was unanimous among all six MPC members. The RBI cited persistent food inflation and global economic uncertainties as key factors. GDP growth projection for FY25 has been maintained at 7%. The CPI inflation forecast has been revised slightly upward to 5.4% from 5.3%. RBI Governor Shaktikanta Das emphasized that the central bank remains focused on withdrawing accommodation to align inflation with the 4% target while supporting growth.',
    contentTamil: 'இந்திய ரிசர்வ் வங்கி பணவீக்க கட்டுப்பாட்டு குழு கூட்டத்தில் ரெப்போ வட்டி விகிதத்தை 6.5% மாற்றமின்றி வைத்திருக்க ஒருமனதாக முடிவு செய்தது. பணவீக்கம் 4% இலக்கை நோக்கி கொண்டு வர வங்கி கவனம் செலுத்துவதாக ஆளுநர் சக்திகாந்த தாஸ் தெரிவித்தார்.',
    category: 'Business',
    categoryKey: 'business',
    language: 'both',
    publishedAt: timeAgo(8),
    source: 'Economic Wire',
    readTime: 3,
  },
  {
    id: '4',
    title: 'Tamil Nadu Government Announces Free Bus Travel for Women Completes Four Years',
    titleTamil: 'தமிழ்நாடு அரசின் பெண்களுக்கு இலவச பேருந்து பயணம் நான்கு ஆண்டுகள் நிறைவடைந்தது',
    summary: 'The Tamil Nadu governments free bus travel scheme for women has completed four years, benefiting over 200 crore women passengers across the state.',
    summaryTamil: 'தமிழ்நாடு அரசின் பெண்களுக்கான இலவச பேருந்து பயணத் திட்டம் நான்கு ஆண்டுகளை நிறைவு செய்துள்ளது. மாநிலம் முழுவதும் 200 கோடிக்கும் மேற்பட்ட பெண் பயணிகள் பயன்பெற்றுள்ளனர்.',
    content: 'The Tamil Nadu governments flagship free bus travel scheme for women has completed four successful years. Launched on February 21, 2021, the scheme has benefited over 200 crore women passengers across the state. The government has spent approximately Rs 5,800 crore on the scheme so far. According to official data, Chennai, Coimbatore, and Madurai account for the highest usage. The scheme allows women to travel free of cost in ordinary and express buses operated by state transport corporations. The government has also announced plans to introduce dedicated women-only buses on select routes during peak hours.',
    contentTamil: 'தமிழ்நாடு அரசின் முதன்மை திட்டமான பெண்களுக்கான இலவச பேருந்து பயணத் திட்டம் நான்கு ஆண்டுகளை வெற்றிகரமாக நிறைவு செய்துள்ளது. இதுவரை சுமார் 5,800 கோடி ரூபாய் செலவிடப்பட்டுள்ளது.',
    category: 'Tamil Nadu',
    categoryKey: 'tamil-nadu',
    language: 'both',
    publishedAt: timeAgo(12),
    source: 'Daily Tamil',
    readTime: 3,
  },
  {
    id: '5',
    title: 'India Wins Test Series Against Australia 2-1 in Thrilling Finale',
    titleTamil: 'இந்தியா ஆஸ்திரேலியாவை 2-1 என்ற கணக்கில் தோற்கடித்து தொடரை வென்றது',
    summary: 'India clinched a historic Test series victory against Australia, winning the final match by 7 wickets in a thrilling contest.',
    summaryTamil: 'இந்தியா ஆஸ்திரேலியாவை இறுதி போட்டியில் 7 விக்கெட் வித்தியாசத்தில் வென்று வரலாற்று சிறப்பு வெற்றி பெற்றது.',
    content: 'India secured a historic Test series victory against Australia, winning the final and deciding match by 7 wickets. Chasing a target of 275, India reached 278 for 3 in the final session of day five. The captain led from the front with a magnificent century, while the vice-captain provided crucial support with a well-made 78. The bowlers had earlier bundled out Australia for 291 in the second innings, with the spinner claiming 5 wickets. This series win marks Indias fourth consecutive Test series victory on Australian soil, a record unmatched by any other visiting team.',
    contentTamil: 'இந்தியா ஆஸ்திரேலியாவை இறுதி போட்டியில் 7 விக்கெட் வித்தியாசத்தில் வென்றது. 275 இலக்கை நோக்கி துரதிய 5-வது நாள் இறுதி அமர்வில் 278/3 என்ற கணக்கில் வெற்றி பெற்றது. இந்திய கேப்டன் சதம் அடித்து அணியை வழிநடத்தினார்.',
    category: 'Sports',
    categoryKey: 'sports',
    language: 'both',
    publishedAt: timeAgo(16),
    source: 'Sports Central',
    readTime: 3,
  },
  {
    id: '6',
    title: 'New Education Policy Implementation: Tamil Nadu Seeks Additional Time',
    titleTamil: 'புதிய கல்விக் கொள்கை செயல்படுத்தம்: தமிழ்நாடு கூடுதல் நேரம் கோரியது',
    summary: 'The Tamil Nadu government has requested additional time from the Centre to implement the New Education Policy, citing the need for detailed consultations.',
    summaryTamil: 'தமிழ்நாடு அரசு புதிய கல்விக் கொள்கையை செயல்படுத்த மத்திய அரசிடம் கூடுதல் நேரம் கோரியுள்ளது. விரிவான ஆலோசனை தேவை என்று கூறியுள்ளது.',
    content: 'The Tamil Nadu government has formally requested the Union Education Ministry for additional time to implement the New Education Policy (NEP) 2020. The state has expressed concerns over certain provisions, particularly the three-language formula and the 5+3+3+4 structure. The state government has constituted a committee to study the implications and submit a report. Education Minister said the state is committed to improving education quality but wants to ensure that the unique two-language system and social justice principles are not compromised. The Centre has indicated willingness to consider state-specific concerns.',
    contentTamil: 'தமிழ்நாடு அரசு புதிய கல்விக் கொள்கை 2020-ஐ செயல்படுத்த மத்திய கல்வி அமைச்சகத்திடம் கூடுதல் நேரம் கோரியுள்ளது. மூன்று மொழி கொள்கை மற்றும் 5+3+3+4 அமைப்பு குறித்து கவலை தெரிவித்துள்ளது.',
    category: 'Education',
    categoryKey: 'education',
    language: 'both',
    publishedAt: timeAgo(20),
    source: 'Education Times',
    readTime: 3,
  },
  {
    id: '7',
    title: 'World Leaders Gather for Climate Summit as Global Temperatures Rise',
    titleTamil: 'உலக வெப்பநிலை உயர்வால் உலகத் தலைவர்கள் காலநிலை உச்சி கூட்டத்தில் ஒன்றுகூடுகிறார்கள்',
    summary: 'World leaders from over 190 countries have gathered for the annual climate summit to discuss urgent action on rising global temperatures.',
    summaryTamil: '190-க்கும் மேற்பட்ட நாடுகளின் தலைவர்கள் உலக வெப்பநிலை உயர்வை கட்டுப்படுத்த அவசர நடவடிக்கை பற்றி விவாதிக்க வாரும் காலநிலை உச்சி கூட்டத்தில் ஒன்றுகூடியுள்ளனர்.',
    content: 'World leaders from over 190 countries have convened for the annual UN Climate Change Conference to discuss urgent measures to combat rising global temperatures. The summit focuses on accelerating the transition to renewable energy, increasing climate finance for developing nations, and setting more ambitious emission reduction targets. The UN Secretary-General warned that the world is off track to meet the Paris Agreement goals, with 2024 likely to be the hottest year on record. India has pledged to achieve net-zero emissions by 2070 and has called for developed nations to fulfill their $100 billion climate finance commitment.',
    contentTamil: '190-க்கும் மேற்பட்ட நாடுகளின் தலைவர்கள் உலக வெப்பநிலை உயர்வை எதிர்க்க அவசர நடவடிக்கைகள் பற்றி விவாதிக்க ஒன்றுகூடியுள்ளனர். இந்தியா 2070-க்குள் பூஜ்ஜிய உமிழ்வை அடைவதாக உறுதிமொழி ஏற்றுள்ளது.',
    category: 'World',
    categoryKey: 'world',
    language: 'both',
    publishedAt: timeAgo(24),
    source: 'World News',
    readTime: 4,
  },
  {
    id: '8',
    title: 'AI-Powered Eye Screening Camp Reaches 10,000 Rural Patients in Tamil Nadu',
    titleTamil: 'AI தொழில்நுட்ப கண் பரிசோதனை முகாம் தமிழ்நாட்டில் 10,000 கிராமப்புற நோயாளிகளை அடைந்தது',
    summary: 'An AI-powered eye screening initiative has successfully screened over 10,000 rural patients across Tamil Nadu for diabetic retinopathy and cataracts.',
    summaryTamil: 'AI தொழில்நுட்பம் கொண்ட கண் பரிசோதனை முயற்சி தமிழ்நாடு முழுவதும் 10,000-க்கும் மேற்பட்ட கிராமப்புற நோயாளிகளுக்கு டயாபெடிக் ரெட்டினோபதி மற்றும் கண்புரை பரிசோதனை செய்துள்ளது.',
    content: 'An innovative AI-powered eye screening initiative has successfully screened over 10,000 rural patients across Tamil Nadu for diabetic retinopathy and cataracts. The program, a collaboration between a leading eye hospital and a tech company, uses AI algorithms to analyze retinal images and detect eye conditions within minutes. The initiative has been particularly impactful in remote villages where access to ophthalmologists is limited. Of the 10,000 patients screened, approximately 1,200 were identified with early-stage diabetic retinopathy and 800 with cataracts. All identified patients have been referred for further treatment at no cost.',
    contentTamil: 'AI தொழில்நுட்பம் கொண்ட கண் பரிசோதனை முயற்சி தமிழ்நாடு முழுவதும் 10,000-க்கும் மேற்பட்ட கிராமப்புற நோயாளிகளுக்கு பரிசோதனை செய்துள்ளது. 1,200 பேருக்கு டயாபெடிக் ரெட்டினோபதி மற்றும் 800 பேருக்கு கண்புரை கண்டறியப்பட்டுள்ளது.',
    category: 'Health',
    categoryKey: 'health',
    language: 'both',
    publishedAt: timeAgo(30),
    source: 'Health Today',
    readTime: 3,
  },
  {
    id: '9',
    title: 'New Metro Rail Extension Opens in Chennai, Connecting Airport to City Center',
    titleTamil: 'சென்னையில் புதிய மெட்ரோ ரயில் நீட்டிப்பு திறக்கப்பட்டது: விமான நிலையத்தை நகர மையத்துடன் இணைக்கிறது',
    summary: 'The Chennai Metro Rail extension connecting the airport to the city center has opened to the public, reducing travel time to just 35 minutes.',
    summaryTamil: 'சென்னை விமான நிலையத்தை நகர மையத்துடன் இணைக்கும் மெட்ரோ ரயில் நீட்டிப்பு பொதுமக்களுக்கு திறக்கப்பட்டது. பயண நேரம் 35 நிமிடங்களாக குறைந்துள்ளது.',
    content: 'The long-awaited Chennai Metro Rail extension connecting Chennai International Airport to the city center has been inaugurated and opened to the public. The 22.5 km corridor with 17 stations reduces travel time from the airport to the city center to just 35 minutes. The extension features fully accessible stations with tactile paths, elevators, and audio announcements for visually impaired passengers. The metro will operate from 5 AM to 11 PM with trains every 5 minutes during peak hours. The fare ranges from Rs 10 to Rs 50. Officials expect a daily ridership of over 1.5 lakh on this corridor.',
    contentTamil: 'சென்னை சர்வதேச விமான நிலையத்தை நகர மையத்துடன் இணைக்கும் மெட்ரோ ரயில் நீட்டிப்பு திறக்கப்பட்டது. 22.5 கி.மீ நீளமுள்ள இந்த பாதையில் 17 நிலையங்கள் உள்ளன. பார்வையற்ற பயணிகளுக்கு தொடுதிறன் பாதைகள், லிப்ட் மற்றும் ஒலி அறிவிப்புகள் உள்ளன.',
    category: 'Tamil Nadu',
    categoryKey: 'tamil-nadu',
    language: 'both',
    publishedAt: timeAgo(36),
    source: 'City News',
    readTime: 3,
  },
  {
    id: '10',
    title: 'Government Launches Digital Accessibility Initiative for Government Websites',
    titleTamil: 'அரசு இணையதளங்களுக்கு டிஜிட்டல் அணுகல் முன்முயற்சி தொடங்கப்பட்டது',
    summary: 'The Government of India has launched a major initiative to make all government websites accessible to persons with disabilities, following WCAG 2.2 guidelines.',
    summaryTamil: 'இந்திய அரசு அனைத்து அரசு இணையதளங்களையும் ஊனமுற்றோருக்கு அணுகக்கூடியதாக மாற்றும் பெரிய முன்முயற்சியை தொடங்கியுள்ளது.',
    content: 'The Government of India has launched a comprehensive Digital Accessibility Initiative aimed at making all government websites and digital services accessible to persons with disabilities. The initiative follows WCAG 2.2 AA guidelines and includes provisions for screen reader compatibility, keyboard navigation, voice interfaces, and high contrast modes. The Ministry of Electronics and Information Technology (MeitY) will conduct accessibility audits of over 5,000 government websites. The initiative also includes training programs for government web developers on accessibility standards. A national helpline has been set up for citizens to report inaccessible government websites.',
    contentTamil: 'இந்திய அரசு அனைத்து அரசு இணையதளங்களையும் ஊனமுற்றோருக்கு அணுகக்கூடியதாக மாற்றும் டிஜிட்டல் அணுகல் முன்முயற்சியை தொடங்கியுள்ளது. 5,000-க்கும் மேற்பட்ட அரசு இணையதளங்களுக்கு அணுகல் தணிக்கை நடத்தப்படும்.',
    category: 'Government',
    categoryKey: 'government',
    language: 'both',
    publishedAt: timeAgo(48),
    source: 'Gov News',
    readTime: 3,
  },
];

export function getNewsByCategory(categoryKey: string): NewsArticle[] {
  if (categoryKey === 'all') return sampleNews;
  return sampleNews.filter((a) => a.categoryKey === categoryKey);
}

export function searchNews(query: string): NewsArticle[] {
  const q = query.toLowerCase();
  return sampleNews.filter(
    (a) =>
      a.title.toLowerCase().includes(q) ||
      a.summary.toLowerCase().includes(q) ||
      a.titleTamil?.includes(query) ||
      a.summaryTamil?.includes(query) ||
      a.category.toLowerCase().includes(q)
  );
}

export function getArticleById(id: string): NewsArticle | undefined {
  return sampleNews.find((a) => a.id === id);
}

export function formatTimeAgo(isoDate: string, lang: 'en' | 'ta' = 'en'): string {
  const diff = Date.now() - new Date(isoDate).getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(hours / 24);

  if (lang === 'ta') {
    if (days > 0) return `${days} நாட்களுக்கு முன்`;
    if (hours > 0) return `${hours} மணிநேரத்திற்கு முன்`;
    return 'இப்போது';
  }

  if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  return 'just now';
}


/* ------------------------------------------------------------------ */
/* Live news (Google News RSS via the `news` edge function)            */
/* ------------------------------------------------------------------ */

export interface LiveNewsResult {
  articles: NewsArticle[];
  /** false when the server was unreachable and sample stories are shown instead */
  live: boolean;
}

export function isNewsConfigured(): boolean {
  return !!NEWS_URL;
}

export async function fetchNews(opts: {
  language: AppLanguage;
  category?: string;
  query?: string;
}): Promise<LiveNewsResult> {
  const category = opts.category ?? 'all';
  const fallback = (): LiveNewsResult => ({
    articles: opts.query ? searchNews(opts.query) : getNewsByCategory(category),
    live: false,
  });
  if (!NEWS_URL) return fallback();

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const params = new URLSearchParams({ lang: opts.language, category });
    if (opts.query) params.set('q', opts.query);
    const res = await fetch(`${NEWS_URL}?${params.toString()}`, {
      signal: controller.signal,
      headers: authHeaders(),
    });
    if (!res.ok) throw new Error(String(res.status));
    const data = (await res.json()) as {
      items?: { id: string; title: string; source: string; link: string; publishedAt: string }[];
    };
    const label = newsCategories.find((c) => c.key === category);
    const articles: NewsArticle[] = (data.items ?? []).map((it) => ({
      id: it.id,
      title: it.title,
      // The feed is already in the requested language, so the same text serves both fields.
      titleTamil: opts.language === 'ta' ? it.title : undefined,
      summary: it.source,
      summaryTamil: it.source,
      content: '',
      category: label?.labelEn ?? 'Top stories',
      categoryKey: category,
      language: opts.language,
      publishedAt: it.publishedAt,
      source: it.source,
      readTime: 1,
      link: it.link,
    }));
    if (articles.length === 0) return fallback();
    return { articles, live: true };
  } catch {
    return fallback();
  } finally {
    clearTimeout(timer);
  }
}
