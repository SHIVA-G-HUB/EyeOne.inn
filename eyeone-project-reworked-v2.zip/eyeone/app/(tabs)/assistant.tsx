import React, { useState, useRef, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, Pressable, FlatList, KeyboardAvoidingView, Platform } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Mic, MicOff, Send, Trash2, Volume2, Square, Play, MessageCircle, Headphones } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { getAssistantGreeting, ChatMessage } from '@/services/ai';
import { askEyo } from '@/services/eyo';
import { detectAction, actionAcknowledgement, EyoAction } from '@/services/intents';
import { fetchNews } from '@/services/news';
import { getCurrentCoords, whereAmI, navErrorMessage } from '@/services/navigation';
import { ScreenWrapper, AccessibleHeading } from '@/components/ui/AccessibleComponents';
import { QuickActions } from '@/components/QuickActions';
import { SosButton } from '@/components/SosButton';
import { haptic } from '@/lib/haptics';

export default function AssistantScreen() {
  const { getColors, getFontSize, language, voiceEnabled, handsFree, setHandsFree } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const router = useRouter();
  const focused = useIsFocused();
  const params = useLocalSearchParams<{ listen?: string }>();
  const { speak, stop, isPaused, pause, resume } = useSpeech();
  const ttsLang = (l = language) => (l === 'ta' ? 'ta-IN' : 'en-US');

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSpeakingResponse, setIsSpeakingResponse] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const thinkingRef = useRef(false);
  const messagesRef = useRef<ChatMessage[]>([]);
  const listRef = useRef<FlatList<ChatMessage>>(null);

  // Refs so speech callbacks always see the latest values.
  const handsFreeRef = useRef(handsFree);
  handsFreeRef.current = handsFree;
  const focusedRef = useRef(focused);
  focusedRef.current = focused;
  const sendRef = useRef<(text: string) => void>(() => {});
  const startListeningRef = useRef<() => void>(() => {});
  const silentTurnsRef = useRef(0);

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  /* ---------------- speaking ---------------- */

  const say = useCallback(
    (text: string, l: 'en' | 'ta' = language) => {
      if (!voiceEnabled) {
        speak(text, { lang: ttsLang(l) }); // hands text to the screen reader if one is running
        return;
      }
      setIsSpeakingResponse(true);
      speak(text, {
        lang: ttsLang(l),
        onEnd: () => {
          setIsSpeakingResponse(false);
          // Hands-free: after Eyo finishes talking, listen for the next thing.
          if (handsFreeRef.current && focusedRef.current) setTimeout(() => startListeningRef.current(), 450);
        },
      });
    },
    [speak, voiceEnabled, language]
  );

  const addMessage = useCallback((role: 'user' | 'assistant', content: string) => {
    const msg: ChatMessage = { id: `${role}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, role, content, timestamp: Date.now() };
    setMessages((prev) => [...prev, msg]);
  }, []);

  /* ---------------- voice input ---------------- */

  const recognition = useSpeechRecognition({
    lang: ttsLang(),
    onResult: ({ transcript }) => {
      silentTurnsRef.current = 0;
      sendRef.current(transcript);
    },
    onError: (msg) => {
      if (!handsFreeRef.current) return;
      if (msg.startsWith('No speech') && ++silentTurnsRef.current < 2) {
        setTimeout(() => startListeningRef.current(), 300);
      } else {
        silentTurnsRef.current = 0;
        setHandsFree(false);
        say(language === 'ta' ? 'கைகளின்றி உரையாடலை நிறுத்திவிட்டேன். மைக்கைத் தட்டினால் மீண்டும் பேசலாம்.' : 'Hands-free paused. Tap the microphone when you want to talk.');
      }
    },
  });

  startListeningRef.current = () => {
    if (recognition.isListening || thinkingRef.current || !recognition.isSupported()) return;
    stop();
    setIsSpeakingResponse(false);
    recognition.start();
  };

  /* ---------------- actions triggered by speech or the tiles ---------------- */

  const runAction = useCallback(
    async (action: EyoAction) => {
      const ack = actionAcknowledgement(action, language);
      haptic.medium();

      switch (action.type) {
        case 'sos':
          addMessage('assistant', ack);
          router.push('/sos');
          return;

        case 'camera':
          // The camera speaks its own status ("Looking now"), so no extra spoken acknowledgement here.
          addMessage('assistant', ack);
          stop();
          router.navigate({ pathname: '/(tabs)/camera', params: { mode: action.mode, auto: String(Date.now()) } });
          return;

        case 'navigate':
          addMessage('assistant', ack);
          say(ack);
          router.navigate({ pathname: '/(tabs)/navigation', params: { dest: action.destination, auto: String(Date.now()) } });
          return;

        case 'nearby':
          addMessage('assistant', ack);
          say(ack);
          router.navigate({ pathname: '/(tabs)/navigation', params: { nearby: action.kind, auto: String(Date.now()) } });
          return;

        case 'whereAmI': {
          addMessage('assistant', ack);
          say(ack);
          thinkingRef.current = true;
          setIsThinking(true);
          let answer: string;
          try {
            answer = await whereAmI(await getCurrentCoords(), language);
          } catch (e) {
            answer = navErrorMessage(e, language);
          }
          thinkingRef.current = false;
          setIsThinking(false);
          addMessage('assistant', answer);
          say(answer);
          return;
        }

        case 'news': {
          const newsLang = action.language ?? language;
          thinkingRef.current = true;
          setIsThinking(true);
          const { articles, live } = await fetchNews({ language: newsLang, category: action.category, query: action.query });
          thinkingRef.current = false;
          setIsThinking(false);
          const top = articles.slice(0, 5);
          const ta = newsLang === 'ta';
          let text: string;
          if (top.length === 0) {
            text = t('noResults');
          } else {
            const lines = top.map((a, i) => `${i + 1}. ${ta && a.titleTamil ? a.titleTamil : a.title}.`);
            text = `${ta ? 'முக்கியச் செய்திகள்:' : 'Top stories:'} ${lines.join(' ')}`;
            if (!live) text += ` ${t('newsOffline')}`;
          }
          addMessage('assistant', text);
          say(text, newsLang);
          return;
        }
      }
    },
    [language, addMessage, say, router, stop]
  );

  /* ---------------- sending ---------------- */

  const handleSendMessage = useCallback(
    async (text: string) => {
      const clean = text.trim();
      if (!clean || thinkingRef.current) return;

      const history = messagesRef.current;
      addMessage('user', clean);
      setInputText('');

      // Commands first: instant, reliable, work offline. Everything else is a conversation with Eyo.
      const action = detectAction(clean);
      if (action) {
        await runAction(action);
        return;
      }

      thinkingRef.current = true;
      setIsThinking(true);
      const { reply } = await askEyo(history, clean, language);
      thinkingRef.current = false;
      setIsThinking(false);
      addMessage('assistant', reply);
      haptic.tap();
      say(reply);
    },
    [language, addMessage, runAction, say]
  );
  sendRef.current = handleSendMessage;

  /* ---------------- greeting + shake ---------------- */

  const greetedRef = useRef(false);
  useEffect(() => {
    if (greetedRef.current) return;
    greetedRef.current = true;
    const greeting = getAssistantGreeting(language);
    setMessages([{ id: 'greeting', role: 'assistant', content: greeting, timestamp: Date.now() }]);
    // Opened by shaking? Skip the long greeting — the listen effect below takes over.
    if (!params.listen) setTimeout(() => say(greeting), 500);
  }, []);

  // Shake from anywhere in the app: stop talking, say "listening", then listen.
  const lastListenRef = useRef<string | null>(null);
  useEffect(() => {
    if (!params.listen || params.listen === lastListenRef.current) return;
    lastListenRef.current = params.listen;
    stop();
    if (!recognition.isSupported()) {
      say(language === 'ta' ? 'நான் கேட்கிறேன். தட்டச்சு செய்யுங்கள்.' : 'I am here. Type your question.');
      return;
    }
    // A short prompt, then the microphone opens.
    speak(t('listening'), { lang: ttsLang(), onEnd: () => startListeningRef.current() });
  }, [params.listen]);

  /* ---------------- controls ---------------- */

  const handleMicPress = useCallback(() => {
    haptic.tap();
    if (recognition.isListening) {
      recognition.stop();
      return;
    }
    silentTurnsRef.current = 0;
    startListeningRef.current();
  }, [recognition]);

  const handleStopSpeak = useCallback(() => {
    stop();
    setIsSpeakingResponse(false);
  }, [stop]);

  const handlePauseResume = useCallback(() => {
    if (isPaused()) resume();
    else pause();
  }, [isPaused, resume, pause]);

  const handleClear = useCallback(() => {
    stop();
    setIsSpeakingResponse(false);
    setMessages([{ id: 'greeting', role: 'assistant', content: getAssistantGreeting(language), timestamp: Date.now() }]);
  }, [stop, language]);

  const toggleHandsFree = () => {
    haptic.tap();
    const next = !handsFree;
    setHandsFree(next);
    if (next && !recognition.isSupported()) {
      say(language === 'ta' ? 'இந்தச் சாதனத்தில் குரல் உள்ளீடு இல்லை.' : 'Voice input is not available on this device.');
      return;
    }
    say(next ? (language === 'ta' ? 'கைகளின்றி உரையாடல் இயக்கத்தில்.' : 'Hands-free chat is on.') : language === 'ta' ? 'கைகளின்றி உரையாடல் நிறுத்தம்.' : 'Hands-free chat is off.');
  };

  /* ---------------- rendering ---------------- */

  const renderMessage = ({ item }: { item: ChatMessage }) => {
    const isUser = item.role === 'user';
    return (
      <View
        style={[styles.messageContainer, isUser ? styles.userContainer : styles.assistantContainer]}
        accessible
        accessibilityLabel={isUser ? `${language === 'ta' ? 'நீங்கள்' : 'You'}: ${item.content}` : `Eyo: ${item.content}`}
      >
        {!isUser && (
          <View style={[styles.assistantIcon, { backgroundColor: colors.accent }]}>
            <MessageCircle color="#000" size={16} strokeWidth={2.5} />
          </View>
        )}
        <View
          style={[
            styles.messageBubble,
            { backgroundColor: isUser ? colors.primary : colors.surface, borderColor: isUser ? colors.primary : colors.border },
          ]}
        >
          <Text style={[styles.messageText, { color: isUser ? colors.primaryText : colors.text, fontSize: getFontSize(17) }]}>{item.content}</Text>
        </View>
      </View>
    );
  };

  const onlyGreeting = messages.length <= 1;
  const listening = recognition.isListening;

  return (
    <ScreenWrapper style={styles.screen}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <AccessibleHeading text="Eyo" level={1} />
          <View style={styles.headerActions}>
            <Pressable
              onPress={toggleHandsFree}
              accessibilityRole="switch"
              accessibilityLabel={t('handsFree')}
              accessibilityState={{ checked: handsFree }}
              style={[styles.roundBtn, { backgroundColor: handsFree ? colors.accent : colors.surface, borderColor: colors.border }]}
            >
              <Headphones color={handsFree ? '#000' : colors.text} size={24} strokeWidth={2.5} />
            </Pressable>
            <SosButton compact />
          </View>
        </View>

        {isSpeakingResponse && (
          <View style={[styles.statusBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Volume2 color={colors.accent} size={20} strokeWidth={2.5} />
            <Text style={[styles.statusText, { color: colors.text, fontSize: getFontSize(14) }]}>{t('speak')}</Text>
            <Pressable onPress={handlePauseResume} accessibilityRole="button" accessibilityLabel={isPaused() ? t('continueSpeaking') : t('pause')} style={[styles.speakControlBtn, { backgroundColor: colors.surfaceAlt }]}>
              {isPaused() ? <Play color={colors.text} size={18} strokeWidth={2.5} /> : <Square color={colors.text} size={18} strokeWidth={2.5} />}
            </Pressable>
            <Pressable onPress={handleStopSpeak} accessibilityRole="button" accessibilityLabel={t('stopSpeaking')} style={[styles.speakControlBtn, { backgroundColor: colors.error }]}>
              <Square color="#FFF" size={18} strokeWidth={2.5} />
            </Pressable>
          </View>
        )}

        <FlatList
          ref={listRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.messageList}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={onlyGreeting ? <QuickActions onAction={runAction} /> : null}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
        />

        {!onlyGreeting && <QuickActions compact onAction={runAction} />}

        {isThinking && (
          <View style={[styles.statusBar, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityLiveRegion="polite">
            <Text style={[styles.statusText, { color: colors.text, fontSize: getFontSize(14) }]}>{t('thinking')}</Text>
          </View>
        )}

        {listening && (
          <View style={[styles.statusBar, { backgroundColor: colors.error, borderColor: colors.error }]} accessibilityLiveRegion="polite">
            <Text style={[styles.statusText, { color: '#FFF', fontSize: getFontSize(15) }]}>
              {recognition.transcript ? recognition.transcript : t('listening')}
            </Text>
          </View>
        )}

        {recognition.error && !listening && (
          <View style={[styles.statusBar, { backgroundColor: colors.surface, borderColor: colors.error }]} accessibilityRole="alert">
            <Text style={[styles.statusText, { color: colors.error, fontSize: getFontSize(14) }]}>{recognition.error}</Text>
          </View>
        )}

        <View style={[styles.inputContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            onPress={handleMicPress}
            accessibilityRole="button"
            accessibilityLabel={listening ? t('stop') : t('microphone')}
            accessibilityHint={t('tapToSpeak')}
            disabled={!recognition.isSupported()}
            style={({ pressed }) => [
              styles.micButton,
              { backgroundColor: listening ? colors.error : colors.primary, opacity: pressed ? 0.7 : !recognition.isSupported() ? 0.4 : 1 },
            ]}
          >
            {listening ? <MicOff color="#FFF" size={32} strokeWidth={2.5} /> : <Mic color={colors.primaryText} size={32} strokeWidth={2.5} />}
          </Pressable>

          <TextInput
            style={[styles.textInput, { color: colors.text, fontSize: getFontSize(16) }]}
            placeholder={t('typeMessage')}
            placeholderTextColor={colors.textSecondary}
            value={inputText}
            onChangeText={setInputText}
            onSubmitEditing={() => handleSendMessage(inputText)}
            returnKeyType="send"
            accessibilityLabel={t('typeMessage')}
            multiline
            maxLength={500}
          />

          <Pressable
            onPress={() => handleSendMessage(inputText)}
            accessibilityRole="button"
            accessibilityLabel={t('send')}
            disabled={!inputText.trim()}
            style={({ pressed }) => [
              styles.sendButton,
              { backgroundColor: inputText.trim() ? colors.accent : colors.surfaceAlt, opacity: pressed ? 0.7 : !inputText.trim() ? 0.5 : 1 },
            ]}
          >
            <Send color={inputText.trim() ? '#000' : colors.textSecondary} size={24} strokeWidth={2.5} />
          </Pressable>
        </View>

        {!onlyGreeting && (
          <Pressable
            onPress={handleClear}
            accessibilityRole="button"
            accessibilityLabel={t('newConversation')}
            style={({ pressed }) => [styles.clearButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
          >
            <Trash2 color={colors.textSecondary} size={18} strokeWidth={2.5} />
            <Text style={{ color: colors.textSecondary, fontSize: getFontSize(14), fontWeight: '600' }}>{t('newConversation')}</Text>
          </Pressable>
        )}
      </KeyboardAvoidingView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  screen: { padding: 16, paddingBottom: 8 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  roundBtn: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  statusBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, marginBottom: 8, gap: 10 },
  statusText: { flex: 1, fontWeight: '600' },
  speakControlBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  messageList: { flexGrow: 1, paddingBottom: 8 },
  messageContainer: { flexDirection: 'row', alignItems: 'flex-end', marginBottom: 12, gap: 8 },
  userContainer: { justifyContent: 'flex-end' },
  assistantContainer: { justifyContent: 'flex-start' },
  assistantIcon: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  messageBubble: { maxWidth: '82%', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 18, borderWidth: 1 },
  messageText: { lineHeight: 26, fontWeight: '500' },
  inputContainer: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 8, paddingVertical: 8, borderRadius: 20, borderWidth: 1, gap: 8 },
  micButton: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  textInput: { flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontWeight: '500', maxHeight: 100 },
  sendButton: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  clearButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, borderRadius: 12, borderWidth: 1, gap: 8, marginTop: 8 },
});
