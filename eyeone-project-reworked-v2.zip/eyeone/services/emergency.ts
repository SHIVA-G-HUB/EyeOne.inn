import { Linking, Platform } from 'react-native';
import * as Location from 'expo-location';

/** India's single emergency number (police, fire, ambulance). */
export const EMERGENCY_NUMBER = '112';

const digitsOnly = (phone: string) => phone.replace(/[^\d+]/g, '');

export async function callNumber(phone: string): Promise<boolean> {
  try {
    await Linking.openURL(`tel:${digitsOnly(phone)}`);
    return true;
  } catch {
    return false;
  }
}

/** Best-effort position within a few seconds; never blocks an emergency. */
async function quickPosition(): Promise<{ lat: number; lng: number } | null> {
  try {
    const perm = await Location.requestForegroundPermissionsAsync();
    if (perm.status !== 'granted') return null;
    const last = await Location.getLastKnownPositionAsync();
    const fresh = await Promise.race([
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
      new Promise<null>((r) => setTimeout(() => r(null), 5000)),
    ]);
    const pos = fresh ?? last;
    return pos ? { lat: pos.coords.latitude, lng: pos.coords.longitude } : null;
  } catch {
    return null;
  }
}

/**
 * Opens the phone's messaging app with a prefilled message and a map link.
 * The person still has to press send — this is a phone-platform rule, not a choice.
 */
export async function textLocation(phone: string, name: string, language: 'en' | 'ta'): Promise<{ ok: boolean; hadLocation: boolean }> {
  const pos = await quickPosition();
  const link = pos ? `https://maps.google.com/?q=${pos.lat},${pos.lng}` : '';
  const body =
    language === 'ta'
      ? `இது அவசரம். எனக்கு உதவி தேவை. ${pos ? `என் இடம்: ${link}` : 'என் இடத்தைப் பெற முடியவில்லை.'}`
      : `This is an emergency. I need help. ${pos ? `My location: ${link}` : 'I could not get my location.'}`;
  const sep = Platform.OS === 'ios' ? '&' : '?';
  try {
    await Linking.openURL(`sms:${digitsOnly(phone)}${sep}body=${encodeURIComponent(body)}`);
    return { ok: true, hadLocation: !!pos };
  } catch {
    return { ok: false, hadLocation: !!pos };
  }
}
