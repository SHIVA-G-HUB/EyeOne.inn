# EyeOne — Eyo, the AI assistant for blind & low-vision users

Expo (React Native + Expo Router) app for Android, iOS and web. Voice-first: **Eyo** is the home screen,
and everything the referenced apps do (Be My AI, Seeing AI, Envision, Google Lookout, OKO) is one spoken
sentence or one big button away.

| Reference app feature | In EyeOne |
| --- | --- |
| Be My AI / Seeing AI **Scene** | See tab → Describe scene, or say "What is in front of me?" |
| Seeing AI **Short text**, Lookout **Text**, Envision **Instant text** | Read text |
| Seeing AI **Document**, Envision **Scan text** | Document |
| Seeing AI / Lookout **Currency** | Currency (Indian rupee notes and coins) |
| Seeing AI **Color** | Colour |
| Seeing AI **Product**, Lookout **Food label** | Product: barcode lookup, or Read text on the label |
| Envision **Ask** / Be My AI follow-up | "Ask about this photo" (voice or typed), and Eyo remembers the last result |
| Lookout **Explore** / OKO **navigation** | Navigation tab: real GPS walking directions, nearby places, "Where am I" |
| Be My Eyes **volunteer** / Aira | Not built. Needs a live-video service and a volunteer network. Emergency options (call 112, text location) are built |
| Smart glasses | Not built |

## Install on a phone
See `BUILD_APK.md` (cloud build gives you one APK file).

## Setup
1. `npm install --legacy-peer-deps`
2. Deploy the three edge functions (keeps the OpenAI key off the phone):
   ```
   supabase secrets set OPENAI_API_KEY=sk-...
   supabase functions deploy eyo vision news
   ```
3. Copy `.env.example` to `.env`, fill in the project URL and anon key.
4. `npm run dev`. **Voice input needs a development build**, not Expo Go:
   `npx expo prebuild && npx expo run:android` (or `run:ios`, or EAS Build).

What works without step 2–3: the app, settings, navigation, nearby places, emergency options, offline Eyo commands.
What needs it: camera descriptions, Eyo's conversation, live news (falls back to sample stories).

## Structure
- `app/(tabs)/assistant.tsx` Eyo home: voice, hands-free mode, one-tap tiles, shake-to-listen
- `app/(tabs)/camera.tsx` See: scene / text / document / currency / colour / barcode, follow-up questions, torch, gallery
- `app/(tabs)/navigation.tsx` Where am I, search by voice, nearby, live turn-by-turn with off-route recovery
- `app/(tabs)/news.tsx` Live Tamil/English news incl. Medical
- `app/sos.tsx` Emergency: call 112, call/text your contact with a map link. Never dials by itself
- `services/intents.ts` speech → action router (instant, offline). Anything else goes to Eyo
- `services/vision.ts`, `navigation.ts`, `news.ts`, `eyo.ts`, `emergency.ts`, `session.ts`
- `supabase/functions/{eyo,vision,news}` server side
- `contexts/AccessibilityContext.tsx` settings, now persisted on native as well as web

## Opening the app hands-free
- **Shake** works while EyeOne is open (foreground). Expo apps cannot listen for shakes in the background.
- To open it from a locked or closed phone: Android — assign EyeOne as the default digital assistant or add a home-screen shortcut / Google Assistant routine "open EyeOne"; iPhone — Settings → Accessibility → Touch → Back Tap → Shortcuts → "Open EyeOne", or Siri "Open EyeOne".
- A true always-on shake service needs custom native code (Android foreground service). Not included.

## Known limits (please read before real-world use)
- **Not a mobility aid.** GPS is off by 10–20 m in cities. Users must keep their cane or guide dog. Guidance stops if the app is closed (no background location yet).
- Map data uses free OpenStreetMap services (Nominatim, OSRM foot, Overpass). Fair-use limits, no uptime guarantee. Move to a paid provider behind an edge function before a public launch.
- AI can be wrong. Currency and medicine reads tell the user to retake when unsure; still treat them as help, not proof.
- The edge functions are open to anyone with the anon key. Add Supabase auth or rate limiting before publishing, or someone can run up your OpenAI bill.
- News comes from Google News RSS (headlines and source). Full-article reading is not included.
- Face *recognition* (naming people) is deliberately not built: it is a privacy risk. Scene mode does describe people (number, clothing, actions).
- No on-device OCR yet; text reading needs internet.
- Feed/API URLs were not reachable from the build sandbox: test news, navigation and vision once on a real device.

## Roadmap
- [x] Eyo conversational assistant as home screen, real LLM + offline command fallback
- [x] Text-to-speech, shake-to-open (foreground), native voice input (`expo-speech-recognition`)
- [x] Camera: describe, read text, document, currency, colour, product barcode, follow-up questions
- [x] Real navigation: GPS, search, walking route, nearby places, off-route recovery
- [x] Live Tamil/English news + medical news
- [x] Redesign: big high-contrast buttons, haptics, persisted settings
- [x] Emergency: call 112, contact, location text
- [ ] Background location + notifications during guidance
- [ ] On-device OCR (ML Kit) for offline reading; continuous "live" scene mode
- [ ] Saved faces/places ("who is this", opt-in), volunteer video calls
- [ ] Auth + rate limiting on edge functions; analytics-free crash reporting
