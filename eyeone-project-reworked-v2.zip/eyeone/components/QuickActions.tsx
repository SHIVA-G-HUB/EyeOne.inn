import React from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet } from 'react-native';
import { Eye, FileText, Banknote, Palette, MapPin, Navigation, Newspaper, Stethoscope } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import type { EyoAction } from '@/services/intents';
import { haptic } from '@/lib/haptics';

interface Tile {
  key: string;
  icon: any;
  label: string;
  action: EyoAction;
}

/**
 * One-tap versions of the voice commands. Big, high-contrast, and the same
 * actions Eyo triggers from speech, so sighted helpers and low-vision users can tap too.
 */
export function QuickActions({ onAction, compact }: { onAction: (a: EyoAction) => void; compact?: boolean }) {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);

  const tiles: Tile[] = [
    { key: 'scene', icon: Eye, label: t('describeScene'), action: { type: 'camera', mode: 'scene' } },
    { key: 'text', icon: FileText, label: t('readText'), action: { type: 'camera', mode: 'text' } },
    { key: 'currency', icon: Banknote, label: t('currency'), action: { type: 'camera', mode: 'currency' } },
    { key: 'color', icon: Palette, label: t('colour'), action: { type: 'camera', mode: 'color' } },
    { key: 'where', icon: MapPin, label: t('whereAmI'), action: { type: 'whereAmI' } },
    { key: 'nearby', icon: Navigation, label: `${t('findNearby')}`, action: { type: 'nearby', kind: 'hospital' } },
    { key: 'news', icon: Newspaper, label: t('latestNews'), action: { type: 'news', category: 'all' } },
    { key: 'medical', icon: Stethoscope, label: t('medicalNews'), action: { type: 'news', category: 'medical' } },
  ];

  if (compact) {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow} style={styles.chipScroll}>
        {tiles.map(({ key, icon: Icon, label, action }) => (
          <Pressable
            key={key}
            onPress={() => {
              haptic.tap();
              onAction(action);
            }}
            accessibilityRole="button"
            accessibilityLabel={label}
            style={({ pressed }) => [styles.chip, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
          >
            <Icon color={colors.primary} size={20} strokeWidth={2.5} />
            <Text style={{ color: colors.text, fontSize: getFontSize(14), fontWeight: '700' }}>{label}</Text>
          </Pressable>
        ))}
      </ScrollView>
    );
  }

  return (
    <View style={styles.grid}>
      {tiles.map(({ key, icon: Icon, label, action }) => (
        <Pressable
          key={key}
          onPress={() => {
            haptic.tap();
            onAction(action);
          }}
          accessibilityRole="button"
          accessibilityLabel={label}
          style={({ pressed }) => [styles.tile, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        >
          <View style={[styles.tileIcon, { backgroundColor: colors.primary }]}>
            <Icon color={colors.primaryText} size={30} strokeWidth={2.5} />
          </View>
          <Text style={{ color: colors.text, fontSize: getFontSize(16), fontWeight: '800', textAlign: 'center' }} numberOfLines={2}>
            {label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
  tile: { width: '48%', flexGrow: 1, minHeight: 112, borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12 },
  tileIcon: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center' },
  chipScroll: { flexGrow: 0, marginBottom: 8 },
  chipRow: { gap: 8 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 48, paddingHorizontal: 14, borderRadius: 24, borderWidth: 1 },
});
