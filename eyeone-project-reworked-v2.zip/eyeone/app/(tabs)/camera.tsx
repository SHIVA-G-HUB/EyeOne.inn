import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { useIsFocused } from '@react-navigation/native';
import { useLocalSearchParams } from 'expo-router';
import { Eye, FileText, BookOpen, Banknote, Palette, ScanBarcode, Camera, Flashlight, FlashlightOff, Image as ImageIcon, Volume2, Square, Mic, MicOff, RefreshCw, MessageCircleQuestion } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { ScreenWrapper, AccessibleHeading, AccessibleButton } from '@/components/ui/AccessibleComponents';
import { SosButton } from '@/components/SosButton';
import { describeImage, VisionError, VisionMode, lookupProduct, speakableProduct } from '@/services/vision';
import { rememberVision, recentVision } from '@/services/session';
import { haptic } from '@/lib/haptics';

type CameraMode = Exclude<VisionMode, 'ask'> | 'barcode';

const MODES: { key: CameraMode; icon: any; labelKey: string }[] = [
  { key: 'scene', icon: Eye, labelKey: 'describeScene' },
  { key: 'text', icon: FileText, labelKey: 'readText' },
  { key: 'document', icon: BookOpen, labelKey: 'document' },
  { key: 'currency', icon: Banknote, labelKey: 'currency' },
  { key: 'color', icon: Palette, labelKey: 'colour' },
  { key: 'barcode', icon: ScanBarcode, labelKey: 'product' },
];

const stripDataUrl = (b64: string) => b64.replace(/^data:[^;]+;base64,/, '');

export default function CameraScreen() {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const focused = useIsFocused();
  const params = useLocalSearchParams<{ mode?: string; auto?: string }>();
  const { speak, stop } = useSpeech();
  const lang = language === 'ta' ? 'ta-IN' : 'en-US';

  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView>(null);
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<CameraMode>('scene');
  const [torch, setTorch] = useState(false);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [result, setResult] = useState<string | null>(null);
  const photoRef = useRef<{ base64: string; mime: string } | null>(null);
  const lastAutoRef = useRef<string | null>(null);
  const lastCodeRef = useRef<{ code: string; at: number } | null>(null);

  const setBusyBoth = (v: boolean) => {
    busyRef.current = v;
    setBusy(v);
  };

  const modeLabel = (m: CameraMode) => t(MODES.find((x) => x.key === m)!.labelKey);

  /* ---------------- speaking helpers ---------------- */

  const say = useCallback((text: string) => speak(text, { lang }), [speak, lang]);

  // Leaving the tab silences the camera voice.
  useEffect(() => {
    if (!focused) stop();
  }, [focused, stop]);

  /* ---------------- analyse a photo ---------------- */

  const analyse = useCallback(
    async (base64: string, mime: string, m: VisionMode, question?: string) => {
      setBusyBoth(true);
      setResult(null);
      say(t('analysing'));
      try {
        const text = await describeImage({
          base64,
          mimeType: mime,
          mode: m,
          language,
          question,
          previous: m === 'ask' ? recentVision()?.text : undefined,
        });
        if (m !== 'ask') rememberVision(m, text);
        setResult(text);
        haptic.success();
        say(text);
      } catch (e) {
        const msg = e instanceof VisionError && e.kind === 'not-configured' ? t('visionNotConfigured') : t('visionError');
        setResult(msg);
        haptic.error();
        say(msg);
      } finally {
        setBusyBoth(false);
      }
    },
    [language, say]
  );

  const capture = useCallback(
    async (forMode?: CameraMode) => {
      const m = forMode ?? mode;
      if (busyRef.current || m === 'barcode') return;
      if (!cameraRef.current) return;
      haptic.medium();
      try {
        const photo = await cameraRef.current.takePictureAsync({ quality: 0.6, base64: true });
        if (!photo?.base64) throw new Error('no data');
        const base64 = stripDataUrl(photo.base64);
        photoRef.current = { base64, mime: 'image/jpeg' };
        await analyse(base64, 'image/jpeg', m);
      } catch {
        haptic.error();
        say(t('visionError'));
      }
    },
    [mode, analyse, say]
  );

  const pickFromGallery = useCallback(async () => {
    if (busyRef.current) return;
    haptic.tap();
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      base64: true,
      quality: 0.6,
    });
    if (res.canceled || !res.assets?.[0]?.base64) return;
    const a = res.assets[0];
    const base64 = stripDataUrl(a.base64 as string);
    const mime = a.mimeType ?? 'image/jpeg';
    photoRef.current = { base64, mime };
    await analyse(base64, mime, mode === 'barcode' ? 'scene' : mode);
  }, [mode, analyse]);

  /* ---------------- follow-up question about the same photo ---------------- */

  const ask = useCallback(
    async (question: string) => {
      const photo = photoRef.current;
      if (!photo || busyRef.current) {
        say(language === 'ta' ? 'முதலில் ஒரு படம் எடுங்கள்.' : 'Please take a photo first.');
        return;
      }
      await analyse(photo.base64, photo.mime, 'ask', question);
    },
    [analyse, say, language]
  );

  const recognition = useSpeechRecognition({
    lang,
    onResult: ({ transcript }) => ask(transcript),
  });

  const onMic = () => {
    if (recognition.isListening) {
      recognition.stop();
      return;
    }
    stop();
    haptic.tap();
    recognition.start();
  };

  /* ---------------- barcode ---------------- */

  const onBarcode = useCallback(
    async ({ data }: { data: string }) => {
      const now = Date.now();
      const last = lastCodeRef.current;
      if (busyRef.current || (last && last.code === data && now - last.at < 6000)) return;
      lastCodeRef.current = { code: data, at: now };
      setBusyBoth(true);
      haptic.success();

      let message: string;
      if (/^https?:\/\//i.test(data)) {
        let host = data;
        try {
          host = new URL(data).hostname;
        } catch {}
        message = language === 'ta' ? `QR குறியீடு. இணைப்பு: ${host}` : `QR code with a link to ${host}.`;
      } else if (/^\d{8,14}$/.test(data)) {
        const product = await lookupProduct(data);
        message = speakableProduct(product, language) ?? t('barcodeUnknown');
      } else {
        message = language === 'ta' ? `குறியீடு: ${data}` : `Code says: ${data}`;
      }
      rememberVision('product', message);
      setResult(message);
      say(message);
      setBusyBoth(false);
    },
    [language, say]
  );

  /* ---------------- opened by Eyo ("read this", "what colour is this") ---------------- */

  // The timer below must always call the newest capture(); keeping it in a ref stops the effect
  // from restarting (and silently cancelling the photo) every time `mode` changes.
  const captureRef = useRef(capture);
  captureRef.current = capture;

  useEffect(() => {
    if (!params.mode || !params.auto || params.auto === lastAutoRef.current) return;
    if (!MODES.some((m) => m.key === params.mode)) return;
    if (!permission?.granted) return; // runs again once the camera is allowed
    lastAutoRef.current = params.auto;
    const target = params.mode as CameraMode;
    setMode(target);
    setResult(null);
    if (target === 'barcode') {
      say(t('scanningBarcode'));
      return;
    }
    // Wait for the camera to warm up and focus, then take the photo.
    let cancelled = false;
    const start = Date.now();
    const timer = setInterval(() => {
      if (cancelled) return;
      if (cameraRef.current && Date.now() - start > 1300) {
        clearInterval(timer);
        captureRef.current(target);
      } else if (Date.now() - start > 6000) {
        clearInterval(timer);
      }
    }, 250);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.mode, params.auto, permission?.granted]);

  const selectMode = (m: CameraMode) => {
    haptic.tap();
    setMode(m);
    setResult(null);
    lastCodeRef.current = null;
    say(m === 'barcode' ? t('scanningBarcode') : `${modeLabel(m)}. ${t('tapToCapture')}`);
  };

  const toggleTorch = () => {
    haptic.tap();
    setTorch((v) => {
      say(v ? t('lightOff') : t('lightOn'));
      return !v;
    });
  };

  /* ---------------- permission gate ---------------- */

  useEffect(() => {
    if (permission && !permission.granted && focused) say(t('cameraPermission'));
  }, [permission?.granted, focused]);

  if (!permission) return <ScreenWrapper>{null}</ScreenWrapper>;

  if (!permission.granted) {
    return (
      <ScreenWrapper style={styles.center}>
        <AccessibleHeading text={t('see')} level={1} />
        <Text style={[styles.permText, { color: colors.text, fontSize: getFontSize(18) }]}>{t('cameraPermission')}</Text>
        <AccessibleButton
          label={t('allowCamera')}
          onPress={requestPermission}
          size="extraLarge"
          icon={<Camera color={colors.primaryText} size={28} strokeWidth={2.5} />}
        />
      </ScreenWrapper>
    );
  }

  const isBarcode = mode === 'barcode';

  return (
    <ScreenWrapper style={styles.screen}>
      <View style={styles.header}>
        <AccessibleHeading text={t('see')} level={1} />
        <View style={styles.headerActions}>
          <Pressable
            onPress={toggleTorch}
            accessibilityRole="button"
            accessibilityLabel={torch ? t('lightOff') : t('lightOn')}
            style={[styles.roundBtn, { backgroundColor: torch ? colors.warning : colors.surface, borderColor: colors.border }]}
          >
            {torch ? <Flashlight color="#000" size={24} strokeWidth={2.5} /> : <FlashlightOff color={colors.text} size={24} strokeWidth={2.5} />}
          </Pressable>
          <SosButton compact />
        </View>
      </View>

      {/* Camera preview. The whole area is one big "take photo" button. */}
      <Pressable
        onPress={() => capture()}
        disabled={isBarcode}
        accessibilityRole="button"
        accessibilityLabel={isBarcode ? t('scanningBarcode') : `${t('takePhoto')}. ${modeLabel(mode)}`}
        accessibilityHint={isBarcode ? undefined : t('tapToCapture')}
        style={[styles.preview, { borderColor: colors.border, backgroundColor: '#000' }]}
      >
        {focused && (
          <CameraView
            ref={cameraRef}
            style={StyleSheet.absoluteFill}
            facing="back"
            enableTorch={torch}
            onCameraReady={() => setReady(true)}
            barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'qr'] }}
            onBarcodeScanned={isBarcode ? onBarcode : undefined}
            accessible={false}
            importantForAccessibility="no-hide-descendants"
          />
        )}
        {busy && (
          <View style={styles.busyOverlay} accessibilityLiveRegion="polite">
            <Text style={[styles.busyText, { fontSize: getFontSize(20) }]}>{t('analysing')}</Text>
          </View>
        )}
      </Pressable>

      {/* Result */}
      {result && (
        <View style={[styles.resultCard, { backgroundColor: colors.surface, borderColor: colors.accent }]}>
          <ScrollView style={styles.resultScroll} accessibilityLiveRegion="polite">
            <Text selectable style={[styles.resultText, { color: colors.text, fontSize: getFontSize(18) }]}>
              {result}
            </Text>
          </ScrollView>
          <View style={styles.resultActions}>
            <ResultButton label={t('repeat')} icon={<Volume2 color={colors.text} size={22} strokeWidth={2.5} />} onPress={() => say(result)} />
            <ResultButton label={t('stopSpeaking')} icon={<Square color={colors.text} size={22} strokeWidth={2.5} />} onPress={stop} />
            {!isBarcode && (
              <ResultButton
                label={recognition.isListening ? t('stop') : t('askAboutPhoto')}
                icon={
                  recognition.isListening ? (
                    <MicOff color="#FFF" size={22} strokeWidth={2.5} />
                  ) : recognition.isSupported() ? (
                    <Mic color={colors.text} size={22} strokeWidth={2.5} />
                  ) : (
                    <MessageCircleQuestion color={colors.text} size={22} strokeWidth={2.5} />
                  )
                }
                danger={recognition.isListening}
                disabled={!recognition.isSupported()}
                onPress={onMic}
              />
            )}
          </View>
        </View>
      )}

      {/* Mode selector */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.modeScroll} contentContainerStyle={styles.modeRow} accessibilityRole="tablist">
        {MODES.map(({ key, icon: Icon }) => {
          const selected = mode === key;
          return (
            <Pressable
              key={key}
              onPress={() => selectMode(key)}
              accessibilityRole="tab"
              accessibilityLabel={modeLabel(key)}
              accessibilityState={{ selected }}
              style={({ pressed }) => [
                styles.modeChip,
                {
                  backgroundColor: selected ? colors.primary : colors.surface,
                  borderColor: selected ? colors.primary : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Icon color={selected ? colors.primaryText : colors.text} size={26} strokeWidth={2.5} />
              <Text style={[styles.modeLabel, { color: selected ? colors.primaryText : colors.text, fontSize: getFontSize(13) }]}>
                {modeLabel(key)}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {/* Shutter row */}
      <View style={styles.shutterRow}>
        <Pressable
          onPress={pickFromGallery}
          accessibilityRole="button"
          accessibilityLabel={t('choosePhoto')}
          style={[styles.sideBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
        >
          <ImageIcon color={colors.text} size={26} strokeWidth={2.5} />
        </Pressable>
        <Pressable
          onPress={() => capture()}
          disabled={busy || isBarcode}
          accessibilityRole="button"
          accessibilityLabel={t('takePhoto')}
          accessibilityState={{ disabled: busy || isBarcode }}
          style={({ pressed }) => [
            styles.shutter,
            { backgroundColor: colors.primary, borderColor: colors.text, opacity: busy || isBarcode ? 0.4 : pressed ? 0.8 : 1 },
          ]}
        >
          <Camera color={colors.primaryText} size={34} strokeWidth={2.5} />
        </Pressable>
        <Pressable
          onPress={() => {
            haptic.tap();
            setResult(null);
            photoRef.current = null;
            lastCodeRef.current = null;
          }}
          accessibilityRole="button"
          accessibilityLabel={t('clear')}
          style={[styles.sideBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
        >
          <RefreshCw color={colors.text} size={26} strokeWidth={2.5} />
        </Pressable>
      </View>

      {recognition.isListening && (
        <View style={[styles.listeningBar, { backgroundColor: colors.error }]} accessibilityLiveRegion="polite">
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: getFontSize(15) }}>{t('listening')}</Text>
        </View>
      )}
    </ScreenWrapper>
  );
}

function ResultButton({ label, icon, onPress, danger, disabled }: { label: string; icon: React.ReactNode; onPress: () => void; danger?: boolean; disabled?: boolean }) {
  const { getColors, getFontSize } = useAccessibility();
  const colors = getColors();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [
        styles.resultBtn,
        { backgroundColor: danger ? colors.error : colors.surfaceAlt, opacity: disabled ? 0.4 : pressed ? 0.7 : 1 },
      ]}
    >
      {icon}
      <Text numberOfLines={2} style={{ color: danger ? '#FFF' : colors.text, fontSize: getFontSize(12), fontWeight: '700', textAlign: 'center' }}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { padding: 16, paddingBottom: 8 },
  center: { alignItems: 'center', justifyContent: 'center', gap: 24 },
  permText: { textAlign: 'center', lineHeight: 28, fontWeight: '600' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  roundBtn: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  preview: { flex: 1, borderRadius: 20, borderWidth: 2, overflow: 'hidden', minHeight: 180 },
  busyOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center', padding: 20 },
  busyText: { color: '#FFF', fontWeight: '800', textAlign: 'center' },
  resultCard: { borderRadius: 16, borderWidth: 2, padding: 14, marginTop: 10, maxHeight: 220 },
  resultScroll: { maxHeight: 120 },
  resultText: { lineHeight: 26, fontWeight: '500' },
  resultActions: { flexDirection: 'row', gap: 8, marginTop: 10 },
  resultBtn: { flex: 1, minHeight: 60, borderRadius: 12, alignItems: 'center', justifyContent: 'center', gap: 4, padding: 6 },
  modeScroll: { flexGrow: 0, marginTop: 10 },
  modeRow: { gap: 8, paddingRight: 8 },
  modeChip: { minWidth: 92, minHeight: 72, borderRadius: 14, borderWidth: 2, alignItems: 'center', justifyContent: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 8 },
  modeLabel: { fontWeight: '700', textAlign: 'center' },
  shutterRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginTop: 12, paddingBottom: 4 },
  shutter: { width: 84, height: 84, borderRadius: 42, borderWidth: 4, alignItems: 'center', justifyContent: 'center' },
  sideBtn: { width: 60, height: 60, borderRadius: 30, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  listeningBar: { padding: 10, borderRadius: 12, alignItems: 'center', marginTop: 8 },
});
