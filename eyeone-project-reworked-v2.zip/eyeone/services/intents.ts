import type { VisionMode } from './vision';
import type { NearbyKind } from './navigation';

/**
 * Turns what the person said into an app action, BEFORE anything is sent to the LLM.
 * This makes the important commands instant, reliable and available offline
 * ("describe what is in front of me", "read this", "take me to...", "emergency").
 * Anything that is not a command falls through to Eyo the conversational AI.
 */

export type CameraTarget = VisionMode | 'barcode';

export type EyoAction =
  | { type: 'sos' }
  | { type: 'camera'; mode: CameraTarget }
  | { type: 'whereAmI' }
  | { type: 'nearby'; kind: NearbyKind }
  | { type: 'navigate'; destination: string }
  | { type: 'news'; category: string; query?: string; language?: 'en' | 'ta' };

const has = (text: string, re: RegExp) => re.test(text);

const NEARBY_KINDS: { kind: NearbyKind; re: RegExp }[] = [
  { kind: 'pharmacy', re: /pharmac|chemist|medical (shop|store)|மருந்தகம்|மருந்துக்?\s?கடை/i },
  { kind: 'hospital', re: /hospital|clinic|doctor|மருத்துவமனை|கிளினிக்/i },
  { kind: 'atm', re: /\batm\b|cash machine|ஏடிஎம்/i },
  { kind: 'toilets', re: /toilet|restroom|washroom|கழிவறை|கழிப்பறை/i },
  { kind: 'transit', re: /\bbus\b|\bmetro\b|railway|\btrain\b|பேருந்து|ரயில்|மெட்ரோ/i },
  { kind: 'restaurant', re: /restaurant|food|eat|cafe|hotel|உணவகம்|ஹோட்டல்|சாப்பிட/i },
  { kind: 'shopping', re: /supermarket|shop|store|mall|கடை|மால்/i },
];

export function detectAction(raw: string): EyoAction | null {
  const text = raw.trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  // 1. Emergency always wins.
  // ("help me" alone triggers it; "help me read this" must not.)
  if (
    has(lower, /\b(emergency|sos|ambulance)\b|i need (urgent )?help|call (the )?(police|ambulance|112)|^(please )?help( me)?[.!]*$/) ||
    has(text, /அவசரம்|காப்பாற்று|ஆம்புலன்ஸ்|உதவி வேண்டும்/)
  ) {
    return { type: 'sos' };
  }

  // 2. News (checked before "read", so "read the news" does not open the camera).
  if (has(lower, /\bnews\b|headlines/) || has(text, /செய்தி/)) {
    const medical = has(lower, /medical|doctor|health|hospital/) || has(text, /மருத்துவ|சுகாதார/);
    const search = lower.match(/(?:about|on|for)\s+(.+)$/);
    return {
      type: 'news',
      category: medical ? 'medical' : has(lower, /tamil nadu|chennai/) || has(text, /தமிழ்நாடு|சென்னை/) ? 'tamil-nadu' : 'all',
      query: !medical && search ? search[1].trim() : undefined,
      language: has(lower, /tamil news/) || has(text, /தமிழ்\s*செய்தி/) ? 'ta' : has(lower, /english news/) ? 'en' : undefined,
    };
  }

  // 3. Where am I / what is around me (location, not camera).
  if (has(lower, /where am i|my location|current location|which (road|street|area)/) || has(text, /நான் எங்கே|என் இடம்|எந்த இடம்/)) {
    return { type: 'whereAmI' };
  }

  // 4. Nearby places.
  if (has(lower, /\b(nearest|nearby|near me|closest|find)\b/) || has(text, /அருகில்|பக்கத்தில்|அருகிலுள்ள/)) {
    const hit = NEARBY_KINDS.find((k) => has(text, k.re) || has(lower, k.re));
    if (hit) return { type: 'nearby', kind: hit.kind };
  }

  // 5. Navigation to a named place.
  const navEn = text.match(/(?:navigate|directions?|route|take me|walk|guide me|how (?:do i )?get|go)\s+(?:me\s+)?(?:to|towards)\s+(.+)/i);
  if (navEn) return { type: 'navigate', destination: navEn[1].replace(/[.?!]+$/, '').trim() };
  const navTa = text.match(/(.+?)\s*(?:க்கு|கு)\s*(?:வழி|போக|செல்ல|கூட்டிச்செல்)/);
  if (navTa) return { type: 'navigate', destination: navTa[1].trim() };

  // 6. Camera modes, most specific first.
  if (has(lower, /currency|rupee|banknote|bank note|cash|money|how much (is|are) (this|these)/) || has(text, /ரூபாய்|நோட்டு|பணம்/)) {
    return { type: 'camera', mode: 'currency' };
  }
  if (has(lower, /colou?r|shade of/) || has(text, /நிறம்|வண்ணம்/)) {
    return { type: 'camera', mode: 'color' };
  }
  if (has(lower, /barcode|scan (this|the|a)? ?(product|item|code)|\bproduct\b/) || has(text, /பார்கோடு|பொருள்/)) {
    return { type: 'camera', mode: 'barcode' };
  }
  if (has(lower, /document|page|letter|paper|form\b|book|newspaper/)) {
    return { type: 'camera', mode: 'document' };
  }
  if (has(lower, /\bread\b|what does (it|this|that) say|\btext\b|label|\bsign\b|menu|medicine name/) || has(text, /படி|எழுத்து|என்ன எழுதி/)) {
    return { type: 'camera', mode: 'text' };
  }
  if (
    has(lower, /what('s| is) (in front|around|ahead)|what do you see|describe|look (around|at)|what am i (looking|holding)|surroundings|what is this|what's this/) ||
    has(text, /எதிரில்|முன்னால்.*என்ன|சுற்றி|என்ன இருக்கிறது|விவரி|பார்த்து.*சொல்/)
  ) {
    return { type: 'camera', mode: 'scene' };
  }

  return null;
}

/** What Eyo says while it opens the right feature. */
export function actionAcknowledgement(action: EyoAction, lang: 'en' | 'ta'): string {
  const ta = lang === 'ta';
  switch (action.type) {
    case 'sos':
      return ta ? 'அவசர வழிகளைத் திறக்கிறேன்.' : 'Opening emergency options.';
    case 'camera':
      switch (action.mode) {
        case 'currency':
          return ta ? 'நோட்டை கேமராவுக்கு முன் பிடியுங்கள். படம் எடுக்கிறேன்.' : 'Hold the note in front of the camera. Taking a photo now.';
        case 'text':
        case 'document':
          return ta ? 'உரையை கேமராவுக்கு முன் பிடியுங்கள். படம் எடுக்கிறேன்.' : 'Hold the text in front of the camera. Taking a photo now.';
        case 'barcode':
          return ta ? 'பார்கோடை கேமராவை நோக்கிப் பிடியுங்கள்.' : 'Point the camera at the barcode.';
        default:
          return ta ? 'கேமராவைத் திறக்கிறேன். படம் எடுக்கிறேன்.' : 'Opening the camera. Taking a photo now.';
      }
    case 'navigate':
      return ta ? `${action.destination} க்கு வழியைத் தேடுகிறேன்.` : `Finding a walking route to ${action.destination}.`;
    case 'whereAmI':
      return ta ? 'உங்கள் இடத்தைக் கண்டறிகிறேன்.' : 'Finding where you are.';
    case 'nearby':
      return ta ? 'அருகில் தேடுகிறேன்.' : 'Looking nearby.';
    case 'news':
      return ta ? 'செய்திகளைப் பெறுகிறேன்.' : 'Getting the news.';
  }
}
