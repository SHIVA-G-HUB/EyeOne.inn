import { processAICommand, ChatMessage } from './ai';
import { AppLanguage } from '@/contexts/AccessibilityContext';
import { EYO_URL, authHeaders } from './config';
import { recentVision } from './session';

/**
 * Eyo — the conversational AI brain of the app.
 *
 * Online: sends the recent conversation to the `eyo` edge function
 * (supabase/functions/eyo), which holds the OpenAI key server-side.
 * Offline / error / not configured: falls back to the built-in keyword
 * assistant in ./ai so the app never goes silent for a blind user.
 */

const API_URL = EYO_URL;
const TIMEOUT_MS = 20000;
const MAX_HISTORY = 12;

export interface EyoReply {
  reply: string;
  source: 'ai' | 'offline';
}

export function isEyoConfigured(): boolean {
  return !!API_URL;
}

export async function askEyo(
  history: ChatMessage[],
  text: string,
  language: AppLanguage
): Promise<EyoReply> {
  if (!API_URL) {
    return { reply: processAICommand(text, language), source: 'offline' };
  }

  const messages = [
    ...history
      .filter((m) => m.id !== 'greeting')
      .slice(-MAX_HISTORY)
      .map((m) => ({ role: m.role, content: m.content })),
    { role: 'user' as const, content: text },
  ];

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      // If the camera just described something, Eyo can answer follow-ups about it.
      body: JSON.stringify({ messages, language, context: recentVision()?.text }),
    });
    if (!res.ok) throw new Error(`Eyo API ${res.status}`);
    const data = (await res.json()) as { reply?: string };
    if (!data.reply) throw new Error('Empty reply');
    return { reply: data.reply, source: 'ai' };
  } catch {
    return { reply: processAICommand(text, language), source: 'offline' };
  } finally {
    clearTimeout(timer);
  }
}
