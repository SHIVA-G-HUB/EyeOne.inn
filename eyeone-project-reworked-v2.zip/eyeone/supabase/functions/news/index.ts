// Supabase Edge Function: EyeOne news.
// Fetches Google News RSS (Tamil or English, India edition) and returns clean JSON,
// because phones/browsers cannot read RSS cross-origin.
//   supabase functions deploy news
// GET ?lang=ta|en&category=all|tamil-nadu|medical|india|world|business|technology|sports|entertainment|health&q=optional
// @ts-nocheck  (Deno runtime)

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

const TOPICS: Record<string, string> = {
  india: 'NATION',
  world: 'WORLD',
  business: 'BUSINESS',
  technology: 'TECHNOLOGY',
  sports: 'SPORTS',
  entertainment: 'ENTERTAINMENT',
  health: 'HEALTH',
};

// Search phrases per language for topics that are not a Google News section.
const SEARCHES: Record<string, Record<string, string>> = {
  'tamil-nadu': { en: 'Tamil Nadu', ta: 'தமிழ்நாடு' },
  medical: {
    en: '(doctors OR hospital OR medical OR healthcare) Tamil Nadu',
    ta: '(மருத்துவர் OR மருத்துவமனை OR மருத்துவம் OR சுகாதாரம்)',
  },
  politics: { en: 'Tamil Nadu politics', ta: 'தமிழக அரசியல்' },
  education: { en: 'education India schools colleges', ta: 'கல்வி பள்ளி கல்லூரி' },
  government: { en: 'Tamil Nadu government scheme', ta: 'தமிழக அரசு திட்டம்' },
  weather: { en: 'Chennai weather rain', ta: 'சென்னை வானிலை மழை' },
};

function feedUrl(lang: string, category: string, q: string): string {
  const hl = lang === 'ta' ? 'ta' : 'en-IN';
  const ceid = lang === 'ta' ? 'IN:ta' : 'IN:en';
  const tail = `hl=${hl}&gl=IN&ceid=${ceid}`;
  const query = q || SEARCHES[category]?.[lang];
  if (query) return `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&${tail}`;
  const topic = TOPICS[category];
  if (topic) return `https://news.google.com/rss/headlines/section/topic/${topic}?${tail}`;
  return `https://news.google.com/rss?${tail}`;
}

const decode = (s: string) =>
  s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, '&');

const strip = (s: string) => decode(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

function tag(block: string, name: string): string {
  const m = block.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`));
  return m ? m[1] : '';
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  const url = new URL(req.url);
  const lang = url.searchParams.get('lang') === 'ta' ? 'ta' : 'en';
  const category = (url.searchParams.get('category') ?? 'all').slice(0, 30);
  const q = (url.searchParams.get('q') ?? '').slice(0, 100);

  try {
    const res = await fetch(feedUrl(lang, category, q), {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; EyeOneNews/1.0)' },
    });
    if (!res.ok) throw new Error(`feed ${res.status}`);
    const xml = await res.text();

    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 20).map((m, i) => {
      const block = m[1];
      const rawTitle = strip(tag(block, 'title'));
      const source = strip(tag(block, 'source'));
      // Google appends " - Publisher" to titles; remove it, we show the source separately.
      const title = source && rawTitle.endsWith(` - ${source}`) ? rawTitle.slice(0, -(source.length + 3)) : rawTitle;
      const pub = new Date(strip(tag(block, 'pubDate')));
      return {
        id: `${category}-${i}-${pub.getTime() || i}`,
        title,
        source: source || 'Google News',
        link: strip(tag(block, 'link')),
        publishedAt: isNaN(pub.getTime()) ? new Date().toISOString() : pub.toISOString(),
      };
    });

    return new Response(JSON.stringify({ items }), {
      headers: { ...cors, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=300' },
    });
  } catch {
    return new Response(JSON.stringify({ error: 'Could not load news' }), {
      status: 502,
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  }
});
