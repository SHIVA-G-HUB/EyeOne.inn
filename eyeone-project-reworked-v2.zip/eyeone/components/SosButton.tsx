import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { Siren } from 'lucide-react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { haptic } from '@/lib/haptics';

/** Always-reachable emergency entry point. Opens the SOS screen (which never calls by itself). */
export function SosButton({ compact }: { compact?: boolean }) {
  const { getFontSize, language } = useAccessibility();
  const t = (key: any) => getTranslation(language, key);
  const router = useRouter();

  return (
    <Pressable
      onPress={() => {
        haptic.warning();
        router.push('/sos');
      }}
      accessibilityRole="button"
      accessibilityLabel={t('emergency')}
      accessibilityHint={t('sosHint')}
      style={({ pressed }) => [styles.btn, compact && styles.compact, { opacity: pressed ? 0.7 : 1 }]}
    >
      <Siren color="#FFF" size={compact ? 24 : 30} strokeWidth={2.5} />
      {!compact && <Text style={[styles.label, { fontSize: getFontSize(18) }]}>{t('emergency')}</Text>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#DC2626',
    borderRadius: 16,
    minHeight: 56,
    paddingHorizontal: 20,
  },
  compact: { width: 52, height: 52, minHeight: 52, borderRadius: 26, paddingHorizontal: 0 },
  label: { color: '#FFF', fontWeight: '800' },
});
