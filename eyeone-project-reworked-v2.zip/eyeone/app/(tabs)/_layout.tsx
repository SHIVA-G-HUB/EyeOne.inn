import { Tabs } from 'expo-router';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { MessageCircle, Camera, Navigation, Newspaper, Settings } from 'lucide-react-native';
import { haptic } from '@/lib/haptics';

/**
 * Five big, always-visible tabs. Eyo (talk) is first and opens by default;
 * "See" is the camera. Home and Help stay routable (Eyo and Settings link to them)
 * but are hidden from the bar to keep it short for screen-reader users.
 */
export default function TabLayout() {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const iconSize = 28;

  return (
    <Tabs
      initialRouteName="assistant"
      screenListeners={{ tabPress: () => haptic.tap() }}
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: 76,
          paddingBottom: 10,
          paddingTop: 8,
        },
        tabBarLabelStyle: { fontSize: getFontSize(12), fontWeight: '700' },
      }}
    >
      <Tabs.Screen
        name="assistant"
        options={{
          title: 'Eyo',
          tabBarIcon: ({ color }) => <MessageCircle color={color} size={iconSize} strokeWidth={2.5} />,
          tabBarAccessibilityLabel: `Eyo, ${t('aiAssistant')}`,
        }}
      />
      <Tabs.Screen
        name="camera"
        options={{
          title: t('see'),
          tabBarIcon: ({ color }) => <Camera color={color} size={iconSize} strokeWidth={2.5} />,
          tabBarAccessibilityLabel: t('see'),
        }}
      />
      <Tabs.Screen
        name="navigation"
        options={{
          title: t('navigation'),
          tabBarIcon: ({ color }) => <Navigation color={color} size={iconSize} strokeWidth={2.5} />,
          tabBarAccessibilityLabel: t('navigation'),
        }}
      />
      <Tabs.Screen
        name="news"
        options={{
          title: t('news'),
          tabBarIcon: ({ color }) => <Newspaper color={color} size={iconSize} strokeWidth={2.5} />,
          tabBarAccessibilityLabel: t('news'),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: t('settings'),
          tabBarIcon: ({ color }) => <Settings color={color} size={iconSize} strokeWidth={2.5} />,
          tabBarAccessibilityLabel: t('settings'),
        }}
      />
      <Tabs.Screen name="index" options={{ href: null }} />
      <Tabs.Screen name="help" options={{ href: null }} />
    </Tabs>
  );
}
