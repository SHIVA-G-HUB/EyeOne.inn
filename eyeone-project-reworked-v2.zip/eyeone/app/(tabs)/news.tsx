import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, FlatList } from 'react-native';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { getTranslation } from '@/i18n/translations';
import { useSpeech } from '@/hooks/useSpeech';
import { ScreenWrapper, AccessibleHeading } from '@/components/ui/AccessibleComponents';
import { newsCategories, NewsArticle, formatTimeAgo, fetchNews } from '@/services/news';
import { haptic } from '@/lib/haptics';
import { Play, Pause, Square, RotateCcw, Bookmark, BookmarkCheck, Search, X, Clock, RefreshCw } from 'lucide-react-native';

export default function NewsScreen() {
  const { getColors, getFontSize, language } = useAccessibility();
  const colors = getColors();
  const t = (key: any) => getTranslation(language, key);
  const { speak, pause, resume, stop, isSpeaking, isPaused, isSupported } = useSpeech();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [readingId, setReadingId] = useState<string | null>(null);
  const [savedArticles, setSavedArticles] = useState<string[]>([]);
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(true);
  const requestId = useRef(0);

  const load = useCallback(
    async (category: string, query?: string) => {
      const id = ++requestId.current;
      setLoading(true);
      const result = await fetchNews({ language, category, query });
      if (id !== requestId.current) return; // a newer request won
      setArticles(result.articles);
      setIsLive(result.live);
      setLoading(false);
      if (!result.live) speak(t('newsOffline'), { lang: language === 'ta' ? 'ta-IN' : 'en-US' });
    },
    [language]
  );

  useEffect(() => {
    load(selectedCategory);
  }, [selectedCategory, language, load]);

  // Typing filters what is already loaded; pressing search asks the server for that topic.
  const filteredNews = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return articles;
    return articles.filter((a) => a.title.toLowerCase().includes(q) || (a.titleTamil ?? '').includes(searchQuery.trim()));
  }, [articles, searchQuery]);

  const getArticleText = useCallback(
    (article: NewsArticle) => {
      const title = language === 'ta' && article.titleTamil ? article.titleTamil : article.title;
      const summary = language === 'ta' && article.summaryTamil ? article.summaryTamil : article.summary;
      const content = language === 'ta' && article.contentTamil ? article.contentTamil : article.content;
      return [title, summary, content].filter(Boolean).join('. ');
    },
    [language]
  );

  const handleRead = useCallback(
    (article: NewsArticle) => {
      if (readingId === article.id && isSpeaking()) {
        if (isPaused()) {
          resume();
        } else {
          pause();
        }
        return;
      }
      setReadingId(article.id);
      speak(getArticleText(article), {
        lang: language === 'ta' ? 'ta-IN' : 'en-US',
        onEnd: () => setReadingId(null),
      });
    },
    [readingId, isSpeaking, isPaused, resume, pause, speak, getArticleText, language]
  );

  const handleStop = useCallback(() => {
    stop();
    setReadingId(null);
  }, [stop]);

  const handleRestart = useCallback(
    (article: NewsArticle) => {
      stop();
      setTimeout(() => {
        speak(getArticleText(article), {
          lang: language === 'ta' ? 'ta-IN' : 'en-US',
          onEnd: () => setReadingId(null),
        });
      }, 100);
    },
    [stop, speak, getArticleText, language]
  );

  const toggleSave = useCallback((id: string) => {
    setSavedArticles((prev) => (prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]));
  }, []);

  const renderArticle = ({ item }: { item: NewsArticle }) => {
    const title = language === 'ta' && item.titleTamil ? item.titleTamil : item.title;
    const summary = language === 'ta' && item.summaryTamil ? item.summaryTamil : item.summary;
    const isReading = readingId === item.id;
    const isSaved = savedArticles.includes(item.id);
    const timeAgo = formatTimeAgo(item.publishedAt, language);

    return (
      <View
        style={[styles.articleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
        accessibilityRole="summary"
        accessibilityLabel={`${item.category}. ${title}. ${t('publishedAt')} ${timeAgo}. ${summary}`}
      >
        <View style={styles.articleHeader}>
          <View style={[styles.categoryBadge, { backgroundColor: colors.primary }]}>
            <Text style={[styles.categoryText, { color: colors.primaryText }]}>
              {language === 'ta' ? newsCategories.find((c) => c.key === item.categoryKey)?.labelTa || item.category : item.category}
            </Text>
          </View>
          <View style={styles.timeContainer}>
            <Clock color={colors.textSecondary} size={14} strokeWidth={2} />
            <Text style={[styles.timeText, { color: colors.textSecondary }]}>{timeAgo}</Text>
          </View>
        </View>

        <Text
          style={[styles.articleTitle, { color: colors.text, fontSize: getFontSize(20) }]}
          accessibilityRole="header"
        >
          {title}
        </Text>
        <Text style={[styles.articleSummary, { color: colors.textSecondary, fontSize: getFontSize(15) }]}>
          {summary}
        </Text>

        <View style={styles.articleActions}>
          <Pressable
            onPress={() => handleRead(item)}
            accessibilityRole="button"
            accessibilityLabel={isReading ? (isPaused() ? t('resume') : t('pause')) : t('readArticle')}
            accessibilityHint={isReading ? 'Pause or resume reading' : 'Read this article aloud'}
            style={({ pressed }) => [
              styles.actionButton,
              { backgroundColor: isReading ? colors.accent : colors.primary, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            {isReading && isSpeaking() && !isPaused() ? (
              <Pause color={isReading ? '#000' : colors.primaryText} size={20} strokeWidth={2.5} />
            ) : isReading && isPaused() ? (
              <Play color="#000" size={20} strokeWidth={2.5} />
            ) : (
              <Play color={colors.primaryText} size={20} strokeWidth={2.5} />
            )}
            <Text style={[styles.actionText, { color: isReading ? '#000' : colors.primaryText }]}>
              {isReading ? (isPaused() ? t('resume') : t('pause')) : t('read')}
            </Text>
          </Pressable>

          {isReading && (
            <>
              <Pressable
                onPress={handleStop}
                accessibilityRole="button"
                accessibilityLabel={t('stop')}
                style={({ pressed }) => [
                  styles.actionButtonSmall,
                  { backgroundColor: colors.error, opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <Square color="#FFF" size={18} strokeWidth={2.5} />
                <Text style={[styles.actionTextSmall, { color: '#FFF' }]}>{t('stop')}</Text>
              </Pressable>
              <Pressable
                onPress={() => handleRestart(item)}
                accessibilityRole="button"
                accessibilityLabel={t('restart')}
                style={({ pressed }) => [
                  styles.actionButtonSmall,
                  { backgroundColor: colors.surfaceAlt, opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <RotateCcw color={colors.text} size={18} strokeWidth={2.5} />
                <Text style={[styles.actionTextSmall, { color: colors.text }]}>{t('restart')}</Text>
              </Pressable>
            </>
          )}

          <Pressable
            onPress={() => toggleSave(item.id)}
            accessibilityRole="button"
            accessibilityLabel={isSaved ? t('removeSaved') : t('saveArticle')}
            style={({ pressed }) => [
              styles.actionButtonSmall,
              { backgroundColor: isSaved ? colors.accent : colors.surfaceAlt, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            {isSaved ? (
              <BookmarkCheck color="#000" size={18} strokeWidth={2.5} />
            ) : (
              <Bookmark color={colors.text} size={18} strokeWidth={2.5} />
            )}
            <Text style={[styles.actionTextSmall, { color: isSaved ? '#000' : colors.text }]}>
              {isSaved ? t('removeSaved') : t('saveArticle')}
            </Text>
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <ScreenWrapper>
      <View style={styles.header}>
        <AccessibleHeading text={t('news')} level={1} />
        <View style={styles.headerActions}>
        <Pressable
          onPress={() => {
            haptic.tap();
            load(selectedCategory);
          }}
          accessibilityRole="button"
          accessibilityLabel={t('refresh')}
          style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
        >
          <View style={[styles.searchToggle, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <RefreshCw color={colors.primary} size={20} strokeWidth={2.5} />
          </View>
        </Pressable>
        <Pressable
          onPress={() => setIsSearchVisible(!isSearchVisible)}
          accessibilityRole="button"
          accessibilityLabel={t('searchNews')}
          style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
        >
          <View style={[styles.searchToggle, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Search color={colors.primary} size={20} strokeWidth={2.5} />
          </View>
        </Pressable>
        </View>
      </View>

      {!isLive && !loading && (
        <View
          style={[styles.notice, { backgroundColor: colors.surface, borderColor: colors.warning }]}
          accessibilityRole="alert"
        >
          <Text style={{ color: colors.warning, fontSize: getFontSize(14), fontWeight: '600' }}>{t('newsOffline')}</Text>
        </View>
      )}

      {isSearchVisible && (
        <View style={[styles.searchContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Search color={colors.textSecondary} size={20} strokeWidth={2} />
          <TextInput
            style={[styles.searchInput, { color: colors.text, fontSize: getFontSize(16) }]}
            placeholder={t('searchPlaceholder')}
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={() => load(selectedCategory, searchQuery.trim())}
            returnKeyType="search"
            accessibilityLabel={t('searchNews')}
            accessibilityHint={t('searchPlaceholder')}
            autoCapitalize="none"
            autoCorrect={false}
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery('')} accessibilityLabel={t('clear')}>
              <X color={colors.textSecondary} size={20} strokeWidth={2} />
            </Pressable>
          )}
        </View>
      )}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryScrollContent}
        accessibilityRole="tablist"
      >
        {[{ key: 'all', labelEn: 'All', labelTa: 'அனைத்தும்', icon: '' }, ...newsCategories].map((cat) => {
          const isSelected = selectedCategory === cat.key;
          const label = language === 'ta' ? cat.labelTa : cat.labelEn;
          return (
            <Pressable
              key={cat.key}
              onPress={() => {
                setSelectedCategory(cat.key);
                setSearchQuery('');
              }}
              accessibilityRole="tab"
              accessibilityLabel={label}
              accessibilityState={{ selected: isSelected }}
              style={({ pressed }) => [
                styles.categoryChip,
                {
                  backgroundColor: isSelected ? colors.primary : colors.surface,
                  borderColor: isSelected ? colors.primary : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text
                style={[
                  styles.categoryChipText,
                  {
                    color: isSelected ? colors.primaryText : colors.text,
                    fontSize: getFontSize(14),
                  },
                ]}
              >
                {label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <FlatList
        data={filteredNews}
        renderItem={renderArticle}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text
              accessibilityLiveRegion="polite"
              style={[styles.emptyText, { color: colors.textSecondary, fontSize: getFontSize(16) }]}
            >
              {loading ? t('loading') : t('noResults')}
            </Text>
          </View>
        }
      />
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  headerActions: { flexDirection: 'row', gap: 10 },
  notice: { padding: 12, borderRadius: 12, borderWidth: 1, marginBottom: 12 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingRight: 4,
  },
  searchToggle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontWeight: '500',
  },
  categoryScroll: {
    marginBottom: 12,
  },
  categoryScrollContent: {
    gap: 8,
    paddingRight: 16,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  categoryChipText: {
    fontWeight: '700',
  },
  listContent: {
    paddingBottom: 20,
  },
  articleCard: {
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    marginBottom: 14,
  },
  articleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  categoryBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
  },
  categoryText: {
    fontSize: 12,
    fontWeight: '700',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  timeText: {
    fontSize: 12,
    fontWeight: '500',
  },
  articleTitle: {
    fontWeight: '800',
    lineHeight: 26,
    marginBottom: 8,
  },
  articleSummary: {
    lineHeight: 22,
    marginBottom: 14,
  },
  articleActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
    gap: 8,
  },
  actionText: {
    fontSize: 14,
    fontWeight: '700',
  },
  actionButtonSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    gap: 6,
  },
  actionTextSmall: {
    fontSize: 13,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontWeight: '600',
  },
});
